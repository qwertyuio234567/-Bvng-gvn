# Piano Hell

A landscape-only, 12-lane falling-note rhythm game for Android, written in Java with a C++ (Oboe)
audio core, built to survive **black MIDI**: charts with hundreds of thousands to millions of note
events, dense enough to be unplayable by a human and heavy enough to kill a normal View-based game.

```
      ▓▓                     ← notes fall down 12 lanes
      ▓▓  ▓▓
   ▓▓ ▓▓  ▓▓  ▓▓              12 chromatic lanes, each with its own accent colour
   ▓▓ ▓▓  ▓▓  ▓▓  ▓▓          variable-length holds (0.1 s … multi-second)
   ▓▓ ▓▓  ▓▓  ▓▓  ▓▓  ▓▓      polyphonic: many fingers, many lanes, at once
 ══════════════════════         hit line · tap / hold judgment
```

* **Package** `com.pianohell` · **v1.0.4** (versionCode 5) · **minSdk 24** · **targetSdk 34** · landscape-locked
* **Build output** `app/build/outputs/apk/debug/app-debug.apk` (≈ 8 MB, debug-signed, 3 ABIs)
* **Dependencies** exactly two: `androidx.recyclerview` and `com.google.oboe:oboe:1.8.1` (Prefab)

---

## 1. Install / run

```bash
bash tools/build.sh                 # bootstraps the toolchain if needed, builds, refreshes the APK
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

`tools/build.sh` is the intended entry point: it exports `GRADLE_USER_HOME` to an excluded cache
directory, moves the NDK staging tree inside `app/build/`, bootstraps the JDK/SDK/NDK on demand and
copies the finished APK to the workspace root. On a normal workstation, plain Gradle works too:

```bash
echo "sdk.dir=$ANDROID_HOME" > local.properties
JAVA_HOME=/path/to/jdk17 ./gradlew :app:assembleDebug   # -> app/build/outputs/apk/debug/app-debug.apk
```

The wrapper is committed (`./gradlew`), the toolchain it expects is JDK 17, AGP 8.5.2, Gradle 8.7,
NDK 26.1.10909125, CMake 3.22.1.

> **Workspace budget note (the reason `tools/build.sh` exists).** The project is built in a sandbox
> whose workspace snapshot only excludes a fixed list of directory names (`.cache`, `.local`, `build`,
> `node_modules`, …). Gradle's default user home is `~/.gradle` — **not** on that list — and in this
> project it grows to ~500 MB and thousands of files; the CMake staging tree (`app/.cxx` by default)
> has the same problem. A build once pushed the session to 517 MB / 2,446 files, over the
> 128 MB / 10,000-file limit, and 2,282 cache files were dropped (no source lost — verified — but it
> must not happen twice). Both are now redirected into excluded paths, so a full native build leaves
> a snapshot footprint of approximately nothing.

On launch: **PRESET CHARTS** (catalogue) or **IMPORT A .MID FILE** (Storage Access Framework).
Rotate to landscape; if the window ends up portrait anyway (split-screen, foldables, an OEM that
ignores `screenOrientation`), a full-screen "ROTATE YOUR DEVICE" overlay covers the game.

---

## 2. Where the spec's files went

| Spec file | In this project | Notes |
|---|---|---|
| `MainActivity.java` | `MainActivity.java` | landscape lock, menu, global options |
| `GameView.java` | `GameView.java` | `SurfaceView` + dedicated render thread + the pixel rasteriser |
| `GameEngine.java` | `GameEngine.java` | fixed-timestep loop, input, holds, judgment, scoring |
| `ChartData.java` | `ChartData.java` | flat primitive arrays, radix sort, binary search |
| `MidiParser.java` | `MidiParser.java` | hand-written SMF reader, two streaming passes |
| `MidiMapper.java` | `MidiMapper.java` | 128→12 lane mapping (3 modes) + colour resolution |
| `AudioEngine.java` + JNI + Oboe C++ | `AudioEngine.java`, `app/src/main/cpp/PianoHellJni.cpp`, `NativeAudioEngine.{h,cpp}`, `CMakeLists.txt` | lock-free event ring, 96-voice mixer |
| `PresetListActivity.java` | `PresetListActivity.java` + `PresetAdapter.java` + `PresetThemeSwatch.java` | RecyclerView catalogue **and** the import screen (one pane per launch) |
| `AndroidManifest.xml` | `AndroidManifest.xml` | landscape lock, no storage permissions (SAF) |
| — | `NotePool.java` | pooling for per-frame tile records, particles, touch events |
| — | `GameActivity.java` | hosts the surface, owns the run lifecycle |
| — | `ChartLoader.java` | every chart load, always on a worker thread |
| — | `ChartIO.java` | custom binary chart format (`.phc`) + import cache |
| — | `ChartGenerator.java`, `OrientationGuard.java`, `PhApp.java`, `LoadedChartStash.java` | procedural charts, orientation overlay, app context, chart hand-off |

---

## 3. The performance-critical decisions (and why)

### 3.1 Rendering: one SurfaceView, one thread, one int[] framebuffer — never a View per note

`GameView` owns a `SurfaceView`, starts a `Thread` in `surfaceCreated()` (priority `MAX_PRIORITY`,
joined in `surfaceDestroyed()`), and each frame does:

```
engine.advance()  →  collectTiles()  →  rasterize()  →  present()
```

* **Why not Views:** 12 lanes × ~50 visible tiles = 600+ views, each with measure/layout/draw and
  its own invalidation. At black-MIDI density that is thousands of views and it collapses long
  before the chart is even parsed.
* **Why pixels and not `canvas.drawRect` per tile:** tiles are flat rectangles with a glow halo; in
  an `int[]` buffer that is arithmetic, not a display-list entry per note. Per-pixel work is bounded
  by three deliberate choices: the tile **body is an opaque `Arrays.fill`** (one vectorised store
  instead of a blend per pixel), the background is **24 gradient bands × 12 lanes** filled the same
  way, and hold notes draw as **a full-width head plus a narrow tail** (~2.5× fewer writes on
  multi-second holds).
* **Adaptive internal resolution:** if a frame budget slips (`< 45 fps`), the framebuffer shrinks
  (down to 55 %) and is upscaled by the surface. The simulation is never affected — a rhythm game
  may not change *when* notes are judged because the GPU is busy; it may only change how many pixels
  they cover.
* **Bounded work per frame:** `MAX_DRAW_TILES = 1400`. Past that the remaining tiles are not drawn
  this frame (the HUD shows `drawn/available`). Bounded, predictable frames beat an unbounded loop
  that stutters exactly during the densest passage.
* Text (combo, score, judgments) is drawn with `Canvas.drawText` over the finished bitmap — glyph
  rasterisation is the one thing Canvas is genuinely better at, and it is a handful of calls.

### 3.2 Notes are a struct-of-arrays, not objects

`ChartData` keeps `long[] startMs`, `int[] durationMs`, `byte[] lane`, `byte[] colorId`, `byte[] kind`,
`byte[] flags`, `byte[] jud`, `int[] midiPitch` — roughly **20 bytes per note**.

* 5,000,000 notes as objects ≈ 350 MB of heap + a pointer chase per note per frame + a GC pause
  exactly when the run gets hard. As flat arrays it is ~100 MB of contiguous, prefetchable memory
  and **zero allocation during play**.
* `startMs` is ascending, so a frame costs `2 × binary search + the visible window` — a
  **5,000,000-note chart and a 500-note chart cost the same per frame**.
* The visible window includes still-running holds by searching from
  `windowStart − longestNoteDuration` (one extra binary search, no backwards scan).
* When a file's notes are not already ordered (multi-track merges), an O(n) sortedness check decides
  whether to sort at all; when it does sort it sorts an `int[]` **permutation** with an LSD radix
  sort (4 × 8-bit passes) and applies it in place by cycle-following — ~4 bytes/note of scratch
  instead of a second copy of the arrays.
* `ChartData.collapsePass()` folds same-lane notes closer than `collapseMs` into single tiles /
  stretched holds, in place, in one linear sweep after the sort (so it also catches overlaps coming
  from different MIDI tracks).

### 3.3 Object pooling, where objects are unavoidable

`NotePool` preallocates the per-frame **tile display records** (4096), **particles** (1024) and a
**touch-event ring** (2048). The render loop acquires from the pool and calls `resetFrame()`;
steady-state play allocates nothing, so there is no GC pause in the middle of a chart. The pool
deliberately holds the *display* records only — the notes themselves are never objects.

### 3.4 Fixed timestep, decoupled from frame rate

`GameEngine.advance()` accumulates real nanoseconds and runs 200 Hz steps (5 ms) with a catch-up cap
(50 steps) so a stalled frame cannot spiral. Judgment windows are in milliseconds, so the simulation
must not care whether the last frame took 8 ms or 33 ms. **Song time is anchored to the audio clock**
(`playbackPositionMs()` from the native stream, i.e. frames actually played), with a measured bias
(the count-in means song time starts negative) and a proportional correction of 2 % per frame, or a
hard re-anchor if the error exceeds 90 ms. That is what stops tiles drifting away from the samples
over a 12-minute black-MIDI run. Touch events are timestamped with `MotionEvent.getEventTime()` and
converted into song time, so input lag does not silently become judgment error; the player's
`audioOffsetMs` calibration is applied on top.

### 3.5 Input: real multi-touch

`onTouchEvent` reads the action-masked pointer index for DOWN/UP and iterates every pointer for
CANCEL; each `pointerId` is tracked per lane, so simultaneous holds across many lanes work. Events
are pushed into a lock-free-ish ring and drained inside the fixed step. A hold is judged *good* when
the finger stays down until the tail passes (within `holdReleaseToleranceMs`), *partial* when
released early, *miss* when the tile runs out. Nothing is judged on `MOVE` for taps — slides cannot
re-trigger notes (`Piano Tiles` semantics).

### 3.6 MIDI import: hand-written parser, two streaming passes, off the UI thread

`android.media.midi` is a router to MIDI *devices* and cannot read a file; Gervill is a Java
soft-synth that is absent on Android and drops events at black-MIDI rates. So `MidiParser` reads the
SMF byte stream directly — VLQ deltas, **running status** (black-MIDI generators rely on it), every
channel message length, meta events (tempo `0x51`, end-of-track `0x2F`), sysex skipping, PPQ **and**
SMPTE divisions.

* **Pass 1** collects the tempo map + pitch/channel histograms. **Pass 2** walks the tracks again and
  writes notes **straight into the flat arrays**. A 1 MB sliding window means a 300 MB file never
  becomes a 300 MB `byte[]`.
* A LIFO stack **per (channel, pitch)** pairs note-ons with note-offs — a single "last note" slot per
  key is not enough when a generator stacks thousands of overlapping notes on one pitch.
* A file whose first tempo event is not at tick 0 gets an implicit 120 BPM entry at tick 0 (otherwise
  every earlier note gets a *negative* timestamp).
* The 128→12 mapping is baked into a 128-entry lookup table once per import, so per-note cost is one
  array read.
* Runs in `ChartLoader` on a single worker thread with progress + cancellation; the parsed chart is
  cached as a **`.phc`** file (Deflate level 1 — a flat dump of the same arrays), so the second launch
  of a 200 MB import is a `readFully`, not a parse.

### 3.7 Audio: Oboe + a fixed voice pool, and the audio clock drives the game

`MediaPlayer` (~200 ms), `SoundPool` (~40–80 ms and a stream ceiling) and Gervill are all out — a late
sound in a rhythm game reads as a *wrong judgment*. The C++ side opens an AAudio **LowLatency**
output (preferring Exclusive + native sample rate + 128-frame callbacks, falling back gracefully when
the device refuses), and mixes into it:

* **96 preallocated voices.** No allocation, no locks, no syscalls in the callback — an xrun during
  the densest bar is exactly the failure this game cannot have.
* **Lock-free SPSC ring** (4096 slots) for note events from the UI thread. Full ring ⇒ *drop* the
  event (silence) rather than block the UI thread.
* **Pre-rendered instrument:** 12 key samples synthesised once at startup by additive synthesis with
  stiff-string inharmonicity, per-partial decay and a hammer transient, then pitch-shifted per note
  (`ratio = 2^(semitones/12)`) with linear interpolation and looped tails for long holds.
  `AudioEngine.installSample()` / `nativeSetSample()` can replace them with a real WAV/SoundFont
  render.
* Soft clipping on the mix bus (dozens of voices in a black-MIDI cluster), lane-based stereo spread.
* If the `.so` is missing for the device ABI or Oboe cannot open a stream, `AudioEngine` becomes a
  documented **silent no-op** and the game stays playable — deliberately *not* a fallback to
  SoundPool, because a late sound is worse than no sound.

### 3.8 Colours

`NoteColors` resolves everything into a 32-entry ARGB palette at load time; `byte colorId` in the
chart stores an *index*:

```
0..11   lane theme colour      (12 configurable accents — Neon / Ice / Hellfire / Mono / Rainbow)
12..27  MIDI channel 0..15     (multi-colour black-MIDI chaos)
28..31  velocity buckets       (ppp / mf / ff / ffff)
```

The render loop therefore only ever does `palette[colorId[i] & 31]` — no per-note parsing, no
allocation, and a theme switch re-generates the palette without touching a single chart array.

---

## 4. Presets

| Tier | Title | BPM | Notes (raw) | After collapse | Source |
|---|---|---|---|---|---|
| 2 | Twinkle Warmup | 108 | 84 | 42 tiles | bundled `.mid`, melody + octave doubling (collapse demo) |
| 5 | Canon in D | 96 | 960 | 840 tiles | bundled `.mid`, arpeggios + 3 s bass pedals (hold demo) |
| 8 | Chromatic Cascade | 160 | 9,771 | 9,655 tiles | bundled `.mid`, 16th-note runs hand to hand |
| 10 | Density Storm | 200 | 246,336 | ~20,000 tiles | bundled `.mid`, 64th-note clusters + tempo drift |
| 12 | BLACK MIDI SYMPHONY | 300 | **2,000,000** | ~152,000 tiles | generated live (a 2M-note `.mid` would be 50–300 MB) |

The bundled files are produced by `tools/make_presets.py` and checked by a second, independent SMF
reader in `tools/validate_midi.py` (they use running status, mid-file tempo changes, overlapping
same-pitch notes and same-lane stacks on purpose — they are importer test fixtures as much as
charts). Every preset row shows title, BPM, difficulty rating, note count and a preview colour
swatch (`PresetThemeSwatch`), plus your personal best.

---

## 5. Verification

`tools/harness/PianoHellHarness.java` runs the whole pure-Java half of the game on a desktop JVM —
no emulator — against the real preset files: **68 checks pass** (see `tools/harness/RESULTS.txt`).

Measured on the host (2 cores, JDK 17; the JVM is not a phone, but the ratios are the useful part):

```
twinkle  mode=0  raw=84       tiles=42       holds=42     holdLen=500..1000 ms    3 ms
canon    mode=0  raw=960      tiles=840      holds=840    holdLen=148..2500 ms    2 ms
cascade  mode=0  raw=9771     tiles=9655     holds=0                              10 ms
storm    mode=0  raw=246336   tiles=20347    holds=17414  holdLen=100..3527 ms   171 ms
         tempoChanges=17  length=88.1 s  memory=4.9 MB
binary search: 643 probes on a 246336-tile chart, all invariants hold
generated 2,000,000 raw notes -> 152,717 tiles in 196 ms (10.2 M notes/s), heap 40 MB
render-window queries: 140k frames, avg 707 tiles/frame, 0.13 µs/frame
```

The parser handles a 246k-note file in ~170 ms (≈2,800 notes/s of music) and the 2M-note generator
runs at 10 M notes/s, i.e. a chart of that size is ready roughly two seconds after you tap it.

Two bugs found this way, both of which would have shipped as *"every preset chart is empty"*:
a `Long.MIN_VALUE` sentinel whose subtraction overflowed the collapse comparison, and a missing
implicit 120 BPM before a file's first tempo event (which produced negative note times). The harness
keeps a regression check for both.

**Not verified here:** anything that needs a real device — actual Oboe latency, the on-device frame
rate at 1000+ tiles, and touch hardware behaviour. The numbers above are algorithmic (complexity and
memory), not GPU claims.

---

## 6. Tuning knobs

| Where | What |
|---|---|
| `tools/check_view_types.py` | run before every build: catches the `ClassCastException` class of bug (v1.0.2) |
| `ScrollWindow` | the one place chart time maps to screen geometry; its window is checked by the harness (v1.0.3) |
| `GameConfig` | scroll speed (`scrollMs`), hit-line position, judgment windows per difficulty (Easy … Black), hold release tolerance, collapse threshold, mapping mode, sudden death, colouring, audio offset, theme |
| `PresetListActivity` | mapping mode (pitch-class / scale quantize / density remap), scale + key root, collapse ms, difficulty, drop channel 10 |
| `ChartData.MAX_NOTES` | 5,000,000 — the ceiling the arrays and the pool are sized against |
| `NotePool` | `MAX_ACTIVE`, `MAX_PARTICLES`, `MAX_EVENTS` |
| `GameView` | `MAX_FPS`, `MAX_DRAW_TILES`, `SCALE_MIN`, `BANDS` |
| `NativeAudioEngine.h` | `kVoices` (96), `kEventsRing` (4096) |

## 7. The bugs that shipped, and what changed

### v1.0.4 — the real "nothing appears" bug (surface created before the chart was bound) + new look

**Root cause.** `GameView.surfaceChanged()` built the framebuffer on the UI thread and read `cfg` /
`palette`. Those are only set by `bind()`, which runs when the (asynchronous) chart load finishes.
With a preset the surface usually appears FIRST, so `cfg` was `null` → `NullPointerException` →
"Piano Hell keeps stopping" / an empty play screen. v1.0.3's change to `ScrollWindow` was correct maths
but was not the cause, which is why nothing changed after it. Reproduced with
`tools/render-test` (desktop JVM, drives the real render thread in the real order:
`surfaceCreated → surfaceChanged → bind`) — it threw the NPE before the fix and renders frames after.

**Fix.** The UI thread only *records* the surface size and a `geometryDirty` flag. The render thread
alone builds buffers/geometry (`applyGeometry()`), and only once an engine is bound. `bind()` publishes
`cfg`/`colors`/`palette` first and the (volatile) `engine` last. `adaptResolution()` also goes through
the flag, so there is exactly one owner of the framebuffer.

**Look.** Piano keyboard under the hit line (white/dark keys, note names, keys light up in the lane
colour when hit or held), rounded gradient tiles with a bevel, specular streak and glow (glow turns
itself off when the screen is crowded), light beams up the lane on hit, scrolling beat grid, hit-line
glow, big combo + judgment popup, thin progress bar. `showDiagnostics` now defaults to off.

**Not verified here:** an actual APK build / on-device run (no Android SDK in the sandbox). Desktop
render test only.

### v1.0.3 — nothing appeared in the playfield (time axis inverted in the renderer)

The board drew, but the falling area stayed empty: the game looked like it had not loaded a chart.
They y-mapping is correct and unchanged —

```java
yHead = hitLinePx − (start − songMs) · pxPerMs     // a note that has NOT arrived sits ABOVE the hit line
```

— but the *visible-window* calculation that feeds it had both signs flipped:

```java
final double topMs    = songMs - (hitY / pxPerMs);            // the PAST edge, not the top
final double bottomMs = songMs + ((bufH - hitY) / pxPerMs);   // the future edge, not the bottom
```

so the renderer only ever fetched notes already **at or behind** the hit line. Everything above it —
the entire falling roll — was never collected, hence drawn as nothing. No exception, no warning, an
empty board.

The mapping now lives in one pure, testable class, `ScrollWindow`, and the window it returns is
*derived* rather than guessed: a tile is visible while `yHead >= −slack` and `yTail <= surfaceH + slack`,
which yields the exact start-time span. Two subtleties that a naive implementation gets wrong, both
of which the harness catches:

1. **Tile height overhang.** A tile keeps hanging over the bottom edge for `tileHeightPx / pxPerMs` ms
   after its head crosses it — searching only to the head's bottom-edge time silently loses the last
   few tiles of *every* frame (the scan saw 3-tile chord bursts vanish).
2. **Long holds.** A hold whose start is long past can still be on screen, so the search reaches back
   by the chart's longest note.

`tools/harness` now verifies the window against a brute-force visibility scan of **every** note in the
chart, across 3,630 geometry probes (5 scroll speeds × 3 hit-line positions × 2 charts): the fetched
window must contain every visible tile, and iterating it must yield exactly the brute-force count.
That check would have caught the original bug on the first run.

Also in this version:

* **`.phc` cache format version bumped to 2** (v1.0.1 added `scaleIndex`/`rootNote` without bumping
  it, so caches written by the older build were read back with the wrong field order), and a cache
  that cannot be read is now **deleted and re-parsed** instead of failing the load. A stale cache is
  a slow load, never a broken one.
* **Load errors are no longer hidden.** `onError` used to dismiss the very panel containing the
  message, leaving an empty board with no explanation. The message now stays on screen with a way out.

### v1.0.2 — the game screen never actually opened (`ClassCastException`)

`activity_game.xml` declares the pause chip as a `<TextView>` (it is a text chip with a button
background); `GameActivity` declared it as `Button`:

```java
private Button btnResume, btnRestart, btnPause;   // btnPause is really a TextView
btnPause = findViewById(R.id.btnPause);           // compiles! runtime ClassCastException
```

`findViewById` is `public final <T extends View> T findViewById(int id)`, so `T` is inferred from the
assignment target and the compiler inserts a silent `checkcast`. On the device that becomes
`java.lang.ClassCastException: android.widget.TextView cannot be cast to android.widget.Button`
thrown from `onCreate`, which Android reports as the unhelpful
`Unable to start activity ComponentInfo{com.pianohell/com.pianohell.GameActivity}: java.lang.…`
(which is exactly what the in-app crash log captured, and why it existed).

`tools/check_view_types.py` now parses every layout and every `findViewById` assignment, resolves the
real widget hierarchy (including this app's own `GameView extends SurfaceView` etc.) and fails the
build if the types disagree — 22 assignments verified against 35 layout ids. `javap` on the compiled
`GameActivity` shows six `checkcast`s and every one now matches its layout.

Also in this version:

* **The audio engine is created on a background thread** (`GameActivity.startAudioAsync`). Opening a
  low-latency stream and pre-rendering the instrument samples is real native work; doing it inline
  stalled activity start and put expensive native code on the launch path. `GameEngine` tolerates a
  null `AudioEngine` and re-learns its clock offset when the engine attaches (`GameEngine.setAudio`),
  so the chart starts instantly and the sound joins a moment later, before the first note arrives.
* **The render loop no longer dies on a transient `null` canvas.** `lockCanvas()` returning null
  (window resize, app switch, the first frame) used to stop the render thread permanently and leave a
  frozen board; now that frame is skipped and the loop continues. Only `surfaceDestroyed` ends it.
* **Framebuffer cap**: the internal bitmap is clamped to 4 M pixels (~16 MB) whatever the window size.
* **The crash summary is conclusive**: the menu now shows the wrapped exception, the *deepest* cause
  and the first `com.pianohell` stack frame, so one screenshot names the failing line.

### v1.0.1 — the menu died before its first frame

The first build (v1.0) died on the device before drawing a single frame: Android only ever showed
*"Piano Hell keeps stopping"* over a black screen — i.e. the crash happened in `MainActivity`, and the
one thing in that path that touched native code was the menu's audio status line, which constructed
a throwaway `AudioEngine` and therefore opened and tore down a low-latency AAudio stream during launch.

The first build (v1.0) died on the device before drawing a single frame: Android only ever showed
*"Piano Hell keeps stopping"* over a black screen — i.e. the crash happened in `MainActivity`, and the
one thing in that path that touched native code was the menu's audio status line, which constructed
a throwaway `AudioEngine` and therefore opened and tore down a low-latency AAudio stream during launch.

Fixed, in layers:

1. **Native teardown race (the actual bug).** `NativeAudioEngine::onError()` called
   `stream->close(); stream_.reset();` — and Oboe documents that closing the stream from inside the
   error callback is illegal. Worse, that teardown could run *while* `start()` was still inside
   `openStream()/requestStart()` on another thread, i.e. two threads mutating one `shared_ptr`.
   The error callback now only records the error and marks the engine not-running; it never touches
   the stream. `start()`/`stop()` are serialised by a mutex, an `opening_` flag guards every use of
   `stream_`, `stop()` is null-safe and idempotent, and a device that refuses a low-latency/exclusive
   stream now falls back to a plain shared stream before giving up.
2. **No native audio on the menu path.** `MainActivity` calls a new side-effect-free
   `AudioEngine.libraryAvailable()` (loads the library, opens nothing). The stream is only opened in
   `GameActivity`, inside a `try/catch(Throwable)`, and the game keeps playing silently if it fails.
3. **Nothing in the startup path is allowed to be fatal.** The orientation re-assert is guarded;
   chart-loader callbacks check `isFinishing()/isDestroyed()`; `beginGame()` shows an in-app error
   instead of dying; `AudioEngine`'s constructor catches `Throwable`, not just `UnsatisfiedLinkError`.
4. **A crash is no longer a black box.** `CrashLog` installs an uncaught-exception handler that writes
   device/build/API + the full stack trace to `filesDir/crash.txt`. The menu shows
   *"LAST RUN CRASHED: <exception>"* with **SHARE CRASH REPORT** / **DISMISS** buttons (the report
   retires itself after two clean launches), and the in-game HUD prints the audio engine's status.
   If v1.0.1 still misbehaves on your device, that text is the whole diagnosis — no adb needed.

Verification for that build: 68/68 host-harness checks still pass, `apksigner verify` clean, native
libs 16 KB-page aligned (required on Android 15 devices with 16 KB pages — checked, and not the cause
here), and the JNI exports, presets and 3 ABIs are all present in the APK.

## 8. Known limitations

* The 2M-note tier is a stress test, not a fair chart: ~218 tiles/second will fail instantly in
  sudden-death mode. Use endless mode (the default menu toggle) if you want to watch it.
* Hold tails are drawn with a fixed minimum height for very short notes (`MIN_HOLD_MS`).
* Two fingers on the *same* lane: the lane remembers one pointer, so the second finger's release ends
  the hold section. Degenerate input, documented in `GameEngine.onDown`.
* Debug-signed APK only; there is no release keystore in this workspace.
* v1.0.1 fixes the launch crash by diagnosis, not by reproduction: the crash was never observed from
  this sandbox (no device, no adb, no logcat from the phone). If it recurs, the crash report the
  menu now shows is what to send.
