# tools/harness

`PianoHellHarness.java` runs the pure-Java half of Piano Hell (MIDI parsing, lane mapping, the flat
chart arrays, the collapse pass, binary search) on a desktop JVM, against the real bundled preset
files. It needs no emulator, which is why it exists: the parser's two-pass streaming design, the
radix sort, the collapse pass and the render-window search can all be regression-tested in two
seconds.

```bash
AJ=$ANDROID_HOME/platforms/android-34/android.jar
javac -encoding UTF-8 -cp $AJ -d /tmp/harness \
      app/src/main/java/com/pianohell/{ChartData,MidiParser,MidiMapper,NoteColors,GameConfig,Preset,ChartGenerator}.java \
      tools/harness/PianoHellHarness.java
java -Xmx2g -cp $AJ:/tmp/harness com.pianohell.PianoHellHarness app/src/main/assets/presets
java -Xmx2g -cp $AJ:/tmp/harness com.pianohell.PianoHellHarness app/src/main/assets/presets --bench-only
```

`RESULTS.txt` holds the last run.

Run `python3 tools/check_view_types.py` too (it needs no toolchain): it compares every `findViewById`
assignment against the class declared in the layout and catches the `ClassCastException` class of bug
that `Activity.findViewById`'s generic signature hides from the compiler. That check found the v1.0.2
game-screen crash.

It caught two bugs that would have shipped as "all preset charts are empty on device":
a `Long.MIN_VALUE` sentinel that overflowed the collapse comparison, and a missing implicit
120 BPM tempo before a file's first tempo event (which produced negative note times).
