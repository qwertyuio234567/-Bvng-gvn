package android.content;

/**
 * Minimal stub — exists ONLY so the host harness can compile and run the game logic without the
 * Android SDK. Only the members GameConfig actually uses are declared; nothing here is shipped.
 */
public interface SharedPreferences {
    int getInt(String key, int def);
    boolean getBoolean(String key, boolean def);
    long getLong(String key, long def);
    float getFloat(String key, float def);
    String getString(String key, String def);

    Editor edit();

    interface Editor {
        Editor putInt(String key, int value);
        Editor putBoolean(String key, boolean value);
        Editor putLong(String key, long value);
        Editor putFloat(String key, float value);
        Editor putString(String key, String value);
        Editor remove(String key);
        void apply();
    }
}
