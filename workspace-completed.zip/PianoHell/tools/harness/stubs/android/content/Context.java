package android.content;

/** Minimal stub — see SharedPreferences.java in this directory. */
public class Context {
    public static final int MODE_PRIVATE = 0;
    public SharedPreferences getSharedPreferences(String name, int mode) { return null; }
}
