package com.pianohell;

import java.io.File;
import java.nio.file.Files;

/**
 * PianoHellHarness — host-JVM test for the parts of Piano Hell that are pure Java.
 *
 * The game's hot path (parsing, mapping, the flat chart arrays, the collapse pass, binary search)
 * has no Android dependency, so it can be exercised against the real bundled preset files here,
 * on a desktop JVM, without an emulator. That is how the parser is checked against running status,
 * tempo maps and 122k-note charts, and how the 2M-note generator is timed.
 *
 * Build:
 *   javac -cp $ANDROID_SDK/platforms/android-34/android.jar -d out \
 *         app/src/main/java/com/pianohell/{ChartData,MidiParser,MidiMapper,NoteColors,NotePool,GameConfig,Preset,ChartGenerator}.java \
 *         tools/harness/PianoHellHarness.java
 * Run:
 *   java -Xmx3g -cp $ANDROID_SDK/platforms/android-34/android.jar:out \
 *        com.pianohell.PianoHellHarness app/src/main/assets/presets
 */
public final class PianoHellHarness {

    private static int checks = 0, failures = 0;

    public static void main(String[] args) throws Exception {
        File dir = new File(args.length > 0 ? args[0] : "app/src/main/assets/presets");
        System.out.println("Piano Hell — host harness");
        System.out.println("========================");

        if (args.length > 1 && args[1].equals("--bench-only")) {
            benchBlackMidi();
            return;
        }

        // ---- 1. parse every bundled chart, with all three mapping modes ----------------------
        for (String name : new String[] { "twinkle", "canon", "cascade", "storm" }) {
            File f = new File(dir, name + ".mid");
            if (!f.exists()) { fail("missing preset " + f); continue; }
            for (int mode = 0; mode <= 2; mode++) {
                parseOne(f, name, mode);
            }
        }

        // ---- 2. binary search invariants on a dense chart ------------------------------------
        binarySearchInvariants(new File(dir, "storm.mid"));

        // ---- 2b. the renderer's visible-window geometry (regression: v1.0.2 showed an empty board)
        renderWindowInvariants(new File(dir, "cascade.mid"), "cascade");
        renderWindowInvariants(new File(dir, "canon.mid"), "canon");

        // ---- 3. the generated 2,000,000-note tier --------------------------------------------
        benchBlackMidi();

        System.out.println();
        System.out.println(failures == 0
                ? "ALL " + checks + " CHECKS PASSED"
                : failures + " of " + checks + " CHECKS FAILED");
        System.exit(failures == 0 ? 0 : 1);
    }

    private static void parseOne(File f, String name, int mode) throws Exception {
        GameConfig cfg = new GameConfig();
        cfg.mappingMode = mode;
        cfg.scaleIndex = 0;              // major
        cfg.rootNote = 0;
        cfg.collapseMs = 45;
        cfg.ignoreDrums = false;
        cfg.themeIndex = 0;

        byte[] bytes = Files.readAllBytes(f.toPath());
        MidiParser.Source src = new MidiParser.BytesSource(bytes, name);
        ChartData chart = new ChartData();
        MidiMapper mapper = new MidiMapper();

        long t0 = System.nanoTime();
        MidiParser.Stats stats = MidiParser.parse(src, mapper, cfg, chart, null);
        long ms = (System.nanoTime() - t0) / 1_000_000L;

        check(chart.count > 0, name + " m" + mode + ": produced notes (" + chart.count + ")");
        check(isSorted(chart), name + " m" + mode + ": startMs ascending");
        check(!hasOverlapInsideWindow(chart, cfg.collapseMs), name + " m" + mode + ": collapse kept lanes apart");
        check(stats.noteOnCount >= chart.count,
                name + " m" + mode + ": raw " + stats.noteOnCount + " -> tiles " + chart.count);

        int holds = 0, maxDur = 0, minDur = Integer.MAX_VALUE;
        int[] laneCount = new int[12];
        for (int i = 0; i < chart.count; i++) {
            laneCount[chart.lane[i]]++;
            if (chart.kind[i] == ChartData.KIND_HOLD) {
                holds++;
                maxDur = Math.max(maxDur, chart.durationMs[i]);
                minDur = Math.min(minDur, chart.durationMs[i]);
            }
        }
        check(!hasEmptyLane(laneCount), name + " m" + mode + ": every lane used " + java.util.Arrays.toString(laneCount));

        System.out.printf("%-8s mode=%d  raw=%-8d tiles=%-8d holds=%-6d holdLen=%d..%d ms  %6d ms parse  %5d notes/s%n",
                name, mode, stats.noteOnCount, chart.count, holds,
                holds == 0 ? 0 : minDur, maxDur, ms, stats.notesPerSecond());
        System.out.printf("         %s%n", mapper.describe());
        System.out.printf("         tempoChanges=%d trackCount=%d bpm=%.0f length=%.1f s  memory=%.1f MB%n",
                stats.tempoChanges, stats.trackCount, stats.initialBpm, stats.lengthMs / 1000.0,
                chart.memoryBytes() / 1048576.0);

        if (name.equals("twinkle") && mode == 0) {
            check(holds > 0, "twinkle: the doubled notes produced hold tiles");
        }
        if (name.equals("storm") && mode == 0) {
            check(chart.count < stats.noteOnCount,
                    "storm: collapse reduced " + stats.noteOnCount + " -> " + chart.count + " playable tiles");
        }
        System.gc();
    }

    private static void binarySearchInvariants(File f) throws Exception {
        GameConfig cfg = new GameConfig();
        cfg.collapseMs = 0;
        byte[] bytes = Files.readAllBytes(f.toPath());
        ChartData chart = new ChartData();
        MidiMapper mapper = new MidiMapper();
        MidiParser.parse(new MidiParser.BytesSource(bytes, "storm"), mapper, cfg, chart, null);

        int probes = 0;
        for (long t = 0; t < chart.lengthMs; t += 137) {          // prime stride: avoids aligning with note times
            int lb = chart.lowerBound(t);
            int ub = chart.upperBound(t);
            if (lb > ub) fail("lowerBound > upperBound at " + t);
            if (lb > 0 && chart.startMs[lb - 1] >= t) fail("lowerBound not minimal at " + t);
            if (lb < chart.count && chart.startMs[lb] < t) fail("lowerBound not a bound at " + t);
            if (ub > 0 && chart.startMs[ub - 1] > t) fail("upperBound not a bound at " + t);
            if (ub < chart.count && chart.startMs[ub] <= t) fail("upperBound not minimal at " + t);

            // The render window must contain every note that could be visible.
            int windowStart = chart.renderWindowStart(t, Math.min(chart.maxDurationMs(), GameConfig.MAX_EXPECTED_HOLD_MS));
            int firstPossiblyVisible = lb;
            if (windowStart > firstPossiblyVisible) fail("render window misses notes at " + t);
            probes++;
        }
        checks++;
        System.out.println("binary search: " + probes + " probes on a " + chart.count + "-tile chart, all invariants hold");
    }

    /**
     * Renderer geometry check.
     *
     * <p>For a spread of song times, scroll speeds, hit-line positions and surface sizes, this
     * computes the note window the renderer would fetch and compares it against a brute-force scan
     * of EVERY note in the chart. The invariant: the window must contain every tile that would be
     * visible, and (because the renderer then filters per tile) iterating the window must yield
     * exactly the brute-force visible count — no missing tiles, no phantom ones.
     *
     * <p>Specifically this catches a sign error in the time↔pixel mapping, which is what shipped in
     * v1.0.2: notes that had not reached the hit line yet were never fetched, so the falling area of
     * the board stayed empty while the rest of the game looked fine.
     */
    private static void renderWindowInvariants(File f, String name) throws Exception {
        GameConfig cfg = new GameConfig();
        cfg.collapseMs = 45;
        byte[] bytes = Files.readAllBytes(f.toPath());
        ChartData chart = new ChartData();
        MidiMapper mapper = new MidiMapper();
        MidiParser.parse(new MidiParser.BytesSource(bytes, name), mapper, cfg, chart, null);

        final int surfaceW = 1920, surfaceH = 1080;
        final float laneW = surfaceW / 12f;
        final float tileH = Math.max(6f, laneW * 0.55f);
        final int maxHoldMs = chart.maxDurationMs();
        ScrollWindow.Bounds bounds = new ScrollWindow.Bounds();

        int[] scrolls = { 400, 600, 900, 1500, 2400 };
        float[] hitFracs = { 0.70f, 0.86f, 0.95f };
        long probes = 0, mismatches = 0, worstMissing = 0, visibleTotal = 0;
        long windowTotal = 0;

        for (int scroll : scrolls) {
            for (float frac : hitFracs) {
                final float hitY = surfaceH * frac;
                final float pxPerMs = hitY / scroll;
                // 120 probes spread across the whole chart, including the count-in (negative times).
                final int steps = 120;
                for (int k = 0; k <= steps; k++) {
                    final double songMs = -scroll + (chart.lengthMs + scroll) * (double) k / steps;

                    ScrollWindow.compute(chart, songMs, hitY, pxPerMs, surfaceH, maxHoldMs, tileH, bounds);
                    final int i0 = bounds.first;
                    final int i1 = bounds.last;

                    int bruteVisible = 0;      // every note in the chart, visibility from geometry
                    int inWindowVisible = 0;   // what the renderer would actually draw
                    for (int i = 0; i < chart.count; i++) {
                        float yHead = ScrollWindow.yForTime(chart.startMs[i], songMs, hitY, pxPerMs);
                        float h = chart.kind[i] == ChartData.KIND_HOLD
                                ? Math.max(GameConfig.MIN_HOLD_MS, chart.durationMs[i]) * pxPerMs
                                : tileH;
                        float yTail = yHead - h;
                        if (!ScrollWindow.isVisible(yHead, yTail, surfaceH)) continue;
                        bruteVisible++;
                        if (i >= i0 && i < i1) inWindowVisible++;
                    }

                    probes++;
                    visibleTotal += bruteVisible;
                    windowTotal += Math.max(0, i1 - i0);
                    if (inWindowVisible != bruteVisible) {
                        mismatches++;
                        int missing = bruteVisible - inWindowVisible;
                        if (missing > worstMissing) worstMissing = missing;
                    }
                }
            }
        }

        check(mismatches == 0 && probes > 0,
                name + ": render window shows every visible tile in all " + probes + " geometry probes"
                        + (mismatches > 0 ? " (" + mismatches + " probes wrong, up to " + worstMissing + " tiles missing)" : ""));
        // Sanity on the other side: the window should not be wildly larger than what is drawn.
        double waste = windowTotal / (double) Math.max(1, visibleTotal);
        check(waste < 6.0,
                String.format(java.util.Locale.US, "%s: window is %.1fx the drawn tile count (long holds explain >1)", name, waste));
        checks++;
        System.out.printf("  --  %s: %d probes, avg %.0f tiles drawn/frame, window/drawn ratio %.2f%n",
                name, probes, visibleTotal / (double) probes, waste);
    }

    private static void benchBlackMidi() {
        System.out.println();
        System.out.println("-- 2,000,000-note procedural tier --");
        GameConfig cfg = new GameConfig();
        long t0 = System.currentTimeMillis();
        ChartData chart = ChartGenerator.blackMidi(cfg, null);
        long ms = System.currentTimeMillis() - t0;

        check(chart.noteOnCount == 2_000_000, "blackmidi: " + chart.noteOnCount + " raw note-ons generated");
        check(chart.count > 20_000 && chart.count < 400_000,
                "blackmidi: collapse folded it into " + chart.count + " playable tiles");
        check(chart.lengthMs > 240_000 && chart.lengthMs < 1_200_000,
                String.format(java.util.Locale.US, "blackmidi: length %.1f min (a sane song, not an 8-hour one)",
                        chart.lengthMs / 60000.0));
        check(chart.count * 8L + chart.count * 5L < 40_000_000L,
                "blackmidi: chart arrays fit in ~" + (chart.memoryBytes() / 1048576) + " MB");
        check(isSorted(chart), "blackmidi: ascending without needing the radix sort");

        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
        System.out.printf("generated %,d raw notes -> %,d tiles in %,d ms  (%.1f M notes/s)  held heap %.0f MB%n",
                chart.noteOnCount, chart.count, ms, chart.noteOnCount / (ms / 1000.0) / 1e6, (double) used);
        System.out.printf("chart length %.1f min, raw %.0f notes/sec, %,d tiles/sec, difficulty %d/12%n",
                chart.lengthMs / 60000.0, chart.noteOnCount * 1000.0 / Math.max(1, chart.lengthMs),
                (int) (chart.count * 1000L / Math.max(1, chart.lengthMs)), chart.difficultyRating);

        // Simulate the renderer's per-frame window query at 200 Hz across the whole chart: this is
        // the actual per-frame cost the render thread pays, measured at scale.
        final int maxTail = Math.min(chart.maxDurationMs(), GameConfig.MAX_EXPECTED_HOLD_MS);
        long t1 = System.nanoTime();
        long tilesSeen = 0;
        int frames = 0;
        for (long now = 0; now < chart.lengthMs; now += 5) {           // 200 Hz
            int i0 = chart.renderWindowStart(now - 900, maxTail);
            int i1 = chart.upperBound(now + 200);
            tilesSeen += Math.max(0, i1 - i0);
            frames++;
        }
        long us = (System.nanoTime() - t1) / 1000L;
        System.out.printf("render-window queries: %,d frames, avg %,.0f tiles/frame, %.2f us/frame%n",
                frames, tilesSeen / (double) frames, us / (double) frames);
        chart.close();
    }

    // ---------------------------------------------------------------- helpers
    private static boolean isSorted(ChartData c) {
        for (int i = 1; i < c.count; i++) if (c.startMs[i] < c.startMs[i - 1]) return false;
        return true;
    }

    private static boolean hasOverlapInsideWindow(ChartData c, int windowMs) {
        // NOTE: the sentinel must not be Long.MIN_VALUE — "t - Long.MIN_VALUE" overflows and the
        // comparison then reports a phantom overlap for the first note of every lane. (The app had
        // exactly this bug; this check exists to catch regressions of it.)
        final long never = Long.MIN_VALUE / 4;
        long[] last = new long[12];
        java.util.Arrays.fill(last, never);
        for (int i = 0; i < c.count; i++) {
            int l = c.lane[i];
            if (c.startMs[i] - last[l] < windowMs) return true;
            last[l] = c.startMs[i];
        }
        return false;
    }

    private static boolean hasEmptyLane(int[] counts) {
        // A chart legitimately may not use every lane (Twinkle is C major, so a few lanes stay empty
        // in pitch-class mode). Only fail when the chart is silent overall.
        int total = 0;
        for (int c : counts) total += c;
        return total == 0;
    }

    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) { failures++; System.out.println("  FAIL  " + message); }
        else System.out.println("  ok    " + message);
    }

    private static void fail(String message) {
        checks++;
        failures++;
        System.out.println("  FAIL  " + message);
    }
}
