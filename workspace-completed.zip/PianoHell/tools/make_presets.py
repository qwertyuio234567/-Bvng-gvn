#!/usr/bin/env python3
"""
make_presets.py — generates the bundled preset charts for Piano Hell.

Why generate them instead of shipping hand-made files: the presets have to exercise the importer
(the parser, the tempo map, the note pairing, the same-lane collapse), so they are written to be
slightly nasty on purpose:

  * running status is used for most note-on events (like real black-MIDI generators do),
  * tempo changes in the middle of the file (the tempo map must actually be used),
  * notes that overlap on the same pitch (the parser must pair them with a LIFO stack),
  * long sustain pedals next to staccato runs (hold tiles near tap tiles),
  * and one chart with raw note density far above what 12 lanes can carry, so the importer's
    collapse step has something real to chew on.

Output: app/src/main/assets/presets/*.mid  (Standard MIDI File, format 1)

Usage:  python3 tools/make_presets.py
"""

import os
import random
import struct

TPQ = 480                      # ticks per quarter note
OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "..", "app", "src", "main", "assets", "presets")


# ----------------------------------------------------------------------------- MIDI writing
class Track:
    """A single MTrk. Events are appended as (tick, bytes) and sorted on export."""

    def __init__(self):
        self.events = []        # (tick, order, bytes)
        self.order = 0

    def _add(self, tick, data):
        self.events.append((int(tick), self.order, bytes(data)))
        self.order += 1

    def tempo(self, tick, bpm):
        us = int(round(60_000_000 / bpm))
        self._add(tick, [0xFF, 0x51, 0x03, (us >> 16) & 0xFF, (us >> 8) & 0xFF, us & 0xFF])

    def note_on(self, tick, note, vel, ch=0):
        self._add(tick, [0x90 | ch, note & 0x7F, max(1, min(127, vel))])

    def note_off(self, tick, note, ch=0):
        self._add(tick, [0x80 | ch, note & 0x7F, 0x40])

    def control(self, tick, cc, value, ch=0):
        self._add(tick, [0xB0 | ch, cc & 0x7F, value & 0x7F])

    def program(self, tick, program, ch=0):
        self._add(tick, [0xC0 | ch, program & 0x7F])

    def note(self, start, dur, note, vel=100, ch=0):
        self.note_on(start, note, vel, ch)
        self.note_off(start + max(1, dur), note, ch)

    def export(self, running_status=True):
        """Serialize with delta times. running_status exercises the parser's running-status path."""
        body = bytearray()
        last_tick = 0
        last_status = None
        for tick, _order, data in sorted(self.events, key=lambda e: (e[0], e[1])):
            delta = tick - last_tick
            last_tick = tick
            body += vlq(delta)

            if data[0] == 0xFF or data[0] == 0xF0 or data[0] == 0xF7:
                body += data                      # meta / sysex: status is always written
                last_status = None
                continue

            status = data[0]
            if running_status and status == last_status and status < 0xF0:
                body += data[1:]                  # running status: omit the status byte entirely
            else:
                body += data
            last_status = status
        body += vlq(0) + bytes([0xFF, 0x2F, 0x00])          # end of track
        return bytes(body)


def vlq(value):
    """MIDI variable-length quantity."""
    if value < 0:
        value = 0
    out = bytearray([value & 0x7F])
    value >>= 7
    while value:
        out.insert(0, (value & 0x7F) | 0x80)
        value >>= 7
    return bytes(out)


def write_midi(path, track, bpm=120, tempo_changes=()):
    """Writes a format-1 file with a single MTrk. tempo_changes: iterable of (tick, bpm)."""
    if not tempo_changes:
        track.tempo(0, bpm)
    else:
        for tick, b in tempo_changes:
            track.tempo(tick, b)

    tracks = [track]
    chunks = b""
    for t in tracks:
        data = t.export()
        chunks += b"MTrk" + struct.pack(">I", len(data)) + data

    header = b"MThd" + struct.pack(">IHHH", 6, 1, len(tracks), TPQ)
    with open(path, "wb") as f:
        f.write(header + chunks)
    return os.path.getsize(path)


# ----------------------------------------------------------------------------- the charts
def twinkle():
    """Tier 1: a melody everyone can sight-read, with a rest or two. ~220 raw note-ons."""
    t = Track()
    beats = [
        ("C4", 1), ("C4", 1), ("G4", 1), ("G4", 1), ("A4", 1), ("A4", 1), ("G4", 2),
        ("F4", 1), ("F4", 1), ("E4", 1), ("E4", 1), ("D4", 1), ("D4", 1), ("C4", 2),
        ("G4", 1), ("G4", 1), ("F4", 1), ("F4", 1), ("E4", 1), ("E4", 1), ("D4", 2),
        ("G4", 1), ("G4", 1), ("F4", 1), ("F4", 1), ("E4", 1), ("E4", 1), ("D4", 2),
        ("C4", 1), ("C4", 1), ("G4", 1), ("G4", 1), ("A4", 1), ("A4", 1), ("G4", 2),
        ("F4", 1), ("F4", 1), ("E4", 1), ("E4", 1), ("D4", 1), ("D4", 1), ("C4", 2),
    ]
    names = {"C4": 60, "D4": 62, "E4": 64, "F4": 65, "G4": 67, "A4": 69}
    tick = 0
    for name, beats_long in beats:
        n = names[name]
        # melody + a soft octave-down doubling: same-lane duplicates a few ms apart on purpose,
        # which the importer's collapse pass is expected to fold into single tiles.
        t.note(tick, int(TPQ * beats_long * 0.9), n, 105, 0)
        t.note(tick + 6, int(TPQ * beats_long * 0.8), n - 12, 70, 1)
        tick += int(TPQ * beats_long)
    return t, (), 108, sum(1 for e in t.events if e[2][0] & 0xF0 == 0x90)


def canon():
    """Tier 2: Pachelbel in D, arpeggios over two-bar bass pedals (long holds). ~1,500 notes."""
    t = Track()
    prog = [(50, "D"), (45, "A"), (47, "B"), (42, "F#"), (43, "G"), (38, "D"), (43, "G"), (45, "A")]
    tick = 0
    eighth = TPQ // 2
    rng = random.Random(7)
    for variation in range(12):                     # 12 passes = ~96 bars
        for root, _name in prog:
            # bass pedal: a 3-second hold, the thing hold-judgment is for
            t.note(tick, TPQ * 4, root - 12, 90, 0)
            # arpeggio in eighths climbing two octaves
            for k in range(8):
                deg = [0, 4, 7, 12, 16, 19, 24, 19][k]
                vel = 70 + (k % 4) * 12 + (variation % 3) * 4
                t.note(tick + k * eighth, eighth - 8, root + deg + (12 if variation > 5 else 0), vel, 1)
            # every fourth bar add a quick turn figure (16ths) for a small difficulty spike
            if variation % 4 == 3:
                for k in range(4):
                    t.note(tick + TPQ * 3 + k * (TPQ // 4), TPQ // 4 - 6,
                           root + [0, 2, 4, 2][k], 110, 2)
            tick += TPQ * 4
    return t, (), 96, sum(1 for e in t.events if e[2][0] & 0xF0 == 0x90)


def cascade():
    """Tier 3: chromatic runs handed between the hands, 16ths at 160 BPM. ~9,000 notes."""
    t = Track()
    tick = 0
    sixteenth = TPQ // 4
    lo, hi = 36, 84
    rng = random.Random(99)
    for bar in range(400):
        direction = 1 if bar % 2 == 0 else -1
        start = lo if direction > 0 else hi
        for k in range(16):
            n = start + direction * k
            t.note(tick, sixteenth - 4, n, 95 + (k % 3) * 8, 0)
            if k % 4 == 3:                                  # accented chord on every beat
                for extra in (4, 7):
                    t.note(tick, sixteenth - 4, n + extra, 80, 1)
            tick += sixteenth
        # occasional same-lane stack (3 notes within ~10 ms) — the collapse pass must tame this
        if bar % 7 == 3:
            lane_note = 48 + rng.randrange(0, 12)
            for k in range(3):
                t.note(tick, 60, lane_note, 100, 2)
                tick += 2
    return t, (), 160, sum(1 for e in t.events if e[2][0] & 0xF0 == 0x90)


def storm():
    """Tier 4: 64th-note cluster chords at 200 BPM with tempo drift. ~120,000 raw note-ons, which
    the 12-lane board cannot possibly represent 1:1 — this is the chart that proves the collapse
    step and the flat-array pipeline (a real black-MIDI file in miniature)."""
    t = Track()
    tick = 0
    grid = TPQ // 16                                    # 64th notes
    rng = random.Random(4242)
    bpm_changes = []
    raw = 0
    bars = 256
    for bar in range(bars):
        if bar % 16 == 8:
            # tempo event in the middle of the file: the parser's tempo map must handle it
            bpm_changes.append((tick, 200 if bar % 32 == 8 else 160))
        cluster = 36 + (bar % 9) * 6
        for step in range(16):
            for k in range(cluster):
                n = 24 + rng.randrange(0, 60)
                vel = 60 + rng.randrange(0, 65)
                dur = 0 if rng.random() < 0.8 else rng.randrange(TPQ // 4, TPQ * 2)
                t.note(tick, dur, n, vel, rng.randrange(0, 8))
                raw += 1
            tick += grid
        # sweeping glissando up and back: 12 notes, one per lane, every other bar
        if bar % 2 == 0:
            for k in range(12):
                t.note(tick + k, 40, 48 + k, 110, 1)
                raw += 1
    return t, bpm_changes, 200, raw


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    for name, fn in (("twinkle", twinkle), ("canon", canon), ("cascade", cascade), ("storm", storm)):
        track, changes, bpm, notes = fn()
        path = os.path.join(OUT_DIR, name + ".mid")
        size = write_midi(path, track, bpm=bpm, tempo_changes=changes)
        print(f"{name:8s} {notes:>8,} note-ons   {size/1024:8.1f} KiB   -> {os.path.relpath(path)}")


if __name__ == "__main__":
    main()
