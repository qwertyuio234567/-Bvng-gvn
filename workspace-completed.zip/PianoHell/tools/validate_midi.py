#!/usr/bin/env python3
"""Independent sanity check for the generated presets: re-reads the SMF byte stream
(including running status) and reports event counts, so we know the parser under test
is reading a legal file. Deliberately a separate implementation from make_presets.py."""
import sys, struct, os

def vlq(buf, i):
    v = 0
    while True:
        b = buf[i]; i += 1
        v = (v << 7) | (b & 0x7F)
        if not (b & 0x80): return v, i

def scan(path):
    buf = open(path, 'rb').read()
    assert buf[0:4] == b'MThd', "bad header"
    hlen = struct.unpack('>I', buf[4:8])[0]
    fmt, ntrk, div = struct.unpack('>HHH', buf[8:14])
    i = 8 + hlen
    total_on = total_off = tempos = 0
    channels, pitches, maxtick, events = set(), set(), 0, 0
    for _ in range(ntrk):
        assert buf[i:i+4] == b'MTrk', "bad track chunk at %d" % i
        tlen = struct.unpack('>I', buf[i+4:i+8])[0]
        j = i + 8
        end = j + tlen
        tick = 0
        status = 0
        while j < end:
            d, j = vlq(buf, j)
            tick += d
            maxtick = max(maxtick, tick)
            b = buf[j]
            if b & 0x80: status = b; j += 1
            if status == 0xFF:
                mtype = buf[j]; j += 1
                ml, j = vlq(buf, j)
                if mtype == 0x51: tempos += 1
                if mtype == 0x2F: j += ml; break
                j += ml; status = 0; events += 1; continue
            elif status in (0xF0, 0xF7):
                ml, j = vlq(buf, j); j += ml; status = 0; continue
            hi = status & 0xF0
            n = 2 if hi in (0x80, 0x90, 0xA0, 0xB0, 0xE0) else 1
            data = buf[j:j+n]; j += n
            events += 1
            if hi == 0x90 and data[1] != 0:
                total_on += 1; channels.add(status & 15); pitches.add(data[0])
            elif hi == 0x80 or (hi == 0x90 and data[1] == 0):
                total_off += 1
        i = end
    return dict(format=fmt, tracks=ntrk, division=div, note_on=total_on, note_off=total_off,
                tempos=tempos, channels=sorted(channels), pitches=len(pitches),
                last_tick=maxtick, events=events, bytes=len(buf))

if __name__ == '__main__':
    d = sys.argv[1] if len(sys.argv) > 1 else 'app/src/main/assets/presets'
    for f in sorted(os.listdir(d)):
        if f.endswith('.mid'):
            r = scan(os.path.join(d, f))
            print(f"{f:12s} fmt={r['format']} trk={r['tracks']} div={r['division']} "
                  f"on={r['note_on']:>7,} off={r['note_off']:>7,} tempos={r['tempos']} "
                  f"ch={r['channels']} distinct_pitches={r['pitches']:>3} "
                  f"bars={(r['last_tick']/r['division']/4):.0f} {r['bytes']/1024:.0f}KiB")
