#!/usr/bin/env python3
"""
check_view_types.py — catches the silent Android trap that took the game screen down.

`Activity.findViewById` is declared `public final <T extends View> T findViewById(int id)`, so

    private Button btnPause;                 // layout actually declares a TextView
    btnPause = findViewById(R.id.btnPause);  // compiles! T is inferred as Button

compiles happily and then throws at RUNTIME:

    java.lang.ClassCastException: android.widget.TextView cannot be cast to android.widget.Button

...buried inside onCreate, where Android surfaces it as the famously unhelpful
"Unable to start activity ComponentInfo{...}: java.lang.ClassCastException". No compiler warning,
no lint error, no logcat without a cable. This script compares every findViewById assignment
against the class actually declared in the layout, using the real widget hierarchy, and fails loudly.

Usage:  python3 tools/check_view_types.py            (exit 1 on any mismatch)
"""

import os
import re
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES_LAYOUT = os.path.join(ROOT, "app", "src", "main", "res", "layout")
JAVA_DIR = os.path.join(ROOT, "app", "src", "main", "java", "com", "pianohell")
ANDROID_JAR_ORDER = None  # not needed: hierarchy is declared below

# ---------------------------------------------------------------- widget hierarchy
# parents[class] = its superclass. Only the classes this app (or its layouts) actually uses.
PARENTS = {
    "java.lang.Object": None,
    "android.view.View": "java.lang.Object",
    "android.view.ViewGroup": "android.view.View",
    "android.view.SurfaceView": "android.view.View",
    "android.widget.TextView": "android.view.View",
    "android.widget.Button": "android.widget.TextView",
    "android.widget.CompoundButton": "android.widget.Button",
    "android.widget.CheckBox": "android.widget.CompoundButton",
    "android.widget.Switch": "android.widget.CompoundButton",
    "android.widget.ToggleButton": "android.widget.CompoundButton",
    "android.widget.EditText": "android.widget.TextView",
    "android.widget.ImageView": "android.view.View",
    "android.widget.ImageButton": "android.widget.ImageView",
    "android.widget.ProgressBar": "android.view.View",
    "android.widget.SeekBar": "android.widget.ProgressBar",
    "android.widget.RatingBar": "android.widget.ProgressBar",
    "android.widget.Space": "android.view.View",
    "android.widget.LinearLayout": "android.view.ViewGroup",
    "android.widget.FrameLayout": "android.view.ViewGroup",
    "android.widget.RelativeLayout": "android.view.ViewGroup",
    "android.widget.TableLayout": "android.widget.LinearLayout",
    "android.widget.TableRow": "android.widget.LinearLayout",
    "android.widget.ScrollView": "android.widget.FrameLayout",
    "android.widget.HorizontalScrollView": "android.widget.FrameLayout",
    "android.widget.AdapterView": "android.view.ViewGroup",
    "android.widget.AbsSpinner": "android.widget.AdapterView",
    "android.widget.Spinner": "android.widget.AbsSpinner",
    "android.widget.ListView": "android.widget.AdapterView",
    "android.widget.GridView": "android.widget.AdapterView",
    "android.widget.Toolbar": "android.view.ViewGroup",
    "androidx.recyclerview.widget.RecyclerView": "android.view.ViewGroup",
    "android.view.TextureView": "android.view.View",
}


def short(name):
    """com.pianohell.GameView -> GameView ; android.widget.TextView -> TextView"""
    if name is None:
        return None
    return name.rsplit(".", 1)[-1]


def resolve(name):
    """Map a layout tag / java type to a canonical key in PARENTS."""
    n = short(name)
    for k in PARENTS:
        if short(k) == n:
            return k
    return None


def is_a(child, parent):
    """True if `child` is `parent` or a subclass of it. Unknown types return None."""
    c = resolve(child)
    p = resolve(parent)
    if c is None or p is None:
        return None
    seen = set()
    while c is not None and c not in seen:
        if c == p:
            return True
        seen.add(c)
        c = PARENTS.get(c)
    return False


# ---------------------------------------------------------------- layouts
def read_layouts():
    """id -> (tag, file)"""
    ids = {}
    for fn in sorted(os.listdir(RES_LAYOUT)):
        if not fn.endswith(".xml"):
            continue
        tree = ET.parse(os.path.join(RES_LAYOUT, fn))
        for el in tree.iter():
            if el.tag == "include":          # <include layout="@layout/..." android:id="..."/>
                continue
            for k, v in el.attrib.items():
                if k.endswith("}id") or k == "android:id":
                    m = re.match(r"@\+?id/(\w+)", v)
                    if m:
                        ids[m.group(1)] = (el.tag, fn)
    return ids


# ---------------------------------------------------------------- java
CLASS_DECL = re.compile(r"\bclass\s+(\w+)\s*(?:extends\s+([\w.]+))?\s*(?:implements\s+[\w.,\s]+)?\{")
FIELD_DECL = re.compile(r"^\s*(?:private|public|protected|final|static|\s)*([A-Z]\w*)\s+([\w,\s]+);")
FINDBYID_ASSIGN = re.compile(r"\b(\w+)\s*=\s*findViewById\(\s*R\.id\.(\w+)\s*\)")
FINDBYID_DECL = re.compile(r"\b([A-Z]\w*)\s+(\w+)\s*=\s*findViewById\(\s*R\.id\.(\w+)\s*\)")


def read_java():
    """returns (id->type map with tags, class hierarchy from Java, field types, assignments)"""
    java_parents = {}
    fields = {}          # var name -> declared type (best effort, file-scoped)
    assigns = []         # (java file, line no, type_hint or None, var name, r_id)

    for fn in sorted(os.listdir(JAVA_DIR)):
        if not fn.endswith(".java"):
            continue
        path = os.path.join(JAVA_DIR, fn)
        src = open(path, encoding="utf-8").read()

        for m in CLASS_DECL.finditer(src):
            cls, ext = m.group(1), m.group(2)
            if ext:
                java_parents[cls] = short(ext)

        for i, line in enumerate(src.split("\n"), 1):
            m = FIELD_DECL.match(line)
            if m:
                typ, names = m.group(1), m.group(2)
                for n in names.split(","):
                    n = n.strip().split("=")[0].strip()
                    if n:
                        fields[n] = typ
            m = FINDBYID_DECL.search(line)
            if m:
                assigns.append((fn, i, m.group(1), m.group(2), m.group(3)))
                continue
            m = FINDBYID_ASSIGN.search(line)
            if m:
                assigns.append((fn, i, None, m.group(1), m.group(2)))

    # Fold the app's own classes into the hierarchy table (GameView -> SurfaceView, etc.)
    for cls, ext in java_parents.items():
        if cls not in PARENTS:
            PARENTS[cls] = resolve(ext) or ext
    return fields, assigns


def main():
    ids = read_layouts()
    fields, assigns = read_java()

    problems, unknown, checked = [], [], 0
    for fn, line_no, decl_type, var, r_id in assigns:
        if r_id not in ids:
            problems.append(f"{fn}:{line_no}  R.id.{r_id} has no view with that id in any layout")
            continue
        tag, layout_file = ids[r_id]
        wanted = decl_type or fields.get(var)
        if wanted is None:
            unknown.append(f"{fn}:{line_no}  {var} = findViewById(R.id.{r_id})  (unknown declared type)")
            continue
        checked += 1
        ok = is_a(tag, wanted)
        if ok is False:
            problems.append(
                f"{fn}:{line_no}  {wanted} {var} = findViewById(R.id.{r_id})  "
                f"but {layout_file} declares <{short(tag)}>  ->  java.lang.ClassCastException at runtime")
        elif ok is None:
            unknown.append(f"{fn}:{line_no}  cannot verify {wanted} vs <{short(tag)}> (unknown class)")

    print(f"findViewById type check: {checked} assignments verified against {len(ids)} layout ids")
    for u in unknown:
        print("  ?  " + u)
    if problems:
        print()
        for p in problems:
            print("  FAIL  " + p)
        print(f"\n{len(problems)} MISMATCH(ES) — these crash at runtime with ClassCastException")
        return 1
    print("  ok  every findViewById assignment matches the class declared in its layout")
    return 0


if __name__ == "__main__":
    sys.exit(main())
