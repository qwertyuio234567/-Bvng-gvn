#!/usr/bin/env bash
#
# Piano Hell — one-command build.
#
#   bash tools/build.sh              # debug APK
#   bash tools/build.sh --no-daemon  # extra Gradle flags are passed through
#
# Why this script exists (two real problems it solves):
#
#  1. WORKSPACE BUDGET. Gradle's user home defaults to ~/.gradle, which in this project reaches
#     ~500 MB and thousands of files. The workspace snapshot only excludes a fixed list of directory
#     names (.cache, .local, build, node_modules, …), and ~/.gradle is not on that list — so a build
#     once pushed the session 517 MB / 2,446 files over the 128 MB / 10,000-file limit and 2,282
#     cache files were dropped. Nothing important was lost (build caches are regenerable), but every
#     build now redirects ALL of it:
#         GRADLE_USER_HOME  -> /home/user/.cache/gradle     (excluded from snapshots)
#     plus the NDK staging directory is moved inside app/build/ (see app/build.gradle), which is
#     excluded by name. Net effect: a full native build leaves ~0 bytes of snapshot footprint.
#
#  2. TOOLCHAIN. The JDK/SDK/NDK live in ~/.local, which is also excluded (it is 3+ GB), so a fresh
#     sandbox has no toolchain at all. This script bootstraps it on demand instead of failing with
#     "JAVA_HOME is set to an invalid directory".
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
WORKSPACE="${WORKSPACE:-/home/user}"

export GRADLE_USER_HOME="${GRADLE_USER_HOME:-$WORKSPACE/.cache/gradle}"
export JAVA_HOME="${JAVA_HOME:-$WORKSPACE/.local/jdk17}"
export ANDROID_HOME="${ANDROID_HOME:-$WORKSPACE/.local/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
mkdir -p "$GRADLE_USER_HOME"

if [ ! -x "$JAVA_HOME/bin/java" ] || [ ! -d "$ANDROID_HOME/ndk" ]; then
  echo "== toolchain missing (JDK 17 / Android SDK+NDK) — bootstrapping, ~2-3 min =="
  bash "$ROOT/tools/setup-toolchain.sh"
  export JAVA_HOME="$WORKSPACE/.local/jdk17"
  export ANDROID_HOME="$WORKSPACE/.local/android-sdk"
  export ANDROID_SDK_ROOT="$ANDROID_HOME"
fi

cd "$ROOT"
echo "sdk.dir=$ANDROID_HOME" > local.properties
chmod +x ./gradlew

echo "== building =="
./gradlew :app:assembleDebug "$@"

APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
OUT="$WORKSPACE/PianoHell-debug.apk"
cp "$APK" "$OUT"

echo
echo "== done =="
"$ANDROID_HOME/build-tools/34.0.0/aapt2" dump badging "$OUT" 2>/dev/null | head -1 || true
ls -la "$OUT"
echo
echo "workspace snapshot footprint:"
du -sh --exclude=.cache --exclude=.local --exclude=build --exclude=.gradle "$WORKSPACE" 2>/dev/null | tail -1
