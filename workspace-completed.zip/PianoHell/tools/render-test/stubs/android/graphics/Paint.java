package android.graphics;
public class Paint { public static final int ANTI_ALIAS_FLAG=1; public enum Align{LEFT,CENTER,RIGHT}
 public int color=0xFFFFFFFF; public float size=12; public Align align=Align.LEFT; public boolean bold;
 public Paint(){} public Paint(int f){}
 public void setColor(int c){color=c;} public void setTextSize(float s){size=s;} public void setFakeBoldText(boolean b){bold=b;}
 public void setShadowLayer(float r,float dx,float dy,int c){}
 public float measureText(String s){ java.awt.image.BufferedImage i=new java.awt.image.BufferedImage(1,1,2); java.awt.Graphics2D g=i.createGraphics(); g.setFont(new java.awt.Font("SansSerif", bold?java.awt.Font.BOLD:java.awt.Font.PLAIN,Math.max(1,(int)size))); return g.getFontMetrics().stringWidth(s);}
 public void setTextAlign(Align a){align=a;} }
