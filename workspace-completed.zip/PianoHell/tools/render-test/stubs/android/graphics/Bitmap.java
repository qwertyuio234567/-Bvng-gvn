package android.graphics;
public class Bitmap { public enum Config{ARGB_8888} public int w,h; public int[] px;
 public static Bitmap createBitmap(int w,int h,Config c){Bitmap b=new Bitmap();b.w=w;b.h=h;b.px=new int[w*h];return b;}
 public void setPixels(int[] p,int off,int stride,int x,int y,int w,int h){System.arraycopy(p,0,px,0,Math.min(p.length,px.length));}
 public void recycle(){} }
