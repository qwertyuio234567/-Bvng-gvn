package android.graphics;
import java.awt.*; import java.awt.image.BufferedImage;
public class Canvas { public Bitmap out; public BufferedImage img; public int texts;
 public void drawBitmap(Bitmap b,Rect s,Rect d,Paint p){ out=b; img=new BufferedImage(b.w,b.h,BufferedImage.TYPE_INT_ARGB); img.setRGB(0,0,b.w,b.h,b.px,0,b.w); }
 public void drawText(String t,float x,float y,Paint p){ texts++; if(img==null)return; Graphics2D g=img.createGraphics(); g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
   g.setFont(new Font("SansSerif", p.bold?Font.BOLD:Font.PLAIN,Math.max(1,(int)p.size))); int w=g.getFontMetrics().stringWidth(t); float xx=x; if(p.align==Paint.Align.CENTER) xx=x-w/2f; else if(p.align==Paint.Align.RIGHT) xx=x-w;
   g.setColor(new java.awt.Color(0,0,0,150)); g.drawString(t,xx+1.5f,y+2); g.setColor(new java.awt.Color(p.color,true)); g.drawString(t,xx,y); g.dispose(); }
 public void drawRect(float l,float t,float r,float b,Paint p){ if(img==null)return; Graphics2D g=img.createGraphics(); g.setColor(new java.awt.Color(p.color,true)); g.fillRect((int)l,(int)t,(int)(r-l),(int)(b-t)); g.dispose(); } }
