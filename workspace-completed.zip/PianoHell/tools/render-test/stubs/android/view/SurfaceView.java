package android.view; import android.content.Context; import android.util.AttributeSet; import android.graphics.Canvas;
public class SurfaceView { public int W=1280,H=736; public static Canvas last;
 public SurfaceView(Context c,AttributeSet a){}
 public SurfaceHolder getHolder(){ return new SurfaceHolder(){ public void addCallback(Callback c){} public Canvas lockCanvas(){ return new Canvas(); } public void unlockCanvasAndPost(Canvas c){ last=c; } }; }
 public int getWidth(){return W;} public int getHeight(){return H;}
 public void setFocusable(boolean b){} public void setFocusableInTouchMode(boolean b){} public boolean performClick(){return true;} public boolean onTouchEvent(MotionEvent e){return true;} }
