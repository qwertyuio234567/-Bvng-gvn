package android.view; import android.graphics.Canvas;
public interface SurfaceHolder { interface Callback{ void surfaceCreated(SurfaceHolder h); void surfaceChanged(SurfaceHolder h,int f,int w,int hh); void surfaceDestroyed(SurfaceHolder h);} void addCallback(Callback c); Canvas lockCanvas(); void unlockCanvasAndPost(Canvas c); }
