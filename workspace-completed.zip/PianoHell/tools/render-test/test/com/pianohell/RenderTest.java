package com.pianohell;

import java.lang.reflect.*;
import java.nio.file.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;

public class RenderTest {
    static ChartData load(String name, GameConfig cfg, MidiMapper mapper) throws Exception {
        byte[] data = Files.readAllBytes(Paths.get("" + System.getProperty("ph.presets", "app/src/main/assets/presets") + "/" + name + ".mid"));
        ChartData chart = new ChartData();
        chart.themeIndex = 0;
        MidiParser.parse(new MidiParser.BytesSource(data, name), mapper, cfg, chart, new MidiParser.Listener() {
            public void onProgress(int p, long n, String s) {}
            public boolean isCancelled() { return false; }
        });
        return chart;
    }
    static void setD(Object o, String f, double v) throws Exception { Field x = o.getClass().getDeclaredField(f); x.setAccessible(true); x.setDouble(o, v); }

    public static void main(String[] args) throws Exception {
        String preset = args.length > 0 ? args[0] : "canon";
        double jumpTo = args.length > 1 ? Double.parseDouble(args[1]) : 12000;
        String png = args.length > 2 ? args[2] : "/home/claude/rt/frame.png";
        GameConfig cfg = new GameConfig();
        MidiMapper mapper = new MidiMapper();
        ChartData chart = load(preset, cfg, mapper);
        System.out.println("chart tiles=" + chart.count);

        // The REAL order on device with an async preset load:
        //   surfaceCreated -> surfaceChanged -> (chart finishes loading) -> bind()
        GameView v = new GameView(null, null);
        v.surfaceCreated(null);
        try { v.surfaceChanged(null, 0, 1280, 736); System.out.println("surfaceChanged before bind: OK, no exception"); }
        catch (Throwable t) { System.out.println("surfaceChanged before bind: THREW " + t); System.exit(1); }
        Thread.sleep(150);                       // render thread idles while no chart is bound

        NotePool pool = new NotePool();
        GameEngine eng = new GameEngine(chart, cfg, pool, null, mapper);
        v.bind(eng, cfg, new NoteColors(0), mapper);
        cfg.suddenDeath = false;
        eng.start();
        eng.pause();                                  // freeze while we arrange the scene (no races)
        setD(eng, "songTimeMs", jumpTo);
        { // skip the miss-sweep over everything before the jump point (we are testing drawing, not scoring)
            Field ec = GameEngine.class.getDeclaredField("expireCursor"); ec.setAccessible(true); ec.setInt(eng, chart.lowerBound((long) jumpTo));
            Field cb = GameEngine.class.getDeclaredField("combo"); cb.setAccessible(true); cb.setInt(eng, 37);
            Field sc = GameEngine.class.getDeclaredField("score"); sc.setAccessible(true); sc.setLong(eng, 184250);
            Field pf = GameEngine.class.getDeclaredField("perfectCount"); pf.setAccessible(true); pf.setInt(eng, 31);
            Field gd = GameEngine.class.getDeclaredField("goodCount"); gd.setAccessible(true); gd.setInt(eng, 6);
            eng.lastJudgmentMs = android.os.SystemClock.uptimeMillis() + 380; eng.lastJudgmentKind = 0; }
        eng.resume();
        // pretend two fingers are on lanes 4 and 7 / just hit
        eng.laneFlash[4] = 1f; eng.laneFlash[7] = 0.6f; eng.laneFlash[0] = 0.3f;
        Thread.sleep(300);
        eng.laneFlash[4] = 1f; eng.laneFlash[7] = 0.6f; eng.laneFlash[0] = 0.3f;
        eng.lastJudgmentMs = android.os.SystemClock.uptimeMillis();
        Thread.sleep(60);
        v.stopRenderThread();

        android.graphics.Canvas last = android.view.SurfaceView.last;
        if (last == null || last.out == null) { System.out.println("FAIL: nothing was ever presented"); System.exit(2); }
        android.graphics.Bitmap b = last.out;
        BufferedImage img = last.img;
        ImageIO.write(img, "png", new File(png));
        System.out.println("presented " + b.w + "x" + b.h + ", songMs=" + (long) eng.getSongTimeMs() + ", active tiles=" + pool.activeCount() + " -> " + png);
    }
}
