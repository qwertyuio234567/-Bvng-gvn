#!/usr/bin/env bash
# Desktop render test: compiles the REAL GameView/GameEngine/etc. against tiny Android stubs and drives
# the real render thread in the real device order (surfaceCreated -> surfaceChanged -> bind).
# Usage: bash tools/render-test/run.sh [preset=canon] [songMs=12000] [out.png]
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; ROOT="$HERE/../.."
SRC="$ROOT/app/src/main/java/com/pianohell"
OUT="$(mktemp -d)"
FILES=""
for f in ChartData MidiParser MidiMapper NoteColors GameConfig Preset ChartGenerator NotePool ScrollWindow GameEngine GameView; do FILES="$FILES $SRC/$f.java"; done
java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d "$OUT" $(find "$HERE/stubs" -name '*.java') $FILES "$HERE/test/com/pianohell/RenderTest.java"
java -Dph.presets="$ROOT/app/src/main/assets/presets" -cp "$OUT" com.pianohell.RenderTest "${1:-canon}" "${2:-12000}" "${3:-/tmp/frame.png}"
