#!/usr/bin/env bash
# Piano Hell — one-shot toolchain bootstrap.
#
# The JDK, Android SDK/NDK and Gradle live OUTSIDE the project (in ~/.local, which is not part of
# the saved workspace), so a fresh machine/sandbox needs this before ./gradlew will work:
#
#     bash tools/setup-toolchain.sh
#     JAVA_HOME=~/.local/jdk17 ANDROID_HOME=~/.local/android-sdk ./gradlew :app:assembleDebug
#
# Versions are pinned to what the project was built with: JDK 17, NDK 26.1.10909125, CMake 3.22.1,
# build-tools 34.0.0, platform android-34, Gradle wrapper 8.7. On a workstation you probably already
# have an SDK — in that case just write sdk.dir into local.properties instead.
set -euo pipefail
mkdir -p /home/user/.local

export JAVA_HOME=/home/user/.local/jdk17
export PATH="$JAVA_HOME/bin:$PATH"
SDK=/home/user/.local/android-sdk
mkdir -p "$SDK/cmdline-tools" /home/user/.local/downloads
cd /home/user/.local/downloads

echo "=== [1/5] JDK 17 (AGP 8 requires 17; the sandbox ships 11) ==="
if [ ! -d /home/user/.local/jdk17 ]; then
  curl -sSL -o /home/user/.local/jdk17.tar.gz \
    "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse"
  tar xzf /home/user/.local/jdk17.tar.gz -C /home/user/.local
  mv /home/user/.local/jdk-17* /home/user/.local/jdk17
  rm -f /home/user/.local/jdk17.tar.gz
fi

echo "=== [2/5] command line tools ==="
if [ ! -d "$SDK/cmdline-tools/latest" ]; then
  curl -sSL -o clt.zip "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
  unzip -q -o clt.zip -d "$SDK/cmdline-tools"
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
fi
export PATH="$SDK/cmdline-tools/latest/bin:$PATH"

echo "=== [3/5] licenses ==="
yes | sdkmanager --sdk_root="$SDK" --licenses >/dev/null 2>&1 || true

echo "=== [4/5] sdk packages (platform 34, build-tools 34, platform-tools, ndk 26) ==="
sdkmanager --sdk_root="$SDK" "platform-tools" "platforms;android-34" "build-tools;34.0.0" "ndk;26.1.10909125"

echo "=== [5/5] gradle 8.7 ==="
if [ ! -d /home/user/.local/gradle-8.7 ]; then
  curl -sSL -o gradle.zip "https://services.gradle.org/distributions/gradle-8.7-bin.zip"
  unzip -q -o gradle.zip -d /home/user/.local
fi
echo "=== TOOLCHAIN READY ==="
ls "$SDK"
