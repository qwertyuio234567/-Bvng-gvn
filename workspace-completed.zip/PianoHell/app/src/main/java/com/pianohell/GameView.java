package com.pianohell;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

/**
 * GameView — the renderer (the spec's "GameView.java": a SurfaceView plus its own render thread).
 * It draws tiles as raw pixels into an int[] framebuffer.
 *
 * <h3>Why not Views, and why not Canvas-per-tile either</h3>
 * <ul>
 *   <li>A {@code View} per note is exactly the trap the spec calls out: 12 lanes × ~60 visible tiles
 *       = 700+ views, each with measure/layout/draw and its own invalidation. That collapses long
 *       before black-MIDI density, and at 5M notes it never even gets built.</li>
 *   <li>One {@link SurfaceView} + one thread means the game owns its own frame cadence: no
 *       UI-thread choreography, no vsync-blocked layout pass, no allocation per tile.</li>
 *   <li>The tiles are drawn into an int[] framebuffer with our own alpha blending instead of
 *       thousands of {@code canvas.drawRect} calls. Alpha blending + glow + lane flashes are then
 *       just arithmetic, and the same buffer can be rendered at a reduced internal resolution and
 *       upscaled when a device cannot keep up with a 300-notes-per-second chart
 *       ({@link #renderScale}, automatic).</li>
 * </ul>
 * The frame is handed to the surface with {@code lockCanvas()} → {@code drawBitmap} →
 * {@code unlockCanvasAndPost()}. The bitmap is only ever used as a transport for our pixels, so the
 * View/Canvas hierarchy stays at ONE node for the entire playfield.
 *
 * <h3>The render loop</h3>
 * <pre>
 *   while (running) {
 *     long now = System.nanoTime();
 *     ... wait for the frame deadline (target cadence: display refresh, capped at MAX_FPS) ...
 *     engine.advance();                       // fixed-timestep simulation, new notes appear here
 *     collectTiles();                         // binary search + pooled display records
 *     rasterize();                            // lanes, tiles, holds, hit line, particles
 *     present();                              // lockCanvas / drawBitmap / unlockCanvasAndPost
 *   }
 * </pre>
 * Nothing here allocates after the first frame: the tile display list comes from {@link NotePool},
 * particles from the same pool, and all geometry is float math on primitives.
 */
public final class GameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {

    private static volatile int sSurfaceW = 1080, sSurfaceH = 1920;

    /** The engine needs the surface width to convert a touch x into a lane. */
    public static int lastWidthPx() { return sSurfaceW; }

    private static final int MAX_FPS = 120;          // some panels report 144 Hz; 120 is plenty
    private static final long MIN_FRAME_NS = 1_000_000_000L / MAX_FPS;
    /** Adaptive resolution: drop the internal framebuffer when frames get long. */
    private static final float SCALE_MIN = 0.55f;

    // Written by the UI thread in bind(), read by the render thread. `engine` is assigned LAST in
    // bind() and everything else FIRST, so a render thread that sees a non-null engine also sees a
    // complete cfg/colors/palette (volatile write = happens-before for the earlier plain writes).
    private volatile GameEngine engine;
    private volatile GameConfig cfg;
    private volatile NoteColors colors;
    private volatile MidiMapper mapper;
    /** Last surface size reported by surfaceChanged(). The RENDER thread turns it into buffers. */
    private volatile int surfW = 0, surfH = 0;
    /** Set by the UI thread (bind / surfaceChanged); consumed by the render thread. */
    private volatile boolean geometryDirty = true;

    private Thread renderThread;
    private volatile boolean running = false;
    private final SurfaceHolder holder;

    // framebuffer
    private int bufW, bufH;
    private int[] frame;
    private Bitmap frameBitmap;
    private final Rect srcRect = new Rect();
    private final Rect dstRect = new Rect();
    private float renderScale = 1f;

    // render-side geometry cache (recomputed on size change, never per frame)
    private float laneWidth, hitY, pxPerMs;
    /**
     * Background gradient, precomputed as bands: BANDS x LANES colors. Filling a row is then a
     * lookup + an Arrays.fill (which the JIT turns into a vectorised store), instead of a per-pixel
     * blend over the whole surface every frame — that difference alone is several milliseconds a
     * frame at 1080p, which is a third of the 16.6 ms budget at 60 fps.
     */
    private static final int BANDS = 24;
    private int[][] bandColors = new int[BANDS][GameConfig.LANES];
    /**
     * Hard cap on tiles rasterised per frame. Past this the frame cost would blow the budget, so the
     * remaining tiles are simply not drawn this frame (the chart/judgment is untouched — only the
     * picture loses its last few hundred overlapping tiles). Bounded, predictable frame times beat
     * an unbounded draw loop that drops frames and feels worse than a slightly thinner picture.
     */
    private static final int MAX_DRAW_TILES = 1400;
    private int drawnTiles = 0;
    /** Reused every frame (no allocation in the render loop). */
    private final ScrollWindow.Bounds window = new ScrollWindow.Bounds();
    private int[] laneBgTop = new int[GameConfig.LANES];
    private int[] laneBgBottom = new int[GameConfig.LANES];
    private int[] laneLine = new int[GameConfig.LANES];
    private int[] laneBright = new int[GameConfig.LANES];
    private volatile int[] palette;

    // look & feel
    private static final boolean[] IS_SHARP = { false, true, false, true, false, false, true, false, true, false, true, false };
    private static final String[] NOTE_NAMES = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    private int keysTop;                                   // first pixel row of the keyboard strip
    private final int[] tileGrad = new int[8];             // per-tile vertical gradient (reused)
    private final int[] keyGrad = new int[8];
    private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final int GRID_MS = 250;                // scrolling beat grid spacing

    // HUD
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint barPaint = new Paint();
    private final float[] lastFlash = new float[GameConfig.LANES];
    private final java.util.Random rng = new java.util.Random(0xC0FFEE);
    private long frames;
    private long fpsWindowStart;
    private int fps;
    private float shownFps;

    // status strings (rebuilt only when the state changes, so no per-frame String.format in the loop)
    private int lastState = -1;
    private String statusTitle = "";
    private String statusSub = "";
    private RunResultText pendingResult;

    public static final class RunResultText { public String title = "", body = ""; }

    public GameView(Context c) { this(c, null); }

    public GameView(Context c, AttributeSet a) {
        super(c, a);
        holder = getHolder();
        holder.addCallback(this);
        setFocusable(true);
        setFocusableInTouchMode(true);
        textPaint.setColor(0xFFFFFFFF);
        textPaint.setTextSize(28f);
        textPaint.setFakeBoldText(true);
        dimPaint.setColor(0xFFB0B0C8);
        dimPaint.setTextSize(16f);
        barPaint.setColor(0xFFFF2D6F);
        textPaint.setShadowLayer(8f, 0f, 2f, 0xCC000000);
        labelPaint.setFakeBoldText(true);
        labelPaint.setTextAlign(Paint.Align.CENTER);
        frames = 0;
        fpsWindowStart = System.nanoTime();
    }

    /**
     * Wire the view to its simulation. May be called BEFORE or AFTER the surface exists — with an
     * asynchronous preset load it is nearly always AFTER. It must not touch the framebuffer (that
     * belongs to the render thread); it only publishes state and flags the geometry as stale.
     */
    public void bind(GameEngine engine, GameConfig cfg, NoteColors colors, MidiMapper mapper) {
        this.cfg = cfg;
        this.colors = colors;
        this.mapper = mapper;
        this.palette = colors.raw();
        this.geometryDirty = true;
        this.engine = engine;                 // LAST: this is what releases the render loop
    }

    public void setResultText(RunResultText t) { pendingResult = t; }

    // ==================================================================
    // Surface lifecycle
    // ==================================================================

    @Override public void surfaceCreated(SurfaceHolder h) {
        running = true;
        renderThread = new Thread(this, "PianoHell-Render");
        renderThread.setPriority(Thread.MAX_PRIORITY);      // this thread must not be preempted by GC helpers
        renderThread.start();
    }

    @Override public void surfaceChanged(SurfaceHolder h, int format, int width, int height) {
        // v1.0.4: this used to build the framebuffer right here, on the UI thread, dereferencing
        // cfg/palette. On the preset path the chart is still loading when the surface appears, so
        // bind() had not run yet and cfg was null -> NullPointerException -> "Piano Hell keeps
        // stopping". Now we only record the size; the render thread builds buffers once it has a
        // chart (see applyGeometry()).
        sSurfaceW = width;
        sSurfaceH = height;
        surfW = width;
        surfH = height;
        geometryDirty = true;
    }

    @Override public void surfaceDestroyed(SurfaceHolder h) {
        stopRenderThread();
    }

    /** Called by the Activity on onPause; joins the thread so no pixels are posted after detach. */
    public void stopRenderThread() {
        running = false;
        Thread t = renderThread;
        renderThread = null;
        if (t != null) {
            try { t.join(1000); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
    }

    /** Framebuffer sanity cap. 4M pixels is ~16 MB as ARGB_8888 — plenty of headroom on any screen,
     *  and it stops a pathological window size from allocating a bitmap the process cannot hold. */
    private static final int MAX_PIXELS = 4_000_000;

    /** Render thread only: (re)build buffers + geometry when the surface size or binding changed. */
    private boolean applyGeometry() {
        final GameConfig c = cfg;
        final int[] pal = palette;
        final int w = surfW, h = surfH;
        if (c == null || pal == null || w <= 0 || h <= 0) return false;     // not ready yet: try later
        geometryDirty = false;
        resizeBuffers(w, h);
        return frame != null;
    }

    /** Rebuild the framebuffer + derived geometry. Only runs on size changes and scale switches. */
    private void resizeBuffers(int w, int h) {
        if ((long) w * h * renderScale * renderScale > MAX_PIXELS) {
            renderScale = (float) Math.sqrt((double) MAX_PIXELS / ((double) w * h));
        }
        int nw = Math.max(2, (int) (w * renderScale));
        int nh = Math.max(2, (int) (h * renderScale));
        if (frame != null && nw == bufW && nh == bufH) { recomputeGeometry(w, h); return; }
        bufW = nw;
        bufH = nh;
        frame = new int[bufW * bufH];
        if (frameBitmap != null) frameBitmap.recycle();
        frameBitmap = Bitmap.createBitmap(bufW, bufH, Bitmap.Config.ARGB_8888);
        srcRect.set(0, 0, bufW, bufH);
        dstRect.set(0, 0, w, h);
        recomputeGeometry(w, h);
    }

    /**
     * All size-dependent constants — lane width, hit line, pixels-per-millisecond — are computed
     * ONCE here instead of per tile per frame. This is the difference between "scroll speed is a
     * multiply" and "scroll speed is a division in the inner loop of 3000 tiles".
     */
    private void recomputeGeometry(int surfaceW, int surfaceH) {
        laneWidth = (float) bufW / GameConfig.LANES;
        hitY = bufH * cfg.hitLineYFraction;
        // Vertical pixels per millisecond of chart time: a note's whole journey is cfg.scrollMs.
        pxPerMs = hitY / Math.max(1f, (float) cfg.scrollMs);
        keysTop = (int) hitY + Math.max(5, bufH / 80);

        for (int i = 0; i < GameConfig.LANES; i++) {
            int c = palette[i];
            // Black-key lanes sit darker than white-key lanes, like a real keyboard seen from above.
            final int base = IS_SHARP[i] ? 0xFF05050A : 0xFF0D0D16;
            laneBgTop[i] = NoteColors.blend(base, c, IS_SHARP[i] ? 10 : 18);
            laneBgBottom[i] = NoteColors.blend(base, c, IS_SHARP[i] ? 34 : 52);
            laneLine[i] = NoteColors.blend(0xFF0B0B12, c, 70);
            laneBright[i] = c;
            for (int b = 0; b < BANDS; b++) {
                bandColors[b][i] = NoteColors.blend(laneBgTop[i], laneBgBottom[i], b * 256 / BANDS);
            }
        }
        textPaint.setTextSize(Math.max(20f, bufH * 0.035f));
        dimPaint.setTextSize(Math.max(13f, bufH * 0.019f));
    }

    // ==================================================================
    // Render thread
    // ==================================================================

    @Override public void run() {
        long frameStart = System.nanoTime();
        while (running) {
            long now = System.nanoTime();
            long dt = now - frameStart;
            if (dt < MIN_FRAME_NS) {
                long sleepNs = MIN_FRAME_NS - dt;
                try { Thread.sleep(sleepNs / 1_000_000L, (int) (sleepNs % 1_000_000L)); }
                catch (InterruptedException e) { running = false; break; }
                continue;
            }
            frameStart = now;

            if (engine == null || (geometryDirty && !applyGeometry()) || frame == null) {
                // chart still loading / surface size not known yet: idle instead of spinning
                try { Thread.sleep(8); } catch (InterruptedException e) { running = false; break; }
                continue;
            }
            engine.advance();
            spawnHitSparks();
            collectTiles();
            rasterize();
            boolean posted = present();

            frames++;
            if (now - fpsWindowStart >= 1_000_000_000L) {
                fps = (int) frames;
                shownFps = shownFps == 0 ? fps : (shownFps * 0.6f + fps * 0.4f);
                frames = 0;
                fpsWindowStart = now;
                adaptResolution();
            }
            if (!posted) running = false;                 // surface went away
        }
    }

    /**
     * Adaptive internal resolution: if we cannot hold ~50 fps, shrink the framebuffer (never the
     * simulation). Tiles are big flat rects, so the visual cost is small and the win at black-MIDI
     * density is large — the alternative would be to start dropping notes, which a rhythm game
     * must never do because it changes judgment fairness.
     */
    private void adaptResolution() {
        if (fps == 0) return;
        float old = renderScale;
        if (fps < 45 && renderScale > SCALE_MIN) renderScale = Math.max(SCALE_MIN, renderScale - 0.1f);
        else if (fps > 58 && renderScale < 1f) renderScale = Math.min(1f, renderScale + 0.05f);
        if (old != renderScale) {
            // Preserve the surface size for the geometry maths.
            geometryDirty = true;                       // the loop re-applies it next frame
        }
    }

    // ==================================================================
    // Phase 1 — collect: binary search the visible time window, fill the pooled display list
    // ==================================================================

    /**
     * Cost per frame: two binary searches (O(log n)) + one pass over the notes inside the window.
     * A 5,000,000-note chart and a 5,000-note chart cost exactly the same here, which is the entire
     * point of keeping {@code startMs} sorted and searching instead of scanning.
     */
    private void collectTiles() {
        NotePool pool = engine.getPool();
        ChartData chart = engine.getChart();
        pool.resetFrame();

        final double songMs = engine.getSongTimeMs();
        if (chart.count == 0) return;

        final float tileH = Math.max(6f, laneWidth * 0.55f);            // tap tile height

        // The visible slice of the chart. ScrollWindow.compute() derives the index range from the
        // geometry, so it is provably a superset of what can be on screen — the two bugs that lived
        // here (inverted time axis, and ignoring the tile-height overhang at the bottom edge) are
        // both covered by the brute-force scan in tools/harness.
        ScrollWindow.compute(chart, songMs, hitY, pxPerMs, bufH,
                chart.maxDurationMs(), tileH, window);
        final int i0 = window.first;
        final int i1 = window.last;
        final long[] start = chart.startMs;
        final int[] dur = chart.durationMs;
        final byte[] lane = chart.lane;
        final byte[] color = chart.colorId;
        final byte[] kind = chart.kind;
        final byte[] jud = chart.jud;

        for (int i = i0; i < i1; i++) {
            // y of the note's attack: 0 at the top of the surface, hitY at the hit line, and a note
            // that has not arrived yet sits ABOVE the line (y grows downward, time grows upward).
            float yHead = ScrollWindow.yForTime(start[i], songMs, hitY, pxPerMs);
            float height = kind[i] == ChartData.KIND_HOLD
                    ? (float) (Math.max(GameConfig.MIN_HOLD_MS, dur[i]) * pxPerMs)
                    : tileH;
            float yTail = yHead - height;                                // smaller y == later in time
            if (!ScrollWindow.isVisible(yHead, yTail, bufH)) continue;    // fully off-screen: skip early

            int c = palette[color[i] & 0x1F];
            if (jud[i] == ChartData.JUD_DONE) c = NoteColors.darken(c, 0.35f);         // already hit: fade
            else if (jud[i] == ChartData.JUD_MISSED) c = NoteColors.blend(c, 0xFF404040, 170);

            NotePool.ActiveNote n = pool.acquireActive(i, lane[i] * laneWidth, yTail,
                    laneWidth, yHead - yTail, c, kind[i] == ChartData.KIND_HOLD);
            if (n == null) break;                                        // pool full: draw what we have
            n.hit = jud[i] != ChartData.JUD_NONE;                        // already resolved (hit/miss look)
        }
    }

    // ==================================================================
    // Phase 2 — rasterize into the int[] framebuffer
    // ==================================================================

    private void rasterize() {
        final int w = bufW, h = bufH;
        final int[] px = frame;
        final double songMs = engine.getSongTimeMs();

        // ---- background: 24 gradient bands x 12 lanes, filled with Arrays.fill ----------------
        final int bandRows = Math.max(1, h / BANDS);
        for (int b = 0; b < BANDS; b++) {
            int y0 = b * bandRows;
            int y1 = (b == BANDS - 1) ? h : Math.min(h, y0 + bandRows);
            int[] colors = bandColors[b];
            for (int l = 0; l < GameConfig.LANES; l++) {
                int x0 = (int) (l * laneWidth), x1 = (int) ((l + 1) * laneWidth);
                if (x1 > w) x1 = w;
                int c = colors[l];
                for (int y = y0; y < y1; y++) {
                    java.util.Arrays.fill(px, y * w + x0, y * w + x1, c);
                }
            }
        }

        // ---- scrolling beat grid: gives the eye a speed reference even between notes -----------
        final int yHit = (int) hitY;
        for (long k = (long) Math.floor(songMs / GRID_MS); ; k++) {
            int y = (int) (hitY - (k * (double) GRID_MS - songMs) * pxPerMs);
            if (y < 0) break;
            if (y >= yHit) continue;
            fillRect(px, w, h, 0, y, w, y + 1, 0xFFFFFFFF, (k & 3) == 0 ? 34 : 14);
        }

        // ---- lane separators --------------------------------------------------------------------
        for (int l = 1; l < GameConfig.LANES; l++) {
            int x = (int) (l * laneWidth);
            if (x <= 0 || x >= w) continue;
            int c = laneLine[l - 1];
            for (int y = 0; y < yHit; y++) px[y * w + x] = c;
            if (x + 1 < w) for (int y = 0; y < yHit; y++) px[y * w + x + 1] = NoteColors.blend(px[y * w + x + 1], c, 80);
        }

        // ---- hit beams: a light column that shoots up the lane when you hit ----------------------
        final int beamH = Math.max(8, (int) (hitY * 0.55f));
        for (int l = 0; l < GameConfig.LANES; l++) {
            float f = Math.max(engine.laneFlash[l], engine.isLaneDown(l) ? 0.55f : 0f);
            if (f <= 0.02f) continue;
            int x0 = (int) (l * laneWidth) + 1, x1 = (int) ((l + 1) * laneWidth);
            if (x1 > w) x1 = w;
            for (int d = 0; d < beamH; d++) {
                float t = 1f - (float) d / beamH;
                int alpha = (int) (f * 150f * t * t);
                if (alpha <= 0) break;
                int y = yHit - d;
                if (y < 0) break;
                int row = y * w;
                for (int x = x0; x < x1; x++) px[row + x] = NoteColors.blend(px[row + x], laneBright[l], alpha);
            }
        }

        // ---- tiles (pooled display list) ---------------------------------------------------------
        NotePool pool = engine.getPool();
        drawnTiles = 0;
        final int nTiles = Math.min(pool.activeCount(), MAX_DRAW_TILES);
        // Glow is the expensive part of a tile; spend it only while the screen is not crowded.
        final int glow = nTiles < 160 ? 7 : nTiles < 500 ? 4 : nTiles < 900 ? 2 : 0;
        for (int i = 0; i < nTiles; i++) {
            NotePool.ActiveNote n = pool.activeAt(i);
            int x0 = (int) n.x, x1 = (int) (n.x + n.w);
            int y0 = (int) n.y, y1 = (int) (n.y + n.h);
            final int g = n.hit ? 0 : glow;
            if (!n.hold) {
                drawTile(px, w, h, x0 + 3, y0, x1 - 3, y1, n.color, g, false);
            } else {
                // Holds: a NARROW glowing tail (drawn first) + a full-width head on top of it.
                int headTop = Math.max(y0, y1 - (int) (laneWidth * 0.62f));
                if (y0 < headTop) {
                    int inset = (int) (n.w * 0.30f);
                    drawTile(px, w, h, x0 + inset, y0, x1 - inset, headTop + 6, n.color, Math.min(g, 3), true);
                }
                drawTile(px, w, h, x0 + 3, headTop, x1 - 3, y1, n.color, g, false);
            }
            drawnTiles++;
        }

        // ---- particles ---------------------------------------------------------------------------
        for (int i = 0; i < pool.particleCount(); i++) {
            NotePool.Particle p = pool.particleAt(i);
            float life = Math.max(0f, Math.min(1f, p.life / Math.max(0.0001f, p.lifeMax)));
            int rad = (int) (2 + 5 * life);
            disc(px, w, h, (int) p.x, (int) p.y, rad + 4, p.color, (int) (60 * life));       // soft halo
            disc(px, w, h, (int) p.x, (int) p.y, rad, 0xFFFFFFFF, (int) (210 * life));       // hot core
        }

        // ---- hit line: soft glow above, bright core, shadow below -------------------------------
        for (int d = 1; d <= 14; d++) fillRect(px, w, h, 0, yHit - d, w, yHit - d + 1, 0xFFFFFFFF, 46 - d * 3);
        fillRect(px, w, h, 0, yHit - 1, w, yHit + 3, 0xFFFFFFFF, 245);

        // ---- the keyboard under the hit line ------------------------------------------------------
        drawKeyboard(px, w, h);
    }

    /**
     * 12 piano keys, one per lane (white keys for C D E F G A B, dark keys for the sharps). A key
     * lights up in its lane colour when the lane is hit or held. Labels are drawn later with Canvas.
     */
    private void drawKeyboard(int[] px, int w, int h) {
        final int top = keysTop, bottom = h;
        if (top >= bottom - 2) return;
        // backing plate so gaps between keys read as gaps
        fillRect(px, w, h, 0, (int) hitY + 3, w, top, 0xFF000000, 255);
        fillRect(px, w, h, 0, top, w, bottom, 0xFF050508, 255);
        final int rows = bottom - top;
        for (int l = 0; l < GameConfig.LANES; l++) {
            final boolean sharp = IS_SHARP[l];
            final int hiC = sharp ? 0xFF343446 : 0xFFF6F6FC;
            final int loC = sharp ? 0xFF0A0A10 : 0xFFA4A4BC;
            for (int i = 0; i < 8; i++) keyGrad[i] = NoteColors.lerp(hiC, loC, i / 7f);
            float f = Math.max(engine.laneFlash[l], engine.isLaneDown(l) ? 0.9f : 0f);
            final int tint = (int) (Math.min(1f, f) * 215f);
            int x0 = (int) (l * laneWidth) + 2, x1 = (int) ((l + 1) * laneWidth) - 2;
            if (x1 > w) x1 = w;
            if (x1 <= x0) continue;
            for (int y = top; y < bottom - 2; y++) {
                int c = keyGrad[Math.min(7, (y - top) * 8 / rows)];
                if (tint > 0) c = NoteColors.blend(c, laneBright[l], tint);
                int row = y * w;
                int xa = x0, xb = x1;
                int dy = y - top;
                if (dy < 2) { xa++; xb--; }                        // softened top corners
                java.util.Arrays.fill(px, row + xa, row + xb, c);
            }
            // coloured cap on the key: always visible, brighter when lit
            fillRect(px, w, h, x0, top, x1, top + 3, laneBright[l], 120 + Math.min(120, tint / 2));
        }
    }

    /**
     * Hit sparks. The simulation thread only publishes a per-lane flash level; turning that into
     * particles here keeps colors/geometry on the thread that knows the layout, and the pool means
     * a 200-hits-per-second section does not allocate 200 objects per second.
     */
    private void spawnHitSparks() {
        for (int l = 0; l < GameConfig.LANES; l++) {
            float f = engine.laneFlash[l];
            if (f > 0.9f && lastFlash[l] <= 0.9f) {
                float cx = (l + 0.5f) * laneWidth;
                for (int k = 0; k < 6; k++) {
                    float vx = (rng.nextFloat() - 0.5f) * laneWidth * 6f;
                    float vy = -(0.4f + rng.nextFloat()) * bufH * 0.35f;
                    engine.getPool().spawnParticle(cx, (float) hitY, vx, vy, 0.28f + rng.nextFloat() * 0.18f,
                            laneBright[l]);
                }
            }
            lastFlash[l] = f;
        }
    }

    /**
     * A tile: rounded, vertically shaded body with a bright top bevel, a specular streak and an
     * outer glow of {@code glowPx} pixels.
     *
     * <p>Why it is still cheap: the body is {@link java.util.Arrays#fill} per row (one vectorised
     * store), the gradient is 8 precomputed colours per TILE (not per pixel), the rounded corners
     * are a handful of shortened rows, and the glow — the only blended part — is switched off
     * automatically when the screen is crowded (see {@code glow} in {@link #rasterize}).
     *
     * @param glowPx halo width on each side in pixels, 0 = none
     * @param tail   true for the narrow body of a hold (a little darker, no specular streak)
     */
    private void drawTile(int[] px, int w, int h, int x0, int y0, int x1, int y1, int color,
                          int glowPx, boolean tail) {
        if (x1 <= x0 || y1 <= y0) return;
        if (y1 < 0 || y0 > h) return;
        final int th = y1 - y0, tw = x1 - x0;
        final int r = Math.max(1, Math.min(Math.min(th / 2, tw / 2), Math.max(3, (int) (laneWidth * 0.11f))));
        final int iy0 = Math.max(0, y0), iy1 = Math.min(h, y1);

        final int hi = NoteColors.blend(color, 0xFFFFFFFF, 140);
        final int lo = NoteColors.darken(color, tail ? 0.40f : 0.52f);
        final int edge = NoteColors.darken(color, 0.30f);
        final int[] g = tileGrad;
        for (int i = 0; i < 8; i++) g[i] = NoteColors.lerp(color, lo, i / 7f);

        for (int y = iy0; y < iy1; y++) {
            final int dy = y - y0, dyb = y1 - 1 - y;
            int inset = 0;
            if (dy < r) inset = r - (int) Math.sqrt(Math.max(0f, r * r - (r - dy - 0.5f) * (r - dy - 0.5f)));
            else if (dyb < r) inset = r - (int) Math.sqrt(Math.max(0f, r * r - (r - dyb - 0.5f) * (r - dyb - 0.5f)));
            final int xa = Math.max(0, x0 + inset), xb = Math.min(w, x1 - inset);
            if (xa >= xb) continue;
            final int row = y * w;

            int c;
            if (dy < 2) c = hi;                                   // top bevel highlight
            else if (dyb < 2) c = edge;                           // bottom edge
            else c = g[Math.min(7, dy * 8 / Math.max(1, th))];    // vertical shading
            java.util.Arrays.fill(px, row + xa, row + xb, c);

            if (!tail && tw > 14 && dy > 1 && dyb > 1) {           // specular streak down the left side
                int sx = xa + 4;
                if (sx + 2 < xb) {
                    px[row + sx] = NoteColors.blend(px[row + sx], 0xFFFFFFFF, 80);
                    px[row + sx + 1] = NoteColors.blend(px[row + sx + 1], 0xFFFFFFFF, 40);
                }
            }
            if (glowPx > 0) {                                      // outer halo, fading with distance
                for (int k = 1; k <= glowPx; k++) {
                    int a = 70 * (glowPx - k + 1) / (glowPx + 1);
                    int lx = xa - k, rx = xb + k - 1;
                    if (lx >= 0) px[row + lx] = NoteColors.blend(px[row + lx], color, a);
                    if (rx < w) px[row + rx] = NoteColors.blend(px[row + rx], color, a);
                }
            }
        }
        // glow above the tile's top edge (so the leading edge looks lit, not cut out)
        if (glowPx > 0 && y0 > 0) {
            for (int k = 1; k <= Math.min(glowPx, 3); k++) {
                int yy = y0 - k;
                if (yy < 0 || yy >= h) continue;
                int a = 60 * (glowPx - k + 1) / (glowPx + 1);
                int xa = Math.max(0, x0 + r), xb = Math.min(w, x1 - r);
                int row = yy * w;
                for (int x = xa; x < xb; x++) px[row + x] = NoteColors.blend(px[row + x], color, a);
            }
        }
    }

    private static void fillRect(int[] px, int w, int h, int x0, int y0, int x1, int y1, int color, int alpha) {
        if (alpha <= 0) return;
        x0 = Math.max(0, x0); y0 = Math.max(0, y0);
        x1 = Math.min(w, x1); y1 = Math.min(h, y1);
        if (x0 >= x1 || y0 >= y1) return;
        if (alpha >= 255) {
            for (int y = y0; y < y1; y++) {
                int row = y * w;
                java.util.Arrays.fill(px, row + x0, row + x1, color);
            }
            return;
        }
        for (int y = y0; y < y1; y++) {
            int row = y * w;
            for (int x = x0; x < x1; x++) px[row + x] = NoteColors.blend(px[row + x], color, alpha);
        }
    }

    private static void disc(int[] px, int w, int h, int cx, int cy, int r, int color, int alpha) {
        int r2 = r * r;
        for (int y = -r; y <= r; y++) {
            int yy = cy + y;
            if (yy < 0 || yy >= h) continue;
            int row = yy * w;
            for (int x = -r; x <= r; x++) {
                if (x * x + y * y > r2) continue;
                int xx = cx + x;
                if (xx < 0 || xx >= w) continue;
                px[row + xx] = NoteColors.blend(px[row + xx], color, alpha);
            }
        }
    }

    // ==================================================================
    // Phase 3 — present
    // ==================================================================

    private boolean present() {
        Canvas c = null;
        try {
            c = holder.lockCanvas();
            if (c == null) {
                // The surface can be briefly unavailable (window resize, app switch, the frame right
                // after surfaceCreated). Returning false here used to STOP the render thread for
                // good — a frozen board was the result. Skipping the frame and trying again next
                // time is the correct behaviour; surfaceDestroyed is what actually ends the loop.
                return true;
            }
            frameBitmap.setPixels(frame, 0, bufW, 0, 0, bufW, bufH);
            c.drawBitmap(frameBitmap, srcRect, dstRect, null);
            drawHud(c);
            return true;
        } catch (IllegalStateException | IllegalArgumentException e) {
            return false;                                  // surface died mid-frame: thread exits cleanly
        } finally {
            if (c != null) {
                try { holder.unlockCanvasAndPost(c); } catch (IllegalStateException ignored) { }
            }
        }
    }

    /**
     * HUD text goes through Canvas (not the framebuffer) because glyph rasterisation in pure Java
     * would be madness: a handful of drawText calls per frame is free, the thousands of tiles are
     * the part that had to avoid the View system.
     */
    private void drawHud(Canvas c) {
        final float w = getWidth(), h = getHeight();
        final float pad = h * 0.02f;
        final float sy = bufH > 0 ? h / bufH : 1f;               // buffer px -> surface px
        final float hitYs = hitY * sy;
        final float keysTopS = keysTop * sy;
        final float laneWs = w / GameConfig.LANES;

        // thin progress bar along the very top
        float prog = engine.progress();
        barPaint.setColor(0x26FFFFFF);
        c.drawRect(0, 0, w, h * 0.008f, barPaint);
        barPaint.setColor(0xFFFF2D6F);
        c.drawRect(0, 0, w * prog, h * 0.008f, barPaint);

        // score + judgment counters, top-left
        textPaint.setTextAlign(Paint.Align.LEFT);
        textPaint.setTextSize(h * 0.062f);
        c.drawText(String.format(java.util.Locale.US, "%,d", engine.getScore()), pad, h * 0.085f, textPaint);
        dimPaint.setTextSize(h * 0.024f);
        c.drawText("PERFECT " + engine.getPerfect() + "   GOOD " + engine.getGood()
                + "   MISS " + engine.getMiss(), pad, h * 0.125f, dimPaint);

        // combo, big and centred above the hit line
        int combo = engine.getCombo();
        if (combo > 1) {
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(h * 0.11f);
            c.drawText(String.valueOf(combo), w * 0.5f, hitYs * 0.46f, textPaint);
            dimPaint.setTextSize(h * 0.03f);
            dimPaint.setTextAlign(Paint.Align.CENTER);
            c.drawText("COMBO", w * 0.5f, hitYs * 0.46f + h * 0.05f, dimPaint);
            dimPaint.setTextAlign(Paint.Align.LEFT);
            textPaint.setTextAlign(Paint.Align.LEFT);
        }

        // judgment popup: appears over the hit line, rises and fades over ~450 ms
        long age = SystemClock.uptimeMillis() - engine.lastJudgmentMs;
        if (engine.lastJudgmentMs > 0 && age >= 0 && age < 450) {
            int rgb; String label;
            switch (engine.lastJudgmentKind) {
                case 0: rgb = 0xFFE066; label = "PERFECT"; break;
                case 1: rgb = 0x7CF0A8; label = "GOOD"; break;
                case 2: rgb = 0xA0C4FF; label = "PARTIAL"; break;
                default: rgb = 0xFF5C5C; label = "MISS"; break;
            }
            int a = (int) (255 * (1f - age / 450f));
            textPaint.setColor((a << 24) | rgb);
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTextSize(h * 0.05f);
            c.drawText(label, w * 0.5f, hitYs - h * 0.05f - age * h * 0.00012f, textPaint);
            textPaint.setTextAlign(Paint.Align.LEFT);
            textPaint.setColor(0xFFFFFFFF);
        }

        // key labels: note names in the default chromatic mapping, lane numbers otherwise
        labelPaint.setTextSize(Math.max(12f, Math.min(laneWs * 0.30f, (h - keysTopS) * 0.40f)));
        final boolean names = cfg.mappingMode == GameConfig.MAP_PITCH_CLASS;
        for (int l = 0; l < GameConfig.LANES; l++) {
            labelPaint.setColor(IS_SHARP[l] ? 0xFFB8B8D0 : 0xFF2A2A3C);
            String t = names ? NOTE_NAMES[l] : String.valueOf(l + 1);
            c.drawText(t, (l + 0.5f) * laneWs, h - (h - keysTopS) * 0.22f, labelPaint);
        }

        // health (endless mode only — sudden death has no bar to show, it is binary)
        if (!cfg.suddenDeath) {
            barPaint.setColor(0x33FFFFFF);
            c.drawRect(pad, h * 0.145f, w * 0.30f, h * 0.157f, barPaint);
            barPaint.setColor(engine.getHealth() > 0.35f ? 0xFF46E39B : 0xFFFF4D4D);
            c.drawRect(pad, h * 0.145f, pad + (w * 0.30f - pad) * engine.getHealth(), h * 0.157f, barPaint);
        }

        // diagnostics: fps + how many tiles the pool handed out this frame
        if (cfg.showDiagnostics) {
            dimPaint.setTextSize(h * 0.017f);
            float dy = h * 0.19f;
            c.drawText(String.format(java.util.Locale.US,
                            "%d fps · %d/%d tiles · %s · %.0f%% res · clock re-anchors %d",
                            (int) shownFps, drawnTiles, engine.getPool().activeCount(), shortMapping(), renderScale * 100f,
                            engine.getClockReanchors()),
                    pad, dy, dimPaint);
            c.drawText(engine.audioStatus(), pad, dy + h * 0.025f, dimPaint);
        }

        drawStatusOverlay(c, w, h);
    }

    private String shortMapping() {
        if (mapper == null) return "";
        switch (cfg.mappingMode) {
            case GameConfig.MAP_SCALE: return "scale";
            case GameConfig.MAP_DENSITY: return "density";
            default: return "chromatic";
        }
    }

    /** PAUSED / FAILED / FINISHED overlay, plus the results card. */
    private void drawStatusOverlay(Canvas c, float w, float h) {
        int state = engine.getState();
        if (state == lastState) { if (state == GameEngine.STATE_PLAYING) return; }
        lastState = state;

        if (state == GameEngine.STATE_PLAYING) { pendingResult = null; return; }

        barPaint.setColor(0xAA000000);                   // dim the (still animating) playfield
        c.drawRect(0, 0, w, h, barPaint);

        String title;
        String body;
        switch (state) {
            case GameEngine.STATE_PAUSED: title = "PAUSED"; body = "Tap RESUME or press back to quit."; break;
            case GameEngine.STATE_FAILED: title = "FAILED"; body = "Sudden death. Tap RESTART to try again."; break;
            case GameEngine.STATE_FINISHED: title = "CLEARED"; body = ""; break;
            default: title = "GET READY"; body = "First tiles are scrolling in…"; break;
        }
        textPaint.setTextSize(h * 0.10f);
        textPaint.setTextAlign(Paint.Align.CENTER);
        c.drawText(title, w * 0.5f, h * 0.34f, textPaint);
        textPaint.setTextAlign(Paint.Align.LEFT);

        dimPaint.setTextSize(h * 0.028f);
        String extra = pendingResult != null ? pendingResult.body : body;
        String[] lines = extra.split("\n");
        float y = h * 0.42f;
        for (String line : lines) {
            c.drawText(line, w * 0.12f, y, dimPaint);
            y += h * 0.045f;
        }
    }

    // ==================================================================
    // Input: full multi-touch pointer tracking
    // ==================================================================

    /**
     * MotionEvent's action is only meaningful with the pointer index from the action mask, and every
     * other pointer's state must be read with {@code getPointerId(i)} / {@code getX(i)}. Doing it
     * this way (and NOT with {@code getActionIndex()} alone) is what makes 5-finger chords and
     * simultaneous holds across 12 lanes work.
     */
    @Override public boolean onTouchEvent(MotionEvent ev) {
        if (engine == null) return true;
        final int action = ev.getActionMasked();
        final int count = ev.getPointerCount();
        final long when = ev.getEventTime();            // uptime clock: matches SystemClock.uptimeMillis()
        NotePool pool = engine.getPool();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN:
                pool.pushEvent(NotePool.TouchEvent.DOWN, ev.getPointerId(ev.getActionIndex()),
                        ev.getX(ev.getActionIndex()), ev.getY(ev.getActionIndex()), when);
                break;
            case MotionEvent.ACTION_POINTER_UP:
                pool.pushEvent(NotePool.TouchEvent.UP, ev.getPointerId(ev.getActionIndex()),
                        ev.getX(ev.getActionIndex()), ev.getY(ev.getActionIndex()), when);
                break;
            case MotionEvent.ACTION_UP:
                pool.pushEvent(NotePool.TouchEvent.UP, ev.getPointerId(0), ev.getX(0), ev.getY(0), when);
                break;
            case MotionEvent.ACTION_CANCEL:
                for (int i = 0; i < count; i++)
                    pool.pushEvent(NotePool.TouchEvent.CANCEL, ev.getPointerId(i), ev.getX(i), ev.getY(i), when);
                break;
            case MotionEvent.ACTION_MOVE:
                // Releasing a hold by sliding is judged too, so MOVEs are forwarded; the engine
                // treats them as no-ops for taps.
                break;
            default:
                break;
        }
        performClick();                                  // keep accessibility/lint happy; no-op otherwise
        return true;
    }

    @Override public boolean performClick() { return super.performClick(); }
}
