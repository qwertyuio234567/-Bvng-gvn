package com.pianohell;

/**
 * AudioEngine — Java side of the native audio engine.
 *
 * <p>All real work happens in C++ ({@code app/src/main/cpp/NativeAudioEngine.cpp}) because the
 * spec's constraints cannot be met from Java:
 * <ul>
 *   <li><b>Latency.</b> Oboe → AAudio LowLatency gives 5–15 ms touch-to-sound on real devices.
 *       MediaPlayer (~200 ms+), SoundPool (~40–80 ms, plus a stream ceiling) and Gervill (nonexistent
 *       on Android, and too slow at black-MIDI density) are all disqualified.</li>
 *   <li><b>Polyphony.</b> A 5M-note chart can put 100+ overlapping voices in flight. The native
 *       mixer holds a fixed pool of 96 preallocated voices and a lock-free ring buffer for events,
 *       so the render callback never allocates, locks, or blocks.</li>
 *   <li><b>Timing.</b> The native stream reports the frame count it has actually played, which the
 *       game loop uses as its clock. Counting frames in Java would drift against the DAC.</li>
 * </ul>
 *
 * <p><b>Graceful degradation.</b> If the JNI library is missing (an ABI the device does not
 * support, a broken build) or Oboe cannot open a stream, this class turns into a silent no-op and
 * reports the reason. The game stays fully playable and judges normally — we deliberately do NOT
 * silently fall back to SoundPool/MediaPlayer, because a late sound is worse than no sound in a
 * rhythm game: it would look like the judgment was wrong. The failure is surfaced in the HUD.
 */
public final class AudioEngine {

    private static final String TAG = "PianoHellAudio";

    /**
     * Fixed voice pool on the native side. Kept here too so the HUD can show what is being used.
     * Matches kVoices in NativeAudioEngine.h.
     */
    public static final int MAX_VOICES = 96;

    private boolean libraryLoaded;
    private boolean started;
    private String statusMessage = "audio: not initialised";
    /** Lane → MIDI pitch the chart maps to that lane. Set per run from {@link MidiMapper}. */
    private final int[] lanePitch = new int[GameConfig.LANES];
    private float masterVolume = 0.85f;
    private int sampleRate;

    // ------------------------------------------------------------------
    // Native declarations. Names must match the C++ symbols in PianoHellJni.cpp
    // (Java_<package>_<class>_<method>) — there is no annotation processor here on purpose.
    // ------------------------------------------------------------------
    private static native boolean nativeCreate();
    private static native boolean nativeStart();
    private static native void nativeStop();
    private static native void nativeRelease();
    private static native void nativeNoteOn(int pitch, float velocity);
    private static native void nativeNoteOff(int pitch);
    private static native void nativeAllNotesOff();
    private static native void nativeSetLanePitch(int lane, int pitch);
    private static native void nativeSetLanePitches(int[] pitches);
    private static native void nativeSetMasterVolume(float volume);
    private static native void nativeSetSample(int lane, float[] data, int length, int rootPitch);
    private static native long nativePositionMs();
    private static native int nativeActiveVoices();
    private static native int nativeSampleRate();
    private static native int nativeXruns();
    private static native boolean nativeIsRunning();
    private static native void nativeResetClock();
    private static native boolean nativeIsHealthy();
    private static native int nativeLastError();

    /** Set once by {@link #libraryAvailable()}: true when libpianohell.so loaded for this ABI. */
    private static Boolean libraryOk = null;

    static {
        // loaded = false keeps the whole class usable even if the .so is absent.
    }

    /**
     * Is the native audio library present and loadable on this device/ABI? Does NOT open a stream
     * and has no side effects, so it is safe to call from a menu or a settings screen.
     *
     * <p>The menu used to construct a throwaway AudioEngine just to print its status; that opens and
     * closes a low-latency AAudio stream during launch, which is exactly the kind of work that can
     * fail on a device that refuses Exclusive/low-latency sharing — and a failure there took the
     * whole menu down with it. Probing availability is enough for a status line.
     */
    public static synchronized boolean libraryAvailable() {
        if (libraryOk != null) return libraryOk;
        try {
            System.loadLibrary("pianohell");
            libraryOk = nativeCreate();
        } catch (Throwable t) {
            android.util.Log.w(TAG, "native audio unavailable", t);
            libraryOk = false;
        }
        return libraryOk;
    }

    public AudioEngine() {
        try {
            System.loadLibrary("pianohell");
            libraryLoaded = nativeCreate();
            if (libraryLoaded) {
                started = nativeStart();
                sampleRate = nativeSampleRate();
                setStatus(started
                        ? "audio: Oboe " + sampleRate + " Hz, low-latency, " + MAX_VOICES + " voices"
                        : "audio: native lib loaded but no output stream (silent)");
            } else {
                setStatus("audio: native init failed (silent)");
            }
        } catch (Throwable e) {
            // Deliberately Throwable: a device that refuses the audio path must not take the game
            // down with it. The engine degrades to silent and says so in the HUD.
            libraryLoaded = false;
            started = false;
            setStatus("audio: native init failed (" + e.getClass().getSimpleName() + ") — silent");
        }
        if (libraryLoaded) nativeSetMasterVolume(masterVolume);
    }

    /** Long, human-readable status for the menu / HUD / crash reports. */
    public String describe() {
        if (!libraryLoaded) return statusMessage;
        return statusMessage + (started ? " · healthy=" + nativeIsHealthy() + " · voices=" + nativeActiveVoices()
                + " · xruns=" + nativeXruns() : "");
    }

    private void setStatus(String s) {
        statusMessage = s;
        android.util.Log.i(TAG, s);
    }

    // ------------------------------------------------------------------
    // Run lifecycle
    // ------------------------------------------------------------------

    /**
     * Called when a run starts: install the lane → pitch table so a lane hit sounds the same note
     * the chart used, and zero the audio clock that the game syncs to.
     */
    public void onRunStart(MidiMapper mapper) {
        if (!libraryLoaded) return;
        int[] pitches = mapper != null ? mapper.lanePlaybackPitches() : lanePitch;
        System.arraycopy(pitches, 0, lanePitch, 0, GameConfig.LANES);
        nativeSetLanePitches(lanePitch);
        nativeAllNotesOff();
        nativeResetClock();
    }

    public void onRunPause() { if (libraryLoaded) nativeAllNotesOff(); }

    public void onRunResume() { if (libraryLoaded) nativeResetClock(); }

    // ------------------------------------------------------------------
    // Note trigger — the hot path (called for every judged note)
    // ------------------------------------------------------------------

    /** Fire one voice at a MIDI pitch. Returns immediately: the sample is mixed by the RT thread. */
    public void noteOn(int midiPitch, float velocity) {
        if (!started) return;
        nativeNoteOn(midiPitch, velocity * masterVolume);
    }

    /** Convenience overload used by the engine: play whatever pitch lane {@code lane} maps to. */
    public void noteOnLane(int lane, float velocity) {
        noteOn(lanePitch[lane % GameConfig.LANES], velocity);
    }

    public void noteOff(int midiPitch) { if (started) nativeNoteOff(midiPitch); }

    public void allNotesOff() { if (libraryLoaded) nativeAllNotesOff(); }

    // ------------------------------------------------------------------
    // Clock + diagnostics
    // ------------------------------------------------------------------

    /** Milliseconds of audio actually played since the run started, or -1 when there is no audio. */
    public long playbackPositionMs() { return started ? nativePositionMs() : -1; }

    public boolean isReady() { return started; }

    /** Library loaded AND the stream is actually running without a reported error. */
    public boolean isHealthy() { return started && libraryLoaded && nativeIsHealthy(); }

    public int lastNativeError() { return libraryLoaded ? nativeLastError() : -1; }

    public String status() { return statusMessage; }

    public int activeVoices() { return started ? nativeActiveVoices() : 0; }

    public int xruns() { return libraryLoaded ? nativeXruns() : 0; }

    public void setMasterVolume(float v) {
        masterVolume = Math.max(0f, Math.min(1f, v));
        if (libraryLoaded) nativeSetMasterVolume(masterVolume);
    }

    /**
     * Swap in a real instrument sample for one lane (e.g. a WAV/SoundFont render decoded to mono
     * floats). Must be called while the engine is stopped; see the C++ side.
     */
    public void installSample(int lane, float[] mono, int rootPitch) {
        if (libraryLoaded) nativeSetSample(lane, mono, mono.length, rootPitch);
    }

    /** Release the native stream + engine. Safe to call more than once. */
    public void release() {
        if (libraryLoaded) {
            nativeStop();
            nativeRelease();
            libraryLoaded = false;
            started = false;
        }
    }
}
