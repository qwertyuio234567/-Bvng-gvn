package com.pianohell;

import android.app.Application;
import android.content.Context;

/**
 * PhApp — holds the application Context for the few places that need it outside a lifecycle
 * (best-score prefs, asset loading, cache dir for the binary chart format). A static Context is the
 * usual leak trap, so only the APPLICATION context is stored, never an Activity.
 */
public final class PhApp extends Application {

    private static PhApp instance;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        // Installed before anything else so a failure in any later initialisation is captured.
        CrashLog.install(this);
    }

    public static Context get() {
        return instance != null ? instance : null;
    }
}
