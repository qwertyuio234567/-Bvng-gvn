package com.pianohell;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * GameConfig — every tunable in one place, persisted to SharedPreferences.
 *
 * <p>Kept as plain public fields (not getters) because the game loop reads several of them per
 * note per frame; the JIT inlines field reads of a final-ish object far better than virtual calls.
 */
public final class GameConfig {

    // ------------------------- board geometry -------------------------
    /** Spec: exactly 12 vertical lanes. */
    public static final int LANES = 12;
    /** Shortest thing we call a "hold". Below this a note is a tap tile. */
    public static final int MIN_HOLD_MS = 100;
    /** Longest hold we will render/score before we clamp it (guards against 30-minute pedal notes). */
    public static final int MAX_EXPECTED_HOLD_MS = 20_000;

    // ------------------------- scroll / timing -------------------------
    /** Note travel time from top of screen to the hit line, in ms. Lower = faster = harder. */
    public int scrollMs = 900;
    /** Hit line height as a fraction of the surface height (Piano-Tiles style: near the bottom). */
    public float hitLineYFraction = 0.86f;
    /** Judgment windows in ms. Tunable per difficulty (see PRESETS). */
    public int perfectMs = 60;
    public int goodMs = 120;
    /** A hold released this many ms before its tail is only PARTIAL, not a MISS. */
    public int holdReleaseToleranceMs = 90;
    /** Global input/audio calibration, added to every note's judged time. */
    public int audioOffsetMs = 0;

    // ------------------------- mapping (import) -------------------------
    public static final int MAP_PITCH_CLASS = 0;      // lane = pitch % 12   (default, chromatic)
    public static final int MAP_SCALE = 1;            // quantize to nearest degree of a scale/key
    public static final int MAP_DENSITY = 2;          // 12 most-used pitches in this file get their own lane
    public int mappingMode = MAP_PITCH_CLASS;
    public int scaleIndex = 0;                        // index into MidiMapper.SCALES
    public int rootNote = 0;                          // 0..11 pitch class
    /** Same-lane notes closer than this are collapsed into one tile / stretched to a hold. */
    public int collapseMs = 45;
    /** Channel 10 (index 9) is percussion in GM; usually boring for a piano game. */
    public boolean ignoreDrums = true;

    // ------------------------- gameplay -------------------------
    public boolean suddenDeath = true;                // Piano-Tiles style: one miss = fail. false = endless/practice
    public boolean colorByChannel = true;             // imported charts: per-note color from MIDI channel
    public boolean colorByVelocity = false;           // ...or from velocity buckets
    public boolean showDiagnostics = false;           // FPS / active tile counter (Options)
    public int difficulty = 3;                        // index into DIFFICULTY[]
    public int themeIndex = 0;                        // NoteColors theme

    /** Judgment presets: {name, perfect ms, good ms, hold release tolerance ms}. */
    public static final String[][] DIFFICULTY = {
            {"Easy",   "90", "160", "140"},
            {"Normal", "60", "120", "100"},
            {"Hard",   "45",  "90",  "80"},
            {"Hell",   "35",  "70",  "60"},
            {"Black",  "25",  "55",  "45"},
    };

    public void applyDifficulty(int index) {
        difficulty = Math.max(0, Math.min(DIFFICULTY.length - 1, index));
        perfectMs = Integer.parseInt(DIFFICULTY[difficulty][1]);
        goodMs = Integer.parseInt(DIFFICULTY[difficulty][2]);
        holdReleaseToleranceMs = Integer.parseInt(DIFFICULTY[difficulty][3]);
    }

    // ------------------------- persistence -------------------------
    private static final String PREF = "pianohell";

    public static GameConfig load(Context ctx) {
        GameConfig c = new GameConfig();
        SharedPreferences p = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        c.scrollMs = p.getInt("scrollMs", c.scrollMs);
        c.collapseMs = p.getInt("collapseMs", c.collapseMs);
        c.mappingMode = p.getInt("mappingMode", c.mappingMode);
        c.scaleIndex = p.getInt("scaleIndex", c.scaleIndex);
        c.rootNote = p.getInt("rootNote", c.rootNote);
        c.ignoreDrums = p.getBoolean("ignoreDrums", c.ignoreDrums);
        c.suddenDeath = p.getBoolean("suddenDeath", c.suddenDeath);
        c.colorByChannel = p.getBoolean("colorByChannel", c.colorByChannel);
        c.colorByVelocity = p.getBoolean("colorByVelocity", c.colorByVelocity);
        c.showDiagnostics = p.getBoolean("showDiagnostics", c.showDiagnostics);
        c.audioOffsetMs = p.getInt("audioOffsetMs", c.audioOffsetMs);
        c.themeIndex = p.getInt("themeIndex", c.themeIndex);
        c.applyDifficulty(p.getInt("difficulty", c.difficulty));
        return c;
    }

    public void save(Context ctx) {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
                .putInt("scrollMs", scrollMs)
                .putInt("collapseMs", collapseMs)
                .putInt("mappingMode", mappingMode)
                .putInt("scaleIndex", scaleIndex)
                .putInt("rootNote", rootNote)
                .putBoolean("ignoreDrums", ignoreDrums)
                .putBoolean("suddenDeath", suddenDeath)
                .putBoolean("colorByChannel", colorByChannel)
                .putBoolean("colorByVelocity", colorByVelocity)
                .putBoolean("showDiagnostics", showDiagnostics)
                .putInt("audioOffsetMs", audioOffsetMs)
                .putInt("themeIndex", themeIndex)
                .putInt("difficulty", difficulty)
                .apply();
    }

    public GameConfig copy() {
        GameConfig c = new GameConfig();
        c.scrollMs = scrollMs; c.hitLineYFraction = hitLineYFraction;
        c.perfectMs = perfectMs; c.goodMs = goodMs;
        c.holdReleaseToleranceMs = holdReleaseToleranceMs; c.audioOffsetMs = audioOffsetMs;
        c.mappingMode = mappingMode; c.scaleIndex = scaleIndex; c.rootNote = rootNote;
        c.collapseMs = collapseMs; c.ignoreDrums = ignoreDrums;
        c.suddenDeath = suddenDeath; c.colorByChannel = colorByChannel;
        c.colorByVelocity = colorByVelocity; c.showDiagnostics = showDiagnostics;
        c.difficulty = difficulty; c.themeIndex = themeIndex;
        return c;
    }
}
