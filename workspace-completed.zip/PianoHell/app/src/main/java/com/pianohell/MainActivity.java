package com.pianohell;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * MainActivity — landscape-locked menu.
 *
 * <p>Responsibilities: landscape lock (manifest + {@link OrientationGuard}), a way into the preset
 * list and the MIDI importer, and the global options that every chart load reads through
 * {@link GameConfig}. No game code lives here — the menu must never touch the render thread's data.
 */
public final class MainActivity extends Activity {

    private GameConfig cfg;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cfg = GameConfig.load(this);
        setContentView(R.layout.activity_main);
        OrientationGuard.install(this, findViewById(R.id.root));

        findViewById(R.id.btnPresets).setOnClickListener(v ->
                startActivity(new Intent(this, PresetListActivity.class)
                        .putExtra("screen", PresetListActivity.SCREEN_PRESETS)));

        findViewById(R.id.btnImport).setOnClickListener(v ->
                startActivity(new Intent(this, PresetListActivity.class)
                        .putExtra("screen", PresetListActivity.SCREEN_IMPORT)));

        setupOptionsPanel();
        showCrashHint();
        CrashLog.noteCleanRun(this);        // two good launches retire the previous report
    }

    /**
     * If the previous run died, say so under the menu with the exception line and a share button.
     * Without this, an early-startup crash is just "the app keeps stopping" with no way to tell why.
     */
    private void showCrashHint() {
        final String summary = CrashLog.summary(this);
        if (summary == null) return;
        LinearLayout row = findViewById(R.id.optionsPanel);
        TextView hint = new TextView(this);
        hint.setText("LAST RUN CRASHED:\n" + summary);
        hint.setTextColor(0xFFFF6B6B);
        hint.setTextSize(12f);
        Button share = new Button(this);
        share.setText("SHARE CRASH REPORT");
        share.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "Piano Hell crash report");
            i.putExtra(Intent.EXTRA_TEXT, String.valueOf(CrashLog.last(MainActivity.this)));
            startActivity(Intent.createChooser(i, "Share crash report"));
        });
        Button dismiss = new Button(this);
        dismiss.setText("DISMISS");
        dismiss.setOnClickListener(v -> {
            CrashLog.clear(MainActivity.this);
            findViewById(R.id.optionsPanel).setVisibility(View.GONE);
        });
        findViewById(R.id.optionsPanel).setVisibility(View.VISIBLE);   // the panel starts hidden
        row.addView(hint);
        row.addView(share);
        row.addView(dismiss);
    }

    @Override protected void onResume() {
        super.onResume();
        cfg = GameConfig.load(this);
        refreshLastPlayed();
        refreshOptionsSummary();
    }

    private void refreshLastPlayed() {
        TextView t = findViewById(R.id.lastPlayedText);
        StringBuilder sb = new StringBuilder();
        // Only a library-load check here: the menu must never open an audio stream during launch
        // (see AudioEngine.libraryAvailable). The real stream is opened in GameActivity, inside a
        // guard, and its health is reported in the game HUD.
        sb.append("audio: ").append(AudioEngine.libraryAvailable()
                ? "libpianohell.so loaded · 96-voice Oboe engine"
                : "native audio unavailable for this ABI (game still playable, silent)");
        String[] cached = ChartIO.cacheDir(this).list();
        sb.append("\nchart cache: ").append(cached == null ? 0 : cached.length).append(" charts");
        t.setText(sb.toString());
    }

    /**
     * Options: the ones that must be decided before a chart is imported (mapping strategy lives on
     * the import screen, because it changes the lane assignment) plus the gameplay toggles.
     */
    private void setupOptionsPanel() {
        final LinearLayout panel = findViewById(R.id.optionsPanel);
        findViewById(R.id.btnOptions).setOnClickListener(v -> {
            boolean show = panel.getVisibility() != View.VISIBLE;
            panel.setVisibility(show ? View.VISIBLE : View.GONE);
            if (show) buildOptions(panel);
        });
    }

    private void buildOptions(LinearLayout panel) {
        if (panel.getChildCount() > 0) return;         // already built (or a crash hint is in there)
        CheckBox death = new CheckBox(this);
        death.setText(R.string.opt_health);
        death.setChecked(cfg.suddenDeath);
        death.setTextColor(0xFFEDEDF5);
        death.setOnCheckedChangeListener((b, on) -> { cfg.suddenDeath = on; cfg.save(this); });

        CheckBox chan = new CheckBox(this);
        chan.setText(R.string.opt_colors);
        chan.setChecked(cfg.colorByChannel);
        chan.setTextColor(0xFFEDEDF5);
        chan.setOnCheckedChangeListener((b, on) -> { cfg.colorByChannel = on; cfg.save(this); });

        CheckBox diag = new CheckBox(this);
        diag.setText(R.string.opt_show_fps);
        diag.setChecked(cfg.showDiagnostics);
        diag.setTextColor(0xFFEDEDF5);
        diag.setOnCheckedChangeListener((b, on) -> { cfg.showDiagnostics = on; cfg.save(this); });

        TextView offLabel = new TextView(this);
        offLabel.setText("Audio/judgment offset: " + cfg.audioOffsetMs + " ms");
        offLabel.setTextColor(0xFF8A8AA0);

        android.widget.SeekBar offset = new android.widget.SeekBar(this);
        offset.setMax(200);
        offset.setProgress(cfg.audioOffsetMs + 100);
        offset.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                if (!fromUser) return;
                cfg.audioOffsetMs = progress - 100;
                offLabel.setText("Audio/judgment offset: " + cfg.audioOffsetMs + " ms");
                cfg.save(MainActivity.this);
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) { }
        });

        TextView diffLabel = new TextView(this);
        diffLabel.setText("Judgment difficulty windows");
        diffLabel.setTextColor(0xFF8A8AA0);

        android.widget.Spinner diff = new android.widget.Spinner(this);
        android.widget.ArrayAdapter<String> da = new android.widget.ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, getResources().getStringArray(R.array.difficulty_names));
        diff.setAdapter(da);
        diff.setSelection(cfg.difficulty);
        diff.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                cfg.applyDifficulty(pos);
                cfg.save(MainActivity.this);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) { }
        });

        panel.addView(death);
        panel.addView(chan);
        panel.addView(diag);
        panel.addView(offLabel);
        panel.addView(offset);
        panel.addView(diffLabel);
        panel.addView(diff);
    }

    private void refreshOptionsSummary() {
        LinearLayout panel = findViewById(R.id.optionsPanel);
        if (panel != null && panel.getVisibility() == View.VISIBLE) buildOptions(panel);
    }
}
