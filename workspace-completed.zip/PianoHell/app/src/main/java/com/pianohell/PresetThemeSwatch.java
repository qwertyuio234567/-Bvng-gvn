package com.pianohell;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * PresetThemeSwatch — the little 12-lane "preview colour theme" thumbnail on each preset row.
 *
 * <p>It is a tiny custom View that paints the theme's palette plus a few fake tiles, so the player
 * can see what a chart will look like before loading it. It draws once and caches; a RecyclerView
 * row is not a place for anything clever.
 */
public final class PresetThemeSwatch extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private NoteColors colors = new NoteColors(0);
    private int themeIndex = 0;
    /** A few pseudo-random but stable tile positions per theme so each swatch looks different. */
    private final float[] tileY = new float[6];
    private final int[] tileLane = new int[6];

    public PresetThemeSwatch(Context c) { this(c, null); }

    public PresetThemeSwatch(Context c, AttributeSet a) {
        super(c, a);
        java.util.Random r = new java.util.Random(0x5EED);
        for (int i = 0; i < tileY.length; i++) {
            tileY[i] = 0.08f + r.nextFloat() * 0.72f;
            tileLane[i] = r.nextInt(12);
        }
    }

    public void setTheme(int themeIndex) {
        if (this.themeIndex == themeIndex) return;
        this.themeIndex = themeIndex;
        colors = new NoteColors(themeIndex);
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        final float w = getWidth(), h = getHeight();
        float laneW = w / 12f;
        int[] pal = colors.raw();

        paint.setColor(0xFF07070C);
        canvas.drawRect(0, 0, w, h, paint);

        // lane stripes
        for (int l = 0; l < 12; l++) {
            paint.setColor(NoteColors.blend(0xFF07070C, pal[l], 40));
            canvas.drawRect(l * laneW, 0, (l + 1) * laneW, h, paint);
        }
        // fake tiles in the theme colours
        for (int i = 0; i < tileY.length; i++) {
            int l = tileLane[i];
            paint.setColor(pal[l]);
            float y = tileY[i] * h;
            canvas.drawRect(l * laneW + 1, y, (l + 1) * laneW - 1 + (i % 3 == 0 ? laneW : 0),
                    y + h * 0.18f, paint);
        }
        // hit line
        paint.setColor(0xFFFFFFFF);
        canvas.drawRect(0, h * 0.86f, w, h * 0.86f + 2f, paint);
    }
}
