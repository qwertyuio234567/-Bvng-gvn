package com.pianohell;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

/**
 * MidiParser — a hand-written Standard MIDI File (SMF) reader.
 *
 * <h3>Why not Android's MIDI stack?</h3>
 * <ol>
 *   <li>{@code android.media.midi} is a router to physical/virtual MIDI <i>devices</i>; its Java
 *       API cannot read a file at all, and it exposes no tick/channel/velocity metadata.</li>
 *   <li>javax.sound.midi's Gervill is a real-time soft synth with a scheduler thread. Feeding it a
 *       black-MIDI file (10^5..10^6 note-ons, often &gt;1000 events/second) makes it drop events and
 *       stall — and it is not on Android. Wrong output at this density, on top of being unavailable.</li>
 *   <li>We need (tick, channel, velocity, duration, tempo) per note to MAP 128 pitches onto 12 lanes.
 *       A player does not expose that.</li>
 * </ol>
 *
 * <h3>Design for million-note files</h3>
 * <ul>
 *   <li><b>Two streaming passes, no whole-file buffer.</b> Pass 1 collects the tempo map + pitch and
 *       channel histograms (note events are counted, not stored). Pass 2 walks the tracks again and
 *       appends notes STRAIGHT into the flat primitive arrays of {@link ChartData}. Peak memory is a
 *       1 MB sliding window plus the chart — a 300 MB black-MIDI file never becomes a 300 MB byte[].</li>
 *   <li><b>Zero objects per note</b> in either pass (no Note/Event class anywhere).</li>
 *   <li><b>Full spec coverage:</b> VLQ delta times, running status (used heavily by black-MIDI
 *       generators to halve file size), all channel message lengths, meta events (tempo 0x51,
 *       end-of-track 0x2F), sysex skipping, and SMPTE as well as PPQ divisions.</li>
 *   <li><b>Cancellable + progress</b> so {@link ChartLoader} can run it on a worker thread with a
 *       responsive progress bar.</li>
 * </ul>
 *
 * <h3>Format implemented (exactly)</h3>
 * <pre>
 *  Header : "MThd" len=6 format(2) ntrks(2) division(2)
 *  Track  : "MTrk" len(4) (deltaVLQ + event)*
 *   0x8n note off (2 data)   0x9n note on (2) [vel 0 == off]
 *   0xAn aftertouch (2)      0xBn controller (2)     0xCn program (1)
 *   0xDn channel pressure (1) 0xEn pitch bend (2)
 *   0xFF meta: type(1) len(VLQ) data  — 0x51 tempo(3 bytes us/quarter), 0x2F end of track
 *   0xF0 / 0xF7 sysex: len(VLQ) data (skipped)
 *  division: bit15==0 -> ticks per quarter note ; bit15==1 -> SMPTE (-fps in hi byte, ticks/frame in lo)
 * </pre>
 */
public final class MidiParser {

    /** Ceiling on a single note's length. Black-MIDI files love dangling note-ons; we clamp them. */
    private static final int MAX_NOTE_MS = GameConfig.MAX_EXPECTED_HOLD_MS;

    // ==================================================================
    // Sources
    // ==================================================================

    /** Something that can be opened twice: pass 1 (scan) and pass 2 (emit). */
    public interface Source {
        InputStream open() throws IOException;
        long length();                // -1 when unknown
        String name();
    }

    /** In-memory bytes: bundled assets and the custom .phc chart format. */
    public static final class BytesSource implements Source {
        private final byte[] data;
        private final String name;
        public BytesSource(byte[] data, String name) { this.data = data; this.name = name; }
        @Override public InputStream open() { return new ByteArrayInputStream(data); }
        @Override public long length() { return data.length; }
        @Override public String name() { return name; }
    }

    /** Progress + cancellation callback. Called from the parser thread; never touches UI directly. */
    public interface Listener {
        void onProgress(int percent, long notesSeen, String stage);
        boolean isCancelled();
    }

    /** Statistics from pass 1 — feeds {@link MidiMapper} and the difficulty rating. */
    public static final class Stats {
        public final int[] pitchHistogram = new int[128];
        public final int[] channelHistogram = new int[16];
        public long noteOnCount;                  // raw note-ons, before mapping/collapsing: the "hell factor"
        public long noteOffCount;
        public int trackCount;
        public int format;
        public int tempoChanges;
        public long lastNoteTick = -1;
        public int ticksPerQuarter = 480;
        public boolean smpte;
        public double initialBpm = 120;
        public long lengthMs;
        public long parseMs;

        /** Note-ons per second of chart. 1 = calm, 50 = piano roll, 300+ = black MIDI. */
        public int notesPerSecond() {
            return lengthMs <= 0 ? 0 : (int) (noteOnCount * 1000L / lengthMs);
        }
    }

    // ==================================================================
    // Public entry point
    // ==================================================================

    /**
     * Parse {@code src} and append chart notes into {@code out}. Notes arrive track-by-track, so
     * {@code out} is left for {@link ChartData#finishLoad()} to sort (that is the radix-sort path).
     * The caller supplies the mapping (already prepared with the pass-1 histogram) and the collapse
     * threshold; collapsing runs after the sort so it also catches cross-track overlaps.
     */
    public static Stats parse(Source src, MidiMapper mapperOut, GameConfig cfg, ChartData out, Listener listener)
            throws IOException {

        final long t0 = System.nanoTime();
        Stats stats = new Stats();
        TempoMap tempo = new TempoMap();

        // -------- pass 1: tempo map + histograms (cheap: no writes to the chart) --------
        cancelCheck(listener);
        report(listener, 0, 0, "Scanning MIDI header…");
        scan(src, stats, tempo, null, null, listener, true);
        if (tempo.entries == 0) tempo.add(0, 500_000);     // no tempo events at all => 120 BPM
        tempo.finalise();
        stats.tempoChanges = tempo.entries;
        stats.initialBpm = 60_000_000.0 / tempo.micros[0];
        if (!stats.smpte && stats.ticksPerQuarter > 0 && stats.lastNoteTick > 0) {
            stats.lengthMs = tempo.tickToMs(stats.lastNoteTick);
        } else if (stats.lastNoteTick > 0) {
            stats.lengthMs = tempo.tickToMs(stats.lastNoteTick);
        }

        cancelCheck(listener);
        report(listener, 10, stats.noteOnCount, "Mapping 128 pitches → 12 lanes…");
        mapperOut.prepare(stats.pitchHistogram, cfg);

        // -------- pass 2: emit into flat arrays --------
        report(listener, 12, 0, "Writing note events…");
        NoteWriter writer = new NoteWriter(mapperOut, cfg, out, tempo);
        scan(src, stats, tempo, writer, cfg, listener, false);
        writer.flushDangling();

        report(listener, 95, out.count, "Sorting by time (radix)…");
        out.finishLoad();
        if (cfg.collapseMs > 0) {
            report(listener, 97, out.count, "De-overlapping same-lane notes…");
            if (out.collapsePass(cfg.collapseMs, true) > 0) out.recomputeLength();
        }
        out.bpm = (int) Math.round(stats.initialBpm);
        out.noteOnCount = (int) Math.min(Integer.MAX_VALUE, stats.noteOnCount);
        out.mappingMode = cfg.mappingMode;
        out.scaleIndex = cfg.scaleIndex;
        out.rootNote = cfg.rootNote;
        out.isPreset = false;
        out.lengthMs = out.lengthMs > 0 ? out.lengthMs : stats.lengthMs;
        out.difficultyRating = rateDifficulty(stats.notesPerSecond());

        report(listener, 100, out.count, "Done");
        stats.lengthMs = out.lengthMs;
        stats.parseMs = (System.nanoTime() - t0) / 1_000_000L;
        return stats;
    }

    /** 1..12 stars, driven purely by measured note density. */
    public static int rateDifficulty(int notesPerSecond) {
        int[] thresholds = { 3, 6, 10, 16, 24, 36, 50, 70, 100, 150, 220, 320 };
        int r = 1;
        for (int t : thresholds) if (notesPerSecond >= t) r++;
        return Math.min(12, r);
    }

    private static void report(Listener l, int pct, long notes, String stage) {
        if (l != null) l.onProgress(pct, notes, stage);
    }

    private static void cancelCheck(Listener l) throws IOException {
        if (l != null && l.isCancelled()) throw new IOException("Import cancelled");
    }

    // ==================================================================
    // Tempo map: ticks -> milliseconds, no allocation in the hot path
    // ==================================================================

    /**
     * Tempo map with precomputed cumulative milliseconds per tempo change. {@code tickToMs} is then
     * a binary search (or a cached cursor while ticks advance) plus one multiply — cheap enough to
     * call per note event at millions of events.
     */
    static final class TempoMap {
        long[] ticks = new long[256];
        int[] micros = new int[256];
        long[] cumMs = new long[256];
        int entries = 0;
        int ticksPerQuarter = 480;
        boolean smpte;
        int smpteTicksPerSecond = 48000;
        private int cursor = 0;

        void add(long tick, int usPerQuarter) {
            if (entries > 0 && ticks[entries - 1] == tick) { micros[entries - 1] = usPerQuarter; return; }
            if (entries == ticks.length) {
                ticks = java.util.Arrays.copyOf(ticks, entries * 2);
                micros = java.util.Arrays.copyOf(micros, entries * 2);
                cumMs = java.util.Arrays.copyOf(cumMs, entries * 2);
            }
            ticks[entries] = tick;
            micros[entries] = usPerQuarter;
            entries++;
        }

        void finalise() {
            if (entries == 0) add(0, 500_000);
            // A file whose first tempo meta event is NOT at tick 0 (very common: the composer emits
            // it after the track-name/author metas, or the generator only writes changes) means the
            // interval [0, firstTempo) has an implied 120 BPM. Without this entry tickToMs() would
            // extrapolate backwards from the first tempo and return NEGATIVE milliseconds.
            if (ticks[0] != 0) {
                if (entries == ticks.length) {
                    ticks = java.util.Arrays.copyOf(ticks, entries * 2);
                    micros = java.util.Arrays.copyOf(micros, entries * 2);
                    cumMs = java.util.Arrays.copyOf(cumMs, entries * 2);
                }
                System.arraycopy(ticks, 0, ticks, 1, entries);
                System.arraycopy(micros, 0, micros, 1, entries);
                ticks[0] = 0;
                micros[0] = 500_000;
                entries++;
            }
            long ms = 0, prevTick = ticks[0];
            cumMs[0] = 0;
            for (int i = 1; i < entries; i++) {
                ms += (ticks[i] - prevTick) * micros[i - 1] / (ticksPerQuarter * 1000L);
                cumMs[i] = ms;
                prevTick = ticks[i];
            }
            cursor = 0;
        }

        long tickToMs(long tick) {
            if (smpte) return tick * 1000L / smpteTicksPerSecond;
            if (ticksPerQuarter <= 0) return tick;
            int i = findSegment(tick);
            return cumMs[i] + (tick - ticks[i]) * micros[i] / (ticksPerQuarter * 1000L);
        }

        private int findSegment(long tick) {
            // Ticks advance monotonically through a file, so remember where we are (O(1) typical).
            int i = cursor;
            if (i < entries && ticks[i] <= tick) {
                while (i + 1 < entries && ticks[i + 1] <= tick) i++;
                cursor = i;
                return i;
            }
            int lo = 0, hi = entries - 1;
            while (lo < hi) {
                int mid = (lo + hi + 1) >>> 1;
                if (ticks[mid] <= tick) lo = mid; else hi = mid - 1;
            }
            cursor = lo;
            return lo;
        }
    }

    // ==================================================================
    // Pass 2 note writer: pairs note-on/note-off, writes into ChartData
    // ==================================================================

    /**
     * Turns note events into chart rows.
     *
     * <p>Note pairing uses ONE LIFO stack per (channel, pitch) — 2048 slots. A single "last note"
     * slot per key is not enough: black-MIDI generators stack thousands of overlapping notes on the
     * same pitch, and a LIFO stack is what makes their tails land on the right tiles.
     *
     * <p>Everything here appends; the sort happens later in {@link ChartData#finishLoad()}.
     */
    static final class NoteWriter {
        private final MidiMapper mapper;
        private final GameConfig cfg;
        private final ChartData chart;
        private final TempoMap tempo;

        private final int[] depth = new int[16 * 128];
        private final int[][] stackIdx = new int[16 * 128][];   // chart row of each open note (perpitch stack)
        private final long[][] stackMs = new long[16 * 128][];  // its start time in ms

        NoteWriter(MidiMapper mapper, GameConfig cfg, ChartData chart, TempoMap tempo) {
            this.mapper = mapper; this.cfg = cfg; this.chart = chart; this.tempo = tempo;
        }

        void noteOn(int channel, int pitch, int velocity, long tick) {
            if (cfg.ignoreDrums && channel == 9) return;                  // GM channel 10 = percussion
            long t = tempo.tickToMs(tick);
            int lane = mapper.laneOf(pitch);
            int color = mapper.colorOf(pitch, channel, velocity, cfg);
            int idx = chart.count;
            chart.append(lane, t, 0, color, pitch);                       // duration is patched on note-off
            int slot = channel * 128 + pitch;
            if (stackIdx[slot] == null) { stackIdx[slot] = new int[4]; stackMs[slot] = new long[4]; }
            if (depth[slot] == stackIdx[slot].length) {
                stackIdx[slot] = java.util.Arrays.copyOf(stackIdx[slot], depth[slot] * 2);
                stackMs[slot] = java.util.Arrays.copyOf(stackMs[slot], depth[slot] * 2);
            }
            stackIdx[slot][depth[slot]] = idx;
            stackMs[slot][depth[slot]] = t;
            depth[slot]++;
        }

        void noteOff(int channel, int pitch, long tick) {
            int slot = channel * 128 + pitch;
            if (depth[slot] <= 0) return;                                  // unmatched note-off: ignore
            int n = --depth[slot];
            long t = tempo.tickToMs(tick);
            int dur = (int) Math.max(0, Math.min(MAX_NOTE_MS, t - stackMs[slot][n]));
            chart.patchDuration(stackIdx[slot][n], dur);
        }

        /**
         * Called at the end of every MTrk. Black-MIDI and badly exported files leave note-ons
         * dangling; clamping them to the track's last tick is what stops an "infinite" tile that
         * would otherwise sit under the hit line forever and never judge.
         */
        void flushTrack(long endTick) {
            long endMs = tempo.tickToMs(endTick);
            for (int slot = 0; slot < depth.length; slot++) {
                while (depth[slot] > 0) {
                    int n = --depth[slot];
                    int dur = (int) Math.max(0, Math.min(MAX_NOTE_MS, endMs - stackMs[slot][n]));
                    chart.patchDuration(stackIdx[slot][n], dur);
                }
            }
        }

        /** Belt-and-braces call after the whole file: nothing should be open here. */
        void flushDangling() {
            for (int slot = 0; slot < depth.length; slot++) {
                while (depth[slot] > 0) {
                    chart.patchDuration(stackIdx[slot][--depth[slot]], 200);
                }
            }
            chart.recomputeLength();
        }
    }

    // ==================================================================
    // The scanner (shared by both passes)
    // ==================================================================

    /**
     * One implementation, two modes:
     * <ul>
     *   <li>{@code writer == null} → pass 1: build the tempo map, histograms, and format stats.</li>
     *   <li>{@code writer != null} → pass 2: convert ticks→ms and write notes into the chart.</li>
     * </ul>
     * Both modes run on the same sequential reader, so the file is read exactly twice and never
     * fully materialised in memory.
     */
    private static void scan(Source src, Stats stats, TempoMap tempo, NoteWriter writer, GameConfig cfg,
                             Listener listener, boolean firstPass) throws IOException {

        SeekableInput in = new SeekableInput(src.open(), src.length());
        try {
            byte[] hdr = new byte[8];
            in.readFully(hdr, 8);
            if (hdr[0] != 'M' || hdr[1] != 'T' || hdr[2] != 'h' || hdr[3] != 'd')
                throw new IOException("Not a Standard MIDI File (no MThd chunk)");
            int hlen = be32(hdr, 4);
            byte[] rest = new byte[Math.max(6, hlen)];
            in.readFully(rest, Math.max(6, hlen));
            int format = be16(rest, 0);
            int ntrks = be16(rest, 2);
            int division = be16(rest, 4);
            stats.format = format;
            stats.trackCount = ntrks;

            boolean smpte = (division & 0x8000) != 0;
            stats.smpte = smpte;
            if (smpte) {
                int fps = 256 - ((division >> 8) & 0xFF);        // e.g. 0xE8 == -24 fps
                int ticksPerFrame = division & 0xFF;
                tempo.smpte = true;
                tempo.smpteTicksPerSecond = Math.max(1, fps * ticksPerFrame);
                stats.ticksPerQuarter = 0;
            } else {
                stats.ticksPerQuarter = division & 0x7FFF;
                tempo.ticksPerQuarter = Math.max(1, stats.ticksPerQuarter);
            }
            if (hlen > 6) in.skip(hlen - 6);

            for (int t = 0; t < ntrks && t < 100_000; t++) {
                String id = in.readChunkId();
                long len = in.readU32();
                if (!"MTrk".equals(id)) { in.skip(len); continue; }   // skip unknown chunks instead of failing
                long trackEnd = in.position() + len;

                long tick = 0;
                int status = 0;
                byte[] data = new byte[16];
                long lastTickInTrack = 0;
                int sinceProgress = 0;

                while (in.position() < trackEnd) {
                    long delta = in.readVLQ();
                    tick += delta;
                    lastTickInTrack = tick;

                    int b = in.readByte();
                    if (b < 0) break;

                    if ((b & 0x80) != 0) status = b;      // new status byte
                    else in.unread();                     // running status: it was a data byte

                    if (status == 0) { in.skip(1); continue; }

                    int hi = status & 0xF0;
                    if (hi == 0x80) {                     // note off
                        int pitch = in.readByte() & 0x7F;
                        in.readByte();                    // release velocity (unused)
                        if (firstPass) stats.noteOffCount++;
                        if (writer != null) writer.noteOff(status & 0x0F, pitch, tick);
                    } else if (hi == 0x90) {              // note on (vel 0 => off)
                        int pitch = in.readByte() & 0x7F;
                        int vel = in.readByte() & 0x7F;
                        int ch = status & 0x0F;
                        if (vel == 0) {
                            if (firstPass) stats.noteOffCount++;
                            if (writer != null) writer.noteOff(ch, pitch, tick);
                        } else {
                            // Count only in pass 1: the file is read TWICE and stats must describe the
                            // file, not the file times two. (The harness caught this as well.)
                            if (firstPass) {
                                stats.noteOnCount++;
                                stats.pitchHistogram[pitch]++;
                                stats.channelHistogram[ch]++;
                                if (tick > stats.lastNoteTick) stats.lastNoteTick = tick;
                            } else {
                                writer.noteOn(ch, pitch, vel, tick);
                            }
                            if (listener != null && !firstPass && (++sinceProgress & 0x1FFF) == 0) {
                                long len2 = src.length();
                                int pct = len2 > 0
                                        ? 12 + (int) (82L * Math.min(len2, in.position()) / len2)
                                        : 50;
                                listener.onProgress(pct, stats.noteOnCount, "Writing note events…");
                                if (listener.isCancelled()) throw new IOException("Import cancelled");
                            }
                        }
                    } else if (hi == 0xA0 || hi == 0xB0 || hi == 0xE0) {
                        in.skip(2);                       // aftertouch / controller / pitch bend
                    } else if (hi == 0xC0 || hi == 0xD0) {
                        in.skip(1);                       // program change / channel pressure
                    } else if (status == 0xFF) {           // meta
                        int type = in.readByte() & 0xFF;
                        long mlen = in.readVLQ();
                        if (type == 0x51 && mlen == 3) {
                            in.readFully(data, 3);
                            int us = ((data[0] & 0xFF) << 16) | ((data[1] & 0xFF) << 8) | (data[2] & 0xFF);
                            if (firstPass) tempo.add(tick, us);
                        } else if (type == 0x2F) {         // end of track
                            break;
                        } else {
                            in.skip(mlen);
                        }
                    } else if (status == 0xF0 || status == 0xF7) {
                        in.skip(in.readVLQ());             // sysex: consume and forget
                    } else {
                        in.skip(1);
                    }
                }

                // Notes left open at the end of this track: clamp them to the track's last tick.
                if (writer != null) writer.flushTrack(lastTickInTrack);
                in.seek(trackEnd);
            }
        } finally {
            in.close();
        }
    }

    // ==================================================================
    // Little-endian / chunk helpers
    // ==================================================================

    private static int be16(byte[] b, int o) { return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF); }
    private static int be32(byte[] b, int o) {
        return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF);
    }

    // ==================================================================
    // Seekable sliding-window byte reader (1 MB window, no full-file buffer)
    // ==================================================================

    /**
     * Forward-only stream with a 1 MB sliding window: {@code seek()} forward is O(1)-ish (it just
     * advances the cursor or skips), and refills compact the window in place. This is what lets a
     * 300 MB file be parsed twice without ever holding 300 MB of bytes.
     */
    static final class SeekableInput implements Closeable {
        private final InputStream in;
        private final long total;
        private byte[] buf = new byte[1 << 20];
        private int bufLen = 0;
        private int cursor = 0;
        private long base = 0;
        private boolean eof = false;

        SeekableInput(InputStream in, long total) { this.in = in; this.total = total; }

        long position() { return base + cursor; }

        void seek(long pos) throws IOException {
            if (pos < position()) throw new IOException("forward-only reader (want " + pos + ", at " + position() + ")");
            skip(pos - position());
        }

        int readByte() throws IOException {
            if (cursor >= bufLen && !fill()) return -1;
            return buf[cursor++] & 0xFF;
        }

        void unread() { if (cursor > 0) cursor--; else throw new IllegalStateException("unread at window start"); }

        void readFully(byte[] dst, int n) throws IOException {
            if (read(dst, n) < n) throw new IOException("Truncated MIDI file");
        }

        int read(byte[] dst, int n) throws IOException {
            int done = 0;
            while (done < n) {
                if (cursor >= bufLen && !fill()) break;
                int take = Math.min(n - done, bufLen - cursor);
                System.arraycopy(buf, cursor, dst, done, take);
                cursor += take;
                done += take;
            }
            return done;
        }

        void skip(long n) throws IOException {
            while (n > 0) {
                if (cursor >= bufLen && !fill()) return;
                int take = (int) Math.min(n, bufLen - cursor);
                cursor += take;
                n -= take;
            }
        }

        /** 4-byte chunk id, e.g. "MTrk". */
        String readChunkId() throws IOException {
            byte[] b = new byte[4];
            readFully(b, 4);
            return new String(b, java.nio.charset.StandardCharsets.US_ASCII);
        }

        /** Big-endian unsigned 32-bit chunk length. */
        long readU32() throws IOException {
            int a = readByte() & 0xFF, b = readByte() & 0xFF, c = readByte() & 0xFF, d = readByte() & 0xFF;
            return ((long) a << 24) | ((long) b << 16) | ((long) c << 8) | (long) d;
        }

        /** Variable-length quantity: 7 bits per byte, MSB set = continue. Max 4 bytes per spec. */
        long readVLQ() throws IOException {
            long v = 0;
            for (int i = 0; i < 4; i++) {
                int b = readByte();
                if (b < 0) return v;
                v = (v << 7) | (b & 0x7F);
                if ((b & 0x80) == 0) break;
            }
            return v;
        }

        private boolean fill() throws IOException {
            if (eof) return false;
            if (cursor > 0) {
                int rem = bufLen - cursor;
                if (rem > 0) System.arraycopy(buf, cursor, buf, 0, rem);
                bufLen = rem;
                base += cursor;
                cursor = 0;
            }
            if (bufLen == buf.length) buf = java.util.Arrays.copyOf(buf, Math.min(buf.length * 2, 8 << 20));
            int got = in.read(buf, bufLen, buf.length - bufLen);
            if (got <= 0) { eof = true; return bufLen > 0; }
            bufLen += got;
            return true;
        }

        @Override public void close() {
            try { in.close(); } catch (IOException ignored) { }
        }
    }
}
