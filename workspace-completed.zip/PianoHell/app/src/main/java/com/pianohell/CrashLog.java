package com.pianohell;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * CrashLog — a last-resort crash handler.
 *
 * <p>This exists because of a specific failure: the app died so early that the only thing Android
 * showed was "Piano Hell keeps stopping" and there was no way to tell WHY without a USB cable and
 * logcat. A game like this starts a render thread, opens a low-latency audio stream, parses
 * multi-megabyte files and allocates tens of megabytes of primitives — all of which can fail on a
 * particular device, and all of which are much easier to diagnose from the device itself.
 *
 * <p>It writes the uncaught exception to {@code filesDir/crash.txt} and then chains to the platform
 * handler, so crash reporting/Play Console behaviour is unchanged. {@link MainActivity} shows the
 * last crash under the menu, and the user can share it with one tap.
 */
public final class CrashLog {

    private static final String FILE = "crash.txt";
    private static final int MAX_CHARS = 16000;

    private CrashLog() { }

    /** Install as the default handler. Call once, first thing in Application.onCreate. */
    public static void install(final Context appContext) {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try { write(appContext, thread, throwable); } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(thread, throwable);
            else System.exit(1);
        });
    }

    private static void write(Context ctx, Thread thread, Throwable t) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        pw.println("Piano Hell crash report");
        pw.println("time      : " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()));
        pw.println("android   : " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
        pw.println("device    : " + Build.MANUFACTURER + " " + Build.MODEL + " / " + Build.HARDWARE);
        pw.println("abis      : " + java.util.Arrays.toString(Build.SUPPORTED_ABIS));
        pw.println("thread    : " + (thread != null ? thread.getName() : "?"));
        pw.println();
        t.printStackTrace(pw);
        pw.flush();
        String text = sw.toString();
        if (text.length() > MAX_CHARS) text = text.substring(0, MAX_CHARS) + "\n…(truncated)";

        try (Writer w = new FileWriter(new File(ctx.getFilesDir(), FILE), false)) {
            w.write(text);
        } catch (Throwable ignored) { }
    }

    /** The last crash report, or null. Called from the menu, so it must never throw. */
    public static String last(Context ctx) {
        File f = new File(ctx.getFilesDir(), FILE);
        if (!f.exists()) return null;
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = r.readLine()) != null && sb.length() < MAX_CHARS) {
                sb.append(line).append('\n');
            }
        } catch (Throwable t) {
            return null;
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    /**
     * Short but conclusive summary for the menu: the top-level exception, the DEEPEST cause, and the
     * first frame inside this app. Those three lines are enough to name the failed call site — which
     * is the whole point, because the wrapper Android reports ("Unable to start activity
     * ComponentInfo{...}") never says where.
     */
    public static String summary(Context ctx) {
        String full = last(ctx);
        if (full == null) return null;
        String[] lines = full.split("\n");

        String top = null;
        int deepestCause = -1;
        for (int i = 0; i < lines.length; i++) {
            String t = lines[i].trim();
            if (top == null && isThrowableLine(t)) top = t;
            if (t.startsWith("Caused by:")) deepestCause = i;
        }
        StringBuilder sb = new StringBuilder();
        if (deepestCause >= 0) {
            sb.append(clip(lines[deepestCause].trim()));
            for (int i = deepestCause + 1; i < lines.length; i++) {
                String t = lines[i].trim();
                if (t.startsWith("at com.pianohell.")) { sb.append('\n').append(clip(t)); break; }
            }
        } else if (top != null) {
            sb.append(clip(top));
            for (String line : lines) {
                String t = line.trim();
                if (t.startsWith("at com.pianohell.")) { sb.append('\n').append(clip(t)); break; }
            }
        } else {
            sb.append("unrecognised report — use SHARE");
        }
        return sb.toString();
    }

    private static boolean isThrowableLine(String t) {
        return t.contains("Exception") || t.contains("Error") || t.startsWith("Caused by:");
    }

    private static String clip(String t) {
        return t.length() > 140 ? t.substring(0, 140) + "…" : t;
    }

    public static void clear(Context ctx) {
        //noinspection ResultOfMethodCallIgnored
        new File(ctx.getFilesDir(), FILE).delete();
        SharedPreferences p = ctx.getSharedPreferences("pianohell", Context.MODE_PRIVATE);
        p.edit().remove("cleanRuns").apply();
    }

    /** Call on every successful launch; two clean runs in a row means the last crash is stale. */
    public static void noteCleanRun(Context ctx) {
        SharedPreferences p = ctx.getSharedPreferences("pianohell", Context.MODE_PRIVATE);
        int clean = p.getInt("cleanRuns", 0) + 1;
        p.edit().putInt("cleanRuns", clean).apply();
        if (clean >= 2) new File(ctx.getFilesDir(), FILE).delete();
    }
}
