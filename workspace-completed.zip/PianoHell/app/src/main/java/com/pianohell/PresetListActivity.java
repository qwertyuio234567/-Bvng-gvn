package com.pianohell;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * PresetListActivity — the preset browser and the MIDI import panel, side by side in landscape.
 *
 * <p>The two are deliberately on ONE screen with two halves (spec asks for the preset list to be
 * separate from "import your own MIDI"; two columns in landscape satisfies that while keeping the
 * flow to one tap) and both share the same loader, so a bundled preset and a user import go through
 * identical code.
 *
 * <p>SAF: ACTION_OPEN_DOCUMENT with a MIME filter for audio/midi, and no storage permission is
 * ever requested — the document picker grants per-file access to exactly the file the player chose.
 * That is why the manifest has no READ_EXTERNAL_STORAGE.
 */
public final class PresetListActivity extends Activity {

    public static final int SCREEN_PRESETS = 0, SCREEN_IMPORT = 1;
    private static final int REQ_PICK_MIDI = 4711;

    private GameConfig cfg;
    private TextView status;
    private ProgressBar progress;
    private ChartLoader.Canceller canceller;
    private CheckBox ignoreDrums;
    private SeekBar collapse;
    private TextView collapseLabel;
    private Spinner modeSpinner, scaleSpinner, rootSpinner, diffSpinner;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cfg = GameConfig.load(this);
        setContentView(R.layout.activity_preset_list);
        OrientationGuard.install(this, findViewById(R.id.presetRoot));

        status = findViewById(R.id.importStatus);
        progress = findViewById(R.id.importProgress);

        RecyclerView list = findViewById(R.id.presetList);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(new PresetAdapter(this::launchPreset));

        buildImportPanel();
        showScreen(getIntent().getIntExtra("screen", SCREEN_PRESETS));
        ChartIO.pruneCache(this, 21);
    }

    /**
     * The preset catalogue and the MIDI importer are SEPARATE screens that happen to share this
     * activity (and therefore share the loader, the config and the recycle behaviour). A phone held
     * in landscape gets one full-width pane at a time; on a tablet you can flip BOTH_VISIBLE to lay
     * them side by side, which is why the layout is a weighted row.
     */
    private void showScreen(int screen) {
        boolean importMode = screen == SCREEN_IMPORT;
        findViewById(R.id.presetPane).setVisibility(importMode ? android.view.View.GONE : android.view.View.VISIBLE);
        findViewById(R.id.importPane).setVisibility(importMode ? android.view.View.VISIBLE : android.view.View.GONE);
        if (importMode) findViewById(R.id.modeSpinner).requestFocus();
    }

    // ------------------------------------------------------------------
    // Presets
    // ------------------------------------------------------------------

    private void launchPreset(Preset p) {
        startActivity(new Intent(this, GameActivity.class)
                .putExtra(GameActivity.EXTRA_PRESET_ID, p.id));
    }

    // ------------------------------------------------------------------
    // Import panel
    // ------------------------------------------------------------------

    private void buildImportPanel() {
        modeSpinner = findViewById(R.id.modeSpinner);
        scaleSpinner = findViewById(R.id.scaleSpinner);
        rootSpinner = findViewById(R.id.rootSpinner);
        diffSpinner = findViewById(R.id.difficultySpinner);
        collapse = findViewById(R.id.collapseSeek);
        collapseLabel = findViewById(R.id.collapseLabel);
        ignoreDrums = findViewById(R.id.ignoreDrums);

        modeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                MidiMapper.modeNames()));
        modeSpinner.setSelection(cfg.mappingMode);
        modeSpinner.setOnItemSelectedListener(new SimpleSelect((pos) -> {
            cfg.mappingMode = pos;
            boolean scaleish = pos == GameConfig.MAP_SCALE;
            scaleSpinner.setEnabled(scaleish);           // only mode B uses a scale/key
            rootSpinner.setEnabled(scaleish);
            cfg.save(this);
        }));

        scaleSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                MidiMapper.SCALE_NAMES));
        scaleSpinner.setSelection(cfg.scaleIndex);
        scaleSpinner.setOnItemSelectedListener(new SimpleSelect(pos -> { cfg.scaleIndex = pos; cfg.save(this); }));

        rootSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                getResources().getStringArray(R.array.key_names)));
        rootSpinner.setSelection(cfg.rootNote);
        rootSpinner.setOnItemSelectedListener(new SimpleSelect(pos -> { cfg.rootNote = pos; cfg.save(this); }));

        diffSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                getResources().getStringArray(R.array.difficulty_names)));
        diffSpinner.setSelection(cfg.difficulty);
        diffSpinner.setOnItemSelectedListener(new SimpleSelect(pos -> {
            cfg.applyDifficulty(pos);
            cfg.save(this);
        }));

        collapse.setMax(200);
        collapse.setProgress(cfg.collapseMs);
        updateCollapseLabel();
        collapse.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int value, boolean fromUser) {
                cfg.collapseMs = value;
                updateCollapseLabel();
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { }
            @Override public void onStopTrackingTouch(SeekBar sb) { cfg.save(PresetListActivity.this); }
        });

        ignoreDrums.setChecked(cfg.ignoreDrums);
        ignoreDrums.setOnCheckedChangeListener((b, on) -> { cfg.ignoreDrums = on; cfg.save(this); });

        scaleSpinner.setEnabled(cfg.mappingMode == GameConfig.MAP_SCALE);
        rootSpinner.setEnabled(cfg.mappingMode == GameConfig.MAP_SCALE);

        findViewById(R.id.btnPickFile).setOnClickListener(v -> pickMidi());
    }

    private void updateCollapseLabel() {
        collapseLabel.setText("Collapse same-lane notes closer than " + cfg.collapseMs
                + " ms  (0 = keep everything, black-MIDI chaos)");
    }

    /**
     * Launch the Storage Access Framework picker. {@code CATEGORY_OPENABLE} + MIME "audio/midi"
     * with a fallback to any file, because many file providers report .mid as
     * application/octet-stream — filtering strictly there would hide the very files we want.
     */
    private void pickMidi() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] { "audio/midi", "audio/x-midi", "application/octet-stream" });
        startActivityForResult(i, REQ_PICK_MIDI);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK_MIDI || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {                                               // persist read access across restarts
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException ignored) { }

        cfg.save(this);
        setBusy(true, "Reading " + uri.getLastPathSegment());
        canceller = new ChartLoader.Canceller();
        ChartLoader.loadMidiUri(uri, cfg, new ChartLoader.Callback() {
            @Override public void onProgress(int percent, long notes, String stage) {
                progress.setProgress(percent);
                status.setText(stage + (notes > 0 ? "  (" + notes + " notes)" : ""));
            }
            @Override public void onLoaded(ChartData chart, MidiMapper mapper, String describe) {
                setBusy(false, describe);
                Intent g = new Intent(PresetListActivity.this, GameActivity.class);
                g.putExtra(GameActivity.EXTRA_CHART_HANDLE, LoadedChartStash.put(chart, mapper));
                startActivity(g);
            }
            @Override public void onError(String message) {
                setBusy(false, message);
            }
        });
    }

    private void setBusy(boolean busy, String message) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (busy) progress.setProgress(0);
        status.setText(message);
        findViewById(R.id.btnPickFile).setEnabled(!busy);
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (canceller != null) canceller.cancelled = true;   // stop a mid-flight parse when leaving
    }

    /** Tiny helper interface so each spinner gets a one-line listener instead of an anonymous class. */
    private interface OnPos { void at(int position); }

    private final class SimpleSelect implements AdapterView.OnItemSelectedListener {
        private final OnPos onPos;
        SimpleSelect(OnPos onPos) { this.onPos = onPos; }
        @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { onPos.at(pos); }
        @Override public void onNothingSelected(AdapterView<?> p) { }
    }
}
