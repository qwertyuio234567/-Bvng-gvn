package com.pianohell;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.view.View;

/**
 * OrientationGuard — the runtime half of the landscape lock.
 *
 * <p>The manifest flag ({@code android:screenOrientation="landscape"}) is the primary mechanism, but
 * it is not sufficient in the real world: multi-window / freeform / split-screen, some foldables,
 * and several OEMs' "rotation lock" settings can hand a landscape-locked activity a portrait window
 * anyway. So every screen also watches its own layout: if the window is taller than it is wide, a
 * full-screen "ROTATE YOUR DEVICE" overlay covers the UI (and swallows touches, so nothing is
 * played blind in the wrong aspect ratio).
 */
public final class OrientationGuard {

    private OrientationGuard() { }

    /** Re-assert the requested orientation and install the portrait overlay check. */
    public static void install(Activity activity, View root) {
        // Wrapped because setRequestedOrientation() is not infallible: on some OEM builds (and in
        // freeform/desktop-window modes) it can throw, and an exception during onCreate would take
        // the whole app down over what is only a rotation preference. The manifest flag is the
        // primary mechanism; this is the belt-and-braces re-assert.
        try {
            activity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        } catch (Throwable ignored) {
            android.util.Log.w("PianoHell", "could not re-assert landscape orientation", ignored);
        }

        final View overlay = root.findViewById(R.id.rotateOverlay);
        if (overlay == null) return;

        View.OnLayoutChangeListener listener = (v, l, t, r, b, ol, ot, or, ob) -> apply(root, overlay);
        root.addOnLayoutChangeListener(listener);
        apply(root, overlay);
    }

    /** Portrait == the window is taller than it is wide. Cheap; called on layout changes only. */
    public static void apply(View root, View overlay) {
        int w = root.getWidth(), h = root.getHeight();
        boolean portrait = w > 0 && h > 0 && h > w;
        if (portrait != (overlay.getVisibility() == View.VISIBLE)) {
            overlay.setVisibility(portrait ? View.VISIBLE : View.GONE);
        }
    }

    public static boolean isPortrait(View root) {
        return root.getHeight() > root.getWidth();
    }
}
