package com.pianohell;

import java.io.Closeable;

/**
 * ChartData — THE single most performance-critical class in the project.
 *
 * <h3>Why flat primitive arrays instead of a List&lt;Note&gt;?</h3>
 * A black-MIDI chart can contain up to {@link #MAX_NOTES} = 5,000,000 notes. As Java objects
 * (say 48 bytes of header + 4 fields) that is ~350 MB of heap, millions of allocations, and — worse
 * for a game — a pointer-chase per note per frame, which destroys cache locality and invites
 * a stop-the-world GC pause in the middle of a 20-note-per-frame run.
 *
 * Instead every note is a column in a struct-of-arrays (SoA) layout:
 *
 * <pre>
 *   startMs[i], durationMs[i], lane[i], colorId[i], kind[i], flags[i], jud[i]
 * </pre>
 *
 * <ul>
 *   <li>startMs is ASCENDING, so the renderer binary-searches the visible time window instead of
 *       scanning the whole chart. Frame cost is O(log n) + O(visible notes), independent of chart size.</li>
 *   <li>A 12-byte-per-note footprint keeps 5M notes at ~78 MB — loadable, and streamable with
 *       sequential memory access (the CPU prefetcher loves it).</li>
 *   <li>No per-note objects == no per-note allocation == no GC pauses during play.</li>
 * </ul>
 *
 * <h3>Threading contract</h3>
 * The parser thread WRITES (and calls {@link #finishLoad()}) once. After that the object is
 * frozen and only read by the render/update threads; the only mutation is the per-note judgment
 * byte array {@link #jud}, which is written by the game thread and reset between runs.
 */
public final class ChartData implements Closeable {

    /** Hard ceiling the pool/parsers are sized against (matches the spec's 5M requirement). */
    public static final int MAX_NOTES = 5_000_000;

    /** kind[] values. */
    public static final byte KIND_TAP = 0;
    public static final byte KIND_HOLD = 1;

    // flags[] bits
    public static final byte FLAG_LONG_HOLD = 1;      // hold longer than the playable window (juke/harpsichord pedal spam)
    public static final byte FLAG_MERGED = 2;         // produced by the same-lane collapse step
    public static final byte FLAG_FROM_PARSER = 4;    // imported (vs generated preset)

    // jud[] values — per-run judgment state, reset on restart
    public static final byte JUD_NONE = 0;
    public static final byte JUD_HOLDING = 1;         // a finger is currently down on this hold
    public static final byte JUD_DONE = 2;            // scored (hit or already missed)
    public static final byte JUD_MISSED = 3;

    public static final int NO_INDEX = -1;

    // ---------------------------------------------------------------------
    // The flat arrays. Allocated in blocks so a 5M-note import never
    // requires a single 78 MB contiguous allocation up front.
    // ---------------------------------------------------------------------
    public long[] startMs = new long[0];      // ascending after finishLoad()
    public int[] durationMs = new int[0];     // 100 ms .. multi-second holds; 0 == plain tap
    public byte[] lane = new byte[0];         // 0..11
    public byte[] colorId = new byte[0];      // index into NoteColors palette
    public byte[] kind = new byte[0];         // KIND_TAP / KIND_HOLD
    public byte[] flags = new byte[0];        // FLAG_*
    public byte[] jud = new byte[0];          // per-run state (see JUD_*)

    /** Sort key used only by the parser; kept so re-lane-mapping never has to re-read the file. */
    public int[] midiPitch = new int[0];      // 0..127, or -1 for generated charts

    public int count = 0;                     // notes actually stored
    public int capacity = 0;

    // ---------------------------------------------------------------------
    // Chart metadata (cheap to keep, used by the list UI / HUD)
    // ---------------------------------------------------------------------
    public String title = "untitled";
    public String subtitle = "";
    public int bpm = 120;
    public long lengthMs = 0;                 // end of the last note (rename keeps the arrays unambiguous)
    public int difficultyRating = 1;          // 1..12 display rating
    public int themeIndex = 0;                // NoteColors theme used for the preview swatch
    public int mappingMode = 0;           // GameConfig.MAP_* that produced these lanes
    public int scaleIndex = 0;            // mode B settings, kept so a cached chart can rebuild its mapper
    public int rootNote = 0;
    public int noteOnCount = 0;               // raw MIDI note_on count before collapsing (the "hell factor")
    public boolean isPreset = false;

    /**
     * Scratch: last accepted note time per lane, used by the collapse pass.
     * NOTE the sentinel is NO_TIME, not Long.MIN_VALUE: "t - Long.MIN_VALUE" overflows to a negative
     * number for any small t, which made the comparison "closer than windowMs" true for EVERY note
     * and collapsed entire charts down to zero tiles. (Found by tools/harness — worth remembering:
     * sentinels in arithmetic comparisons must not overflow.)
     */
    private static final long NO_TIME = Long.MIN_VALUE / 4;
    private long[] laneTagMs = new long[12];
    private boolean frozen = false;

    public ChartData() {
        for (int i = 0; i < laneTagMs.length; i++) laneTagMs[i] = NO_TIME;
    }

    // =====================================================================
    // Growth / append
    // =====================================================================

    /** Grow to at least n notes. Growth is geometric so N appends cost O(N) total, not O(N^2). */
    public void ensureCapacity(int n) {
        if (n <= capacity) return;
        int target = Math.max(capacity, 1 << 14);          // start at 16k notes
        while (target < n) target += (target >> 1);        // 1.5x steps: less wasted peak memory than 2x
        target = Math.min(target, MAX_NOTES);
        startMs = grow(startMs, target);
        durationMs = grow(durationMs, target);
        lane = grow(lane, target);
        colorId = grow(colorId, target);
        kind = grow(kind, target);
        flags = grow(flags, target);
        jud = grow(jud, target);
        midiPitch = grow(midiPitch, target);
        capacity = target;
    }

    private static long[] grow(long[] a, int n) { long[] b = new long[n]; System.arraycopy(a, 0, b, 0, a.length); return b; }
    private static int[] grow(int[] a, int n) { int[] b = new int[n]; System.arraycopy(a, 0, b, 0, a.length); return b; }
    private static byte[] grow(byte[] a, int n) { byte[] b = new byte[n]; System.arraycopy(a, 0, b, 0, a.length); return b; }

    /**
     * Append one note. Cheap, allocation-free, and safe to call from the parser thread in a tight loop.
     *
     * @param tMs     start time in milliseconds from chart start
     * @param durMs   note length; &lt; 0 is clamped to 0 (tap)
     */
    public void append(int laneIdx, long tMs, int durMs, int colorIdx, int pitch) {
        if (count >= MAX_NOTES) return;                    // silently drop past the ceiling rather than OOM
        if (count >= capacity) ensureCapacity(count + 1);
        int i = count++;
        startMs[i] = tMs;
        durationMs[i] = durMs < 0 ? 0 : durMs;
        lane[i] = (byte) laneIdx;
        colorId[i] = (byte) colorIdx;
        if (durationMs[i] >= GameConfig.MIN_HOLD_MS) kind[i] = KIND_HOLD;
        else { kind[i] = KIND_TAP; durationMs[i] = 0; }      // < 0.1 s is a tap tile, not a hold
        flags[i] = 0;
        midiPitch[i] = pitch;
    }

    public void resetCollapseTags() { for (int i = 0; i < 12; i++) laneTagMs[i] = NO_TIME; }

    /** A note-off arrived: remember how long the tile is. Called by the parser, pre-sort. */
    public void patchDuration(int idx, int durMs) {
        if (idx < 0 || idx >= count) return;
        durationMs[idx] = durMs < 0 ? 0 : durMs;
        kind[idx] = durationMs[idx] >= GameConfig.MIN_HOLD_MS ? KIND_HOLD : KIND_TAP;
        if (kind[idx] == KIND_TAP) durationMs[idx] = 0;
    }

    /**
     * Post-sort collapse pass: walks the now-ascending chart once and removes notes that sit in the
     * same lane closer than {@code windowMs} apart. This is the "avoid unplayable overlaps" step
     * from the spec and it runs AFTER the sort so it also catches overlaps that came from different
     * MIDI tracks. Compaction is done in place (read index + write index over the same arrays),
     * so it needs no extra memory and is O(n) with a single linear sweep.
     *
     * @param stretchToHold true = the surviving tile is stretched to cover the dropped note, which
     *                      keeps the visual honest about the audio that is still going to play.
     * @return number of notes removed
     */
    public int collapsePass(int windowMs, boolean stretchToHold) {
        if (count <= 1) return 0;
        resetCollapseTags();
        int w = 0;
        int removed = 0;
        for (int r = 0; r < count; r++) {
            int ln = lane[r];
            long t = startMs[r];
            if (t - laneTagMs[ln] < windowMs) {
                removed++;
                if (stretchToHold && w > 0) {
                    int j = w - 1;                       // the last kept note of this lane is at w-1 most often
                    while (j >= 0 && lane[j] != ln) j--;
                    if (j >= 0) {
                        int want = (int) (t + durationMs[r] - startMs[j]);
                        if (want > durationMs[j]) {
                            durationMs[j] = want;
                            kind[j] = want >= GameConfig.MIN_HOLD_MS ? KIND_HOLD : KIND_TAP;
                            flags[j] |= FLAG_MERGED;
                        }
                    }
                }
                continue;                                // drop this note
            }
            laneTagMs[ln] = t;
            if (w != r) copyElement(r, w);
            w++;
        }
        count = w;
        return removed;
    }

    /** Copy one note record from src index to dst index (in-place compaction primitive). */
    private void copyElement(int src, int dst) {
        startMs[dst] = startMs[src];
        durationMs[dst] = durationMs[src];
        lane[dst] = lane[src];
        colorId[dst] = colorId[src];
        kind[dst] = kind[src];
        flags[dst] = flags[src];
        midiPitch[dst] = midiPitch[src];
    }

    /** Recompute {@link #lengthMs} (call after any structural edit). */
    public void recomputeLength() {
        long end = 0;
        for (int i = 0; i < count; i++) end = Math.max(end, startMs[i] + durationMs[i]);
        lengthMs = end;
    }

    // =====================================================================
    // Sort + freeze
    // =====================================================================

    /**
     * Make startMs ascending and mark the chart read-only for the engine.
     *
     * <p>Black-MIDI files are usually *almost* sorted (the parser merges tracks in time order),
     * so we first do a cheap O(n) monotonicity check and skip sorting entirely when possible.
     * When a sort is needed we sort an int[] PERMUTATION with an LSD radix sort (4 passes of
     * 8 bits) rather than sorting the parallel arrays directly: the permutation is 4 bytes/note
     * instead of 16, and radix sort has no branch misprediction on random keys — roughly 10x
     * faster than a comparison sort at 5M elements. The permutation is then applied in place by
     * cycle-following, which needs no second copy of the note arrays.
     */
    public void finishLoad() {
        if (count > 1) {
            boolean sorted = true;
            for (int i = 1; i < count; i++) if (startMs[i] < startMs[i - 1]) { sorted = false; break; }
            if (!sorted) {
                int[] perm = sortIndicesByStart();
                applyPermutation(perm);
                perm = null;                                   // let the 20 MB scratch die before play starts
            }
        }
        // Compute duration + a difficulty estimate from density (used by the preset row / HUD).
        long end = 0;
        for (int i = 0; i < count; i++) end = Math.max(end, startMs[i] + durationMs[i]);
        lengthMs = end;
        jud = new byte[max(jud.length, count)];                // ensure the judgment array covers the used range
        java.util.Arrays.fill(jud, 0, capacity, JUD_NONE);
        resetCollapseTags();
        frozen = true;
        trim();
    }

    private static int max(int a, int b) { return a > b ? a : b; }

    /** Radix-sort an index permutation by startMs (stable, O(4n), no comparisons). */
    private int[] sortIndicesByStart() {
        final int n = count;
        int[] cur = new int[n];
        int[] nxt = new int[n];
        for (int i = 0; i < n; i++) cur[i] = i;

        final int[] count256 = new int[257];
        for (int shift = 0; shift < 32; shift += 8) {
            java.util.Arrays.fill(count256, 0);
            for (int i = 0; i < n; i++) {
                int key = (int) ((startMs[cur[i]] >>> shift) & 0xFF);
                count256[key + 1]++;
            }
            for (int i = 0; i < 256; i++) count256[i + 1] += count256[i];
            for (int i = 0; i < n; i++) {
                int idx = cur[i];
                int key = (int) ((startMs[idx] >>> shift) & 0xFF);
                nxt[count256[key]++] = idx;
            }
            int[] t = cur; cur = nxt; nxt = t;
        }
        return cur;
    }

    /** Reorder all parallel arrays according to perm[] using cycle-following (O(n), no copy). */
    private void applyPermutation(int[] perm) {
        for (int i = 0; i < count; i++) {
            if (perm[i] == i) continue;
            // Follow the cycle starting at i, moving the element that belongs here into place.
            long s = startMs[i]; int d = durationMs[i], p = midiPitch[i];
            byte l = lane[i], c = colorId[i], k = kind[i], f = flags[i];
            int j = i;
            while (perm[j] != i) {
                int src = perm[j];
                startMs[j] = startMs[src]; durationMs[j] = durationMs[src]; midiPitch[j] = midiPitch[src];
                lane[j] = lane[src]; colorId[j] = colorId[src]; kind[j] = kind[src]; flags[j] = flags[src];
                perm[j] = j;                       // mark as done
                j = src;
            }
            startMs[j] = s; durationMs[j] = d; midiPitch[j] = p;
            lane[j] = l; colorId[j] = c; kind[j] = k; flags[j] = f;
            perm[j] = j;
        }
    }

    /** Optional: shrink arrays to the used size to hand memory back to the heap. */
    public void trim() {
        if (count == 0) return;
        int n = Math.max(count, 1);
        if (startMs.length != n) {
            startMs = java.util.Arrays.copyOf(startMs, n);
            durationMs = java.util.Arrays.copyOf(durationMs, n);
            lane = java.util.Arrays.copyOf(lane, n);
            colorId = java.util.Arrays.copyOf(colorId, n);
            kind = java.util.Arrays.copyOf(kind, n);
            flags = java.util.Arrays.copyOf(flags, n);
            jud = java.util.Arrays.copyOf(jud, n);
            midiPitch = java.util.Arrays.copyOf(midiPitch, n);
            capacity = n;
        }
    }

    // =====================================================================
    // Binary search helpers — the hot path called every frame
    // =====================================================================

    /** First index with startMs[i] >= t. Always in [0, count]. */
    public int lowerBound(long t) {
        int lo = 0, hi = count;
        long[] a = startMs;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (a[mid] < t) lo = mid + 1; else hi = mid;
        }
        return lo;
    }

    /** First index with startMs[i] > t. */
    public int upperBound(long t) {
        int lo = 0, hi = count;
        long[] a = startMs;
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (a[mid] <= t) lo = mid + 1; else hi = mid;
        }
        return lo;
    }

    /**
     * Fast start index for the visible window that ALSO includes still-running hold notes whose
     * tail is on screen (their start time may be seconds in the past).
     *
     * <p>Naive approach: scan backwards until every lane's longest tail is covered. Instead we keep
     * {@link #maxTailMs} — the longest note duration in the chart — and jump straight to
     * lowerBound(windowStart - maxTailMs). One extra binary search, zero scanning.
     */
    public int renderWindowStart(long windowStartMs, int maxTailMs) {
        return lowerBound(Math.max(0, windowStartMs - maxTailMs));
    }

    /**
     * Worst case under the hit line. Returns the smallest index whose *tail* could still be alive:
     * used by the judgment engine to expire holds it can no longer score.
     */
    public int judgeWindowStart(long nowMs, int maxTailMs) {
        return lowerBound(Math.max(0, nowMs - maxTailMs));
    }

    /** Longest note duration in the chart (cached during finishLoad). */
    public int maxDurationMs() {
        if (maxDurationMs < 0) {
            int m = 0;
            for (int i = 0; i < count; i++) if (durationMs[i] > m) m = durationMs[i];
            maxDurationMs = m;
        }
        return maxDurationMs;
    }
    private int maxDurationMs = -1;

    // =====================================================================
    // Judgment-state helpers (game thread only)
    // =====================================================================

    /** Reset every note to unjudged. O(n) but only runs on restart, never per frame. */
    public void resetJudgment() { java.util.Arrays.fill(jud, 0, count, JUD_NONE); }

    /**
     * Next unjudged note in a lane at or after t. Linear-ish probe over a tiny range because
     * consecutive chart entries for one lane are never more than a few hundred apart at black-MIDI
     * density; the caller passes a starting hint from the keyboard cursor.
     */
    public int nextUnjudgedInLane(int laneIdx, int from, int limit) {
        for (int i = from; i < count && i <= limit; i++) {
            if (lane[i] == laneIdx && jud[i] == JUD_NONE) return i;
        }
        return NO_INDEX;
    }

    /** Approximate bytes resident (for the HUD / diagnostics). */
    public long memoryBytes() {
        return (long) capacity * (8L + 4L + 4L + 1 + 1 + 1 + 1 + 1);
    }

    public boolean isFrozen() { return frozen; }

    @Override public void close() {
        startMs = new long[0]; durationMs = new int[0]; lane = new byte[0];
        colorId = new byte[0]; kind = new byte[0]; flags = new byte[0];
        jud = new byte[0]; midiPitch = new int[0];
        count = capacity = 0;
    }
}
