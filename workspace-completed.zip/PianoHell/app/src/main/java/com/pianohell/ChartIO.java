package com.pianohell;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

/**
 * ChartIO — the custom binary chart format ({@code .phc}) and the import cache.
 *
 * <p>Parsing a 200 MB black-MIDI file takes seconds even with the streaming parser. Caching the
 * RESULT means the second launch of that chart is instant, and the cache is a flat dump of the same
 * primitive arrays the renderer reads — so loading it is one {@code readFully} per array and zero
 * parsing, zero object construction.
 *
 * <pre>
 *   magic   : 'P' 'H' 'C' '1'
 *   header  : version(int) flags(int) noteCount(int) lengthMs(long) bpm(int) difficulty(int)
 *             theme(int) title(UTF) subtitle(UTF) noteOnCount(int)
 *   notes   : startMs(long[n]) durationMs(int[n]) lane(byte[n]) colorId(byte[n])
 *             kind(byte[n]) flags(byte[n]) midiPitch(int[n])
 *   (the whole stream is Deflate-compressed: a 2M-note chart lands around 6–10 MB on disk)
 * </pre>
 */
public final class ChartIO {

    private static final char[] MAGIC = { 'P', 'H', 'C', '1' };
    /**
     * Bumped whenever the payload layout changes. v2 added scaleIndex/rootNote (the mapping settings
     * a cached chart must remember so its lanes and its audio agree).
     *
     * <p>This matters: a cache written by an older build is read back with a different field order,
     * which produces garbage strings and, at best, an exception. The version check turns that into a
     * clean "unsupported version" that {@link ChartLoader} reacts to by discarding the file and
     * parsing the original again — a stale cache must never be able to break the game.
     */
    public static final int VERSION = 2;

    /** Cache directory: {@code filesDir/charts}. */
    public static File cacheDir(android.content.Context ctx) {
        File d = new File(ctx.getFilesDir(), "charts");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File cacheFile(android.content.Context ctx, String key) {
        // Cheap, collision-safe-enough key: hash + a sanitised tail so files are eyeballable.
        String safe = key.replaceAll("[^A-Za-z0-9._-]", "_");
        if (safe.length() > 40) safe = safe.substring(safe.length() - 40);
        return new File(cacheDir(ctx), Integer.toHexString(key.hashCode()) + "_" + safe + ".phc");
    }

    // ------------------------------------------------------------------
    // Write
    // ------------------------------------------------------------------

    public static void write(ChartData chart, File out) throws IOException {
        try (DataOutputStream o = new DataOutputStream(new BufferedOutputStream(
                new DeflaterOutputStream(new FileOutputStream(out), new java.util.zip.Deflater(1))))) {
            for (char c : MAGIC) o.writeByte(c);
            o.writeInt(VERSION);
            o.writeInt(0);                                  // flags, reserved
            o.writeInt(chart.count);
            o.writeLong(chart.lengthMs);
            o.writeInt(chart.bpm);
            o.writeInt(chart.difficultyRating);
            o.writeInt(chart.themeIndex);
            o.writeInt(chart.mappingMode);
            o.writeInt(chart.scaleIndex);
            o.writeInt(chart.rootNote);
            o.writeInt(chart.noteOnCount);
            o.writeUTF(safe(chart.title));
            o.writeUTF(safe(chart.subtitle));
            writeLongArray(o, chart.startMs, chart.count);
            writeIntArray(o, chart.durationMs, chart.count);
            o.write(chart.lane, 0, chart.count);
            o.write(chart.colorId, 0, chart.count);
            o.write(chart.kind, 0, chart.count);
            o.write(chart.flags, 0, chart.count);
            writeIntArray(o, chart.midiPitch, chart.count);
        }
    }

    private static String safe(String s) {
        if (s == null) return "";
        return s.length() > 512 ? s.substring(0, 512) : s;
    }

    private static void writeLongArray(DataOutputStream o, long[] a, int n) throws IOException {
        int i = 0;
        for (; i + 255 < n; i += 256) {                     // batched writes: fewer JNI/buffer calls
            for (int k = 0; k < 256; k++) o.writeLong(a[i + k]);
        }
        for (; i < n; i++) o.writeLong(a[i]);
    }

    private static void writeIntArray(DataOutputStream o, int[] a, int n) throws IOException {
        int i = 0;
        for (; i + 255 < n; i += 256) {
            for (int k = 0; k < 256; k++) o.writeInt(a[i + k]);
        }
        for (; i < n; i++) o.writeInt(a[i]);
    }

    // ------------------------------------------------------------------
    // Read
    // ------------------------------------------------------------------

    public static ChartData read(File in) throws IOException {
        try (DataInputStream i = new DataInputStream(new BufferedInputStream(
                new InflaterInputStream(new FileInputStream(in), new java.util.zip.Inflater(), 1 << 16)))) {
            for (char c : MAGIC) if (i.readByte() != (byte) c) throw new IOException("not a .phc chart");
            int version = i.readInt();
            if (version != VERSION) throw new IOException("unsupported chart version " + version);
            i.readInt();                                    // flags
            int n = i.readInt();
            if (n < 0 || n > ChartData.MAX_NOTES) throw new IOException("implausible note count " + n);

            ChartData chart = new ChartData();
            chart.lengthMs = i.readLong();
            chart.bpm = i.readInt();
            chart.difficultyRating = i.readInt();
            chart.themeIndex = i.readInt();
            chart.mappingMode = i.readInt();
            chart.scaleIndex = i.readInt();
            chart.rootNote = i.readInt();
            chart.noteOnCount = i.readInt();
            chart.title = i.readUTF();
            chart.subtitle = i.readUTF();
            chart.ensureCapacity(n);
            for (int k = 0; k < n; k++) chart.startMs[k] = i.readLong();
            for (int k = 0; k < n; k++) chart.durationMs[k] = i.readInt();
            i.readFully(chart.lane, 0, n);
            i.readFully(chart.colorId, 0, n);
            i.readFully(chart.kind, 0, n);
            i.readFully(chart.flags, 0, n);
            for (int k = 0; k < n; k++) chart.midiPitch[k] = i.readInt();
            chart.count = n;
            chart.finishLoad();                             // sets jud[], length, trims, freezes
            return chart;
        }
    }

    /** Delete cached charts older than {@code days} so the cache cannot grow without bound. */
    public static void pruneCache(android.content.Context ctx, int days) {
        File d = cacheDir(ctx);
        File[] files = d.listFiles();
        if (files == null) return;
        long cutoff = System.currentTimeMillis() - days * 86_400_000L;
        for (File f : files) if (f.lastModified() < cutoff) f.delete();
    }
}
