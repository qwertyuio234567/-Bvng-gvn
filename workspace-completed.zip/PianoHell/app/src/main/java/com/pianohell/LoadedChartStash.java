package com.pianohell;

/**
 * LoadedChartStash — hands a parsed chart from the import screen to the game screen.
 *
 * <p>Why not an Intent extra: a 5,000,000-note chart is ~80 MB of primitive arrays. That cannot go
 * through a Bundle (it would hit the TransactionTooLargeException long before the parser ever
 * finished) and it must not be serialised to disk just to move between two screens of the same app.
 *
 * <p>So the loader leaves the finished chart here and passes a one-line token through the Intent.
 * One slot only: the app has exactly one game screen, and {@link #take} clears the reference so the
 * arrays become collectable as soon as the run is over.
 */
public final class LoadedChartStash {

    public static final class Entry {
        public final ChartData chart;
        public final MidiMapper mapper;
        Entry(ChartData chart, MidiMapper mapper) { this.chart = chart; this.mapper = mapper; }
    }

    private static volatile Entry slot;

    private LoadedChartStash() { }

    public static String put(ChartData chart, MidiMapper mapper) {
        slot = new Entry(chart, mapper);
        return "stash";
    }

    public static Entry take(String token) {
        Entry e = slot;
        slot = null;
        return e;
    }
}
