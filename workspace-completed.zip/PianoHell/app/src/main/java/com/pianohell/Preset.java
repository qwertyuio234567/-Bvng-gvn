package com.pianohell;

/**
 * Preset — a bundled chart's catalogue entry.
 *
 * <p>Three chart sources exist:
 * <ol>
 *   <li><b>MIDI asset</b> ({@code assetPath != null, !procedural, audioAsset == null}) — the
 *       classic path: a bundled {@code .mid} file read by {@link MidiParser}.</li>
 *   <li><b>Audio asset</b> ({@code audioAsset != null}) — an MP3 bundled under
 *       {@code assets/songs/}. {@link AudioChartGenerator} runs TarsosDSP's McLeod pitch detector
 *       over the file and builds the chart from real detected pitches. Notes are NOT random — each
 *       note lands at the millisecond its pitch sounded in the recording.</li>
 *   <li><b>Procedural</b> ({@code procedural}) — generated live by {@link ChartGenerator}
 *       (black-MIDI tier).</li>
 * </ol>
 *
 * <p>Creator credits follow the GD community standard — the composer of the track, not Robtop.
 */
public final class Preset {

    public final String id;
    public final String title;
    public final String subtitle;
    /** Track composer / creator credit shown in the detail row. */
    public final String creator;
    public final int bpm;
    public final int difficulty;      // 1..12, shown as the big number on the row
    public final int noteCount;       // approximate; real count known after parsing / detection
    public final int themeIndex;      // NoteColors.THEME_NAMES index used for the swatch + play
    public final String assetPath;    // "presets/foo.mid" or null
    /** MP3 asset path for audio-detected charts, e.g. "songs/electrodynamix.mp3", or null. */
    public final String audioAsset;
    public final boolean procedural;  // generated instead of parsed / detected

    public Preset(String id, String title, String subtitle, String creator,
                  int bpm, int difficulty, int noteCount,
                  int themeIndex, String assetPath, String audioAsset, boolean procedural) {
        this.id = id; this.title = title; this.subtitle = subtitle; this.creator = creator;
        this.bpm = bpm; this.difficulty = difficulty; this.noteCount = noteCount;
        this.themeIndex = themeIndex; this.assetPath = assetPath;
        this.audioAsset = audioAsset; this.procedural = procedural;
    }

    // ------------------------------------------------------------------ convenience constructors

    /** MIDI-asset preset (classic path). */
    public static Preset midi(String id, String title, String subtitle, String creator,
                              int bpm, int difficulty, int noteCount, int themeIndex, String assetPath) {
        return new Preset(id, title, subtitle, creator, bpm, difficulty, noteCount,
                themeIndex, assetPath, null, false);
    }

    /** Audio-detected preset — notes come from TarsosDSP pitch detection, not from a MIDI file. */
    public static Preset audio(String id, String title, String subtitle, String creator,
                               int bpm, int difficulty, int noteCount, int themeIndex, String audioPath) {
        return new Preset(id, title, subtitle, creator, bpm, difficulty, noteCount,
                themeIndex, null, audioPath, false);
    }

    /** Procedural preset (e.g. black-MIDI symphony). */
    public static Preset procedural(String id, String title, String subtitle, String creator,
                                    int bpm, int difficulty, int noteCount, int themeIndex) {
        return new Preset(id, title, subtitle, creator, bpm, difficulty, noteCount,
                themeIndex, null, null, true);
    }

    // ------------------------------------------------------------------

    /**
     * Full preset catalogue, easy → insane.
     *
     * <p><b>GD creator credits</b> (the composers, not Robtop):
     * <ul>
     *   <li>Waterflame — Clubstep ("At the Speed of Light"), Electrodynamix, Theory of Everything 2,
     *       Clutterfunk, Electroman Adventures, Geometry Dash main theme.</li>
     *   <li>F-777 — Deadlocked, Fingerdash, The Lightning Road.</li>
     *   <li>DJVI — Base After Base, Supersonics, Figures.</li>
     *   <li>Step — Jumper, Time Machine, Cycles.</li>
     *   <li>ParagonX9 — Stereo Madness.</li>
     *   <li>MDK — Press Start (Geometrical Dominator).</li>
     *   <li>ForeverBound — Cant Let Go.</li>
     *   <li>Rukkus — Jumper (alternate).</li>
     * </ul>
     */
    public static final Preset[] ALL = {

        // ---- Classic MIDI tiers (pitch-perfect, instant load) --------------------------------
        midi("twinkle",  "Twinkle Warmup",    "Nursery melody · read the lanes",           "Traditional",   108,  2,    84, 0, "presets/twinkle.mid"),
        midi("canon",    "Canon in D",         "Arpeggios and sustained pedal holds",        "J. Pachelbel",   96,  5,   960, 1, "presets/canon.mid"),
        midi("cascade",  "Chromatic Cascade",  "Fast chromatic runs hand to hand",           "PianoHell",     160,  8,  9771, 4, "presets/cascade.mid"),
        midi("storm",    "Density Storm",      "Cluster chords, ~5,000 raw notes/sec",       "PianoHell",     200, 10, 246336, 2, "presets/storm.mid"),

        // ---- Audio-detected presets — notes are real pitches from the track ------------------
        // Electrodynamix by Waterflame (used in GD level "Electrodynamix" by RobTop)
        audio("electrodynamix", "Electrodynamix",
                "Notes detected from audio · not random",
                "Waterflame",
                174, 9, 1800, 4, "songs/electrodynamix.mp3"),

        // Naten3e / "At the Speed of Light" area — exact title depends on the upload
        audio("naten3e", "At the Speed of Light",
                "Notes detected from audio · not random",
                "Waterflame",
                200, 11, 2200, 2, "songs/naten3e.mp3"),

        // ---- Procedural black-MIDI tier -----------------------------------------------------
        procedural("blackmidi", "BLACK MIDI SYMPHONY",
                "2,000,000 notes · generated live",
                "PianoHell Procedural",
                300, 12, 2_000_000, 2),
    };

    public static Preset byId(String id) {
        for (Preset p : ALL) if (p.id.equals(id)) return p;
        return ALL[0];
    }

    /** Returns true when this preset's chart must go through {@link AudioChartGenerator}. */
    public boolean isAudioDetected() {
        return audioAsset != null;
    }

    /** "174 BPM · Waterflame · ★ 9" — the detail row under the title. */
    public String detailLine() {
        return String.format(java.util.Locale.US, "%d BPM · %s · %,d notes · %s",
                bpm, creator, noteCount, densityLabel());
    }

    private String densityLabel() {
        if (noteCount >= 500_000) return "BLACK MIDI";
        if (noteCount >= 50_000) return "insane";
        if (noteCount >= 5_000) return "very high";
        if (noteCount >= 1_000) return "high";
        return "chill";
    }
}
