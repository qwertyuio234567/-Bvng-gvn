package com.pianohell;

/**
 * ScrollWindow — the single place where chart time is mapped to screen geometry, and where the
 * visible slice of the chart is computed.
 *
 * <h3>The maths (and the bug this class exists to make impossible)</h3>
 * Screen y grows DOWNWARD, chart time grows toward the future, and by the time a note reaches the
 * hit line it is due:
 *
 * <pre>
 *     yHead(start) = hitLinePx − (start − songMs) · pxPerMs
 * </pre>
 *
 * So a note that has NOT arrived yet (start &gt; songMs) has yHead &lt; hitLinePx: it is ABOVE the hit
 * line, falling toward it. The top edge of the surface (y = 0) therefore shows the note that is due
 * {@code hitLinePx / pxPerMs} ms in the FUTURE, and the bottom edge shows the note that passed
 * {@code (surfaceH − hitLinePx) / pxPerMs} ms AGO:
 *
 * <pre>
 *     tTop    = songMs + hitLinePx / pxPerMs             // newest time that can be on screen
 *     tBottom = songMs − (surfaceH − hitLinePx) / pxPerMs // oldest time still on screen
 * </pre>
 *
 * <h3>Why this is a separate, pure class</h3>
 * v1.0.2 and earlier had those two signs swapped inside {@link GameView}, which meant the renderer
 * only ever fetched notes already AT or BEHIND the hit line: the playfield above the line stayed
 * empty and the game looked like it had not loaded a chart. Nothing about that fails to compile or
 * throws — it is a pure sign error in geometry, invisible to javac, lint and review. Keeping the
 * mapping here lets {@code tools/harness} check it against a brute-force visibility scan over every
 * note in a real chart (see {@code renderWindowInvariants} in PianoHellHarness.java).
 */
public final class ScrollWindow {

    /** Extra slack in buffer pixels around the surface, so tiles do not pop at the exact edge. */
    public static final float EDGE_SLACK = 16f;

    private ScrollWindow() { }

    /** Screen y of a note's attack edge. */
    public static float yForTime(long startMs, double songMs, float hitLinePx, float pxPerMs) {
        return (float) (hitLinePx - (startMs - songMs) * pxPerMs);
    }

    /** Newest chart time that can be on screen (top edge). */
    public static double timeAtTop(double songMs, float hitLinePx, float pxPerMs) {
        return songMs + hitLinePx / pxPerMs;
    }

    /** Oldest chart time still on screen (bottom edge). */
    public static double timeAtBottom(double songMs, float hitLinePx, float pxPerMs, float surfaceH) {
        return songMs - (surfaceH - hitLinePx) / pxPerMs;
    }

    /** Reusable output for {@link #compute}: no allocation in the render loop. */
    public static final class Bounds {
        public int first, last;         // half-open index range [first, last)
        public double tTop, tBottom;    // the time span that range was derived from
    }

    /**
     * Compute the index range the renderer must iterate for one frame — a GUARANTEED SUPERSET of
     * every tile that could be visible, derived rather than guessed:
     *
     * <p>A tile is visible while {@code yHead >= -SLACK} (top) and {@code yTail <= surfaceH + SLACK}
     * (bottom). Substituting {@code yHead = hitLinePx − (start − songMs)·pxPerMs} gives the exact
     * start-time span that can satisfy both, and the two subtleties below are what make it exact:
     *
     * <ol>
     *   <li><b>Tile height.</b> A tile keeps hanging over the bottom edge for
     *       {@code tileHeightPx / pxPerMs} ms after its head crosses it. Searching only up to the
     *       head's bottom-edge time silently loses the last few tiles of every frame — invisible in
     *       a screenshot, but it eats exactly the notes you were about to hit. (The first version of
     *       this helper had that bug; the brute-force scan in tools/harness caught it as 3-tile
     *       chord bursts going missing.)</li>
     *   <li><b>Long holds.</b> A hold whose START is long past can still be on screen, so the search
     *       reaches back by the chart's longest note.</li>
     * </ol>
     *
     * <p>Cost: two binary searches, independent of chart size — a 5,000,000-note chart costs exactly
     * the same as a 500-note one.
     *
     * @param maxHoldMs longest note duration in the chart (see {@link ChartData#maxDurationMs()})
     * @param tileHeightPx height of a tap tile in buffer pixels
     */
    public static void compute(ChartData chart, double songMs, float hitLinePx, float pxPerMs,
                               float surfaceH, int maxHoldMs, float tileHeightPx, Bounds out) {
        out.tTop = timeAtTop(songMs, hitLinePx, pxPerMs);
        out.tBottom = timeAtBottom(songMs, hitLinePx, pxPerMs, surfaceH);

        // Slack at the top: notes whose head is still above the surface within EDGE_SLACK.
        final double topSlackMs = EDGE_SLACK / pxPerMs;
        // Reach back: the tile-height overhang + edge slack, plus the longest hold in the chart.
        final int backMs = (int) Math.ceil((tileHeightPx + EDGE_SLACK) / pxPerMs)
                + Math.max(0, maxHoldMs);

        out.first = chart.lowerBound(Math.max(0, (long) Math.floor(out.tBottom) - backMs));
        out.last = chart.upperBound((long) Math.ceil(out.tTop + topSlackMs));
    }

    /** True when a tile spanning [yTail, yHead] can touch the surface. */
    public static boolean isVisible(float yHead, float yTail, float surfaceH) {
        return !(yHead < -EDGE_SLACK || yTail > surfaceH + EDGE_SLACK);
    }
}
