package com.pianohell;

/**
 * ChartGenerator — procedural preset charts.
 *
 * <p>Why generate instead of bundling a file: a genuine 2,000,000-note black-MIDI file is 50–300 MB.
 * Even zipped that is not something to put in an APK, so the top tier generates an equivalent chart
 * directly into the flat primitive arrays of {@link ChartData}. The generated chart then exercises
 * exactly the same render/judgment paths as a parsed one (a parsed 2M-note import takes the same
 * shape), which is what we want to be testing anyway.
 *
 * <p>Everything is written with {@link ChartData#append} in ascending time order, so
 * {@link ChartData#finishLoad()} skips the radix sort entirely (the O(n) monotonicity check passes)
 * and a 2M-note chart is playable within a couple of seconds of tapping it.
 */
public final class ChartGenerator {

    /** xorshift32 — deterministic, allocation-free, and fast enough for millions of notes. */
    private static final class Rng {
        private int s;
        Rng(int seed) { s = seed == 0 ? 0x9E3779B9 : seed; }
        int nextInt() { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return s; }
        int below(int n) { return (nextInt() >>> 1) % n; }
        float unit() { return (nextInt() >>> 8) / (float) (1 << 24); }
    }

    /**
     * Build a chart for a preset id. Only the {@code blackmidi} tier is generated here; the bundled
     * .mid tiers go through {@link MidiParser} like any user import.
     */
    public static ChartData generate(Preset preset, GameConfig cfg, MidiParser.Listener listener) {
        switch (preset.id) {
            case "blackmidi": return blackMidi(cfg, listener);
            default: return null;      // caller falls back to the asset
        }
    }

    /**
     * 2,000,000 notes across 12 lanes, generated in ascending time order.
     *
     * <p>Shape: a melodic spine (one voice that walks the lanes like a real melody) buried under
     * exponentially growing sheets of chords and tremolo, which is what black MIDI actually looks and
     * sounds like. The density ramps so the first 30 seconds are survivable and the last minute is
     * genuinely unplayable — that is the point of the genre.
     */
    public static ChartData blackMidi(GameConfig cfg, MidiParser.Listener listener) {
        final int TOTAL = 2_000_000;
        ChartData chart = new ChartData();
        chart.ensureCapacity(TOTAL);
        chart.title = "BLACK MIDI SYMPHONY";
        chart.subtitle = "procedurally generated · 2,000,000 notes";
        chart.bpm = 300;
        chart.themeIndex = 2;
        chart.isPreset = true;

        final Rng rng = new Rng(0xB1AC5);
        final int[] scale = MidiMapper.SCALES[2];           // harmonic minor: dramatic
        long t = 0;                                          // chart time in ms
        int noteBudget = TOTAL;
        int melodyLane = 6;
        int colorDefault = NoteColors.CHANNEL_BASE;          // multi-colour chaos, like the real thing
        int steps = 0;

        // Time grid shrinks while the number of notes per grid step grows quadratically, so the
        // chart stays roughly 10 minutes long and ends up in the 3,000-4,000 notes/second range —
        // the density a real black-MIDI file actually has. (Getting this arithmetic wrong is how you
        // end up with a chart that is technically 2M notes but takes 8 hours to play.)
        while (noteBudget > 0) {
            float progress = 1f - (float) noteBudget / TOTAL;
            int gridMs = progress < 0.33f ? 50 : progress < 0.66f ? 33 : progress < 0.9f ? 20 : 12;

            // ---- melodic spine: always present, always playable -------------------------------
            if (rng.unit() < 0.55f) {
                int step = rng.below(6) - 2;
                melodyLane = Math.max(0, Math.min(11, melodyLane + step));
                int pitch = 48 + melodyLane + (rng.unit() < 0.3f ? 12 : 0);
                chart.append(melodyLane, t, 0, NoteColors.CHANNEL_BASE + (rng.below(3)), pitch);
                noteBudget--;
            }

            // ---- sheets of chords: the "black" part ------------------------------------------
            // NOTE: the whole step emits in non-decreasing time order (melody @t, chords @t+1,
            // tremolo from t+2). Staying monotonic means finishLoad()'s O(n) sortedness check
            // passes and the 2M-note chart never needs the radix sort at all.
            // sqrt ramp: 6 .. ~206 notes per grid step. A quadratic ramp looks tempting but puts all
            // the density in the last few percent of the chart (the integral of p^2 is tiny at the
            // start), which is how you get a "2M note" chart that is actually 8 hours of ballads.
            int sheet = 6 + (int) (200 * Math.sqrt(progress));
            for (int i = 0; i < sheet && noteBudget > 0; i++) {
                int lane = rng.below(12);
                int octave = rng.unit() < 0.25f ? 12 : rng.unit() < 0.5f ? -12 : 0;
                int pitch = 36 + lane * 2 + octave;
                int dur = 0;
                if (rng.unit() < 0.06f) dur = 300 + rng.below(1800);  // occasional pedal hold
                chart.append(lane, t + 1, dur, colorDefault + rng.below(16), pitch);
                noteBudget--;
            }

            // ---- tremolo bursts: the lane repeats that make your fingers ache -----------------
            if (progress > 0.45f && rng.unit() < 0.25f) {
                int lane = rng.below(12);
                int reps = 3 + rng.below(6);
                final long step = Math.max(1, (gridMs - 3) / (reps + 1));   // fits inside this grid step
                for (int r = 0; r < reps && noteBudget > 0; r++) {
                    chart.append(lane, t + 2 + r * step, 0,
                            NoteColors.VELOCITY_BASE + rng.below(4), 36 + lane);
                    noteBudget--;
                }
            }

            t += gridMs;
            steps++;
            if ((noteBudget & 0x1FFFF) == 0 && listener != null) {   // report every 131k notes
                listener.onProgress((int) (100L * (TOTAL - noteBudget) / TOTAL), TOTAL - noteBudget,
                        "Generating black MIDI…");
                if (listener.isCancelled()) break;
            }
        }

        chart.noteOnCount = chart.count;      // raw note count, kept for the HUD ("2,000,000 notes")
        chart.finishLoad();
        // Run the same collapse the importer runs: 2M raw notes cannot be played 1:1 on 12 lanes,
        // and folding same-lane stacks into holds is exactly what the import pipeline does to a real
        // black-MIDI file. The preset therefore demonstrates the pipeline at full scale.
        if (cfg.collapseMs > 0) {
            chart.collapsePass(cfg.collapseMs, true);
            chart.recomputeLength();
        }
        chart.difficultyRating = MidiParser.rateDifficulty(
                chart.lengthMs <= 0 ? 0 : (int) (chart.noteOnCount * 1000L / chart.lengthMs));
        return chart;
    }
}
