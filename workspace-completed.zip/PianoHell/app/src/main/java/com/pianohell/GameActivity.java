package com.pianohell;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

/**
 * GameActivity — hosts the {@link GameView}, the engine, and the native audio engine.
 *
 * <p>Lifecycle rules that matter for a rhythm game:
 * <ul>
 *   <li>{@code onPause} → pause the SIMULATION and stop the render thread. Anything else would
 *       keep judging notes while the player is in another app.</li>
 *   <li>{@code onResume} → resume the simulation; the render thread is restarted by the surface
 *       callback itself, never by us.</li>
 *   <li>{@code onDestroy} → release the audio stream. Leaking an AAudio stream keeps the device's
 *       low-latency path busy and can make the next launch sound broken.</li>
 * </ul>
 */
public final class GameActivity extends Activity implements GameEngine.Listener {

    public static final String EXTRA_PRESET_ID = "preset_id";
    public static final String EXTRA_CHART_HANDLE = "chart_handle";

    private GameConfig cfg;
    private NoteColors colors;
    private NotePool pool;
    private AudioEngine audio;              // attaches asynchronously; the game runs silent until then
    private GameEngine engine;
    private GameView surface;
    private MidiMapper mapper;
    private volatile boolean destroyed;
    private Thread audioThread;

    private View loadingPanel;
    private TextView loadingText;
    private ProgressBar loadingBar;
    private View buttonRow;
    /**
     * NOTE the types — this is not cosmetic. The pause control in the HUD is a TextView with a button
     * background (activity_game.xml), while the pause/resume/quit row uses real Buttons. Declaring a
     * TextView as a Button compiles, because findViewById's signature is
     * {@code <T extends View> T findViewById(int)}: the compiler infers T from the assignment and
     * inserts a silent checkcast. On a device that becomes
     * {@code java.lang.ClassCastException: android.widget.TextView cannot be cast to android.widget.Button}
     * thrown from onCreate, which Android reports as the wonderfully vague
     * "Unable to start activity ComponentInfo{...GameActivity}". tools/check_view_types.py now
     * verifies every findViewById assignment against its layout, so this cannot come back.
     */
    private Button btnResume, btnRestart;
    private TextView btnPause;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable statePoller = new Runnable() {
        @Override public void run() {
            syncButtons();
            ui.postDelayed(this, 200);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cfg = GameConfig.load(this);
        colors = new NoteColors(cfg.themeIndex);

        setContentView(R.layout.activity_game);
        OrientationGuard.install(this, findViewById(R.id.gameRoot));

        surface = findViewById(R.id.gameSurface);
        loadingPanel = findViewById(R.id.loadingPanel);
        loadingText = findViewById(R.id.loadingText);
        loadingBar = findViewById(R.id.loadingBar);
        buttonRow = findViewById(R.id.buttonRow);
        btnResume = findViewById(R.id.btnResume);
        btnRestart = findViewById(R.id.btnRestart);
        btnPause = findViewById(R.id.btnPause);

        btnPause.setOnClickListener(v -> {
            if (engine == null) return;
            if (engine.getState() == GameEngine.STATE_PLAYING) engine.pause();
            else engine.resume();
            syncButtons();
        });
        btnResume.setOnClickListener(v -> { engine.resume(); syncButtons(); });
        btnRestart.setOnClickListener(v -> { engine.start(); syncButtons(); });
        findViewById(R.id.btnQuit).setOnClickListener(v -> finish());

        loadChart();
    }

    // ------------------------------------------------------------------
    // Chart acquisition (always async, always with progress)
    // ------------------------------------------------------------------

    private void loadChart() {
        String presetId = getIntent().getStringExtra(EXTRA_PRESET_ID);
        String handle = getIntent().getStringExtra(EXTRA_CHART_HANDLE);

        if (handle != null) {
            LoadedChartStash.Entry e = LoadedChartStash.take(handle);
            if (e != null) {            // came from the import screen: already parsed
                mapper = e.mapper;
                beginGame(e.chart, "imported chart");
                return;
            }
        }
        if (presetId == null) presetId = "twinkle";
        final Preset preset = Preset.byId(presetId);
        setLoading(true, "Loading " + preset.title + "…");

        ChartLoader.loadPreset(preset, cfg, new ChartLoader.Callback() {
            // Loader callbacks arrive on the main thread, but the activity may already be gone
            // (back button during a 200 MB import): touching views then is an instant crash.
            private boolean alive() { return !isFinishing() && !isDestroyed(); }

            @Override public void onProgress(int percent, long notes, String stage) {
                if (!alive()) return;
                loadingBar.setProgress(percent);
                loadingText.setText(preset.title + "\n" + stage
                        + (notes > 0 ? "\n" + String.format(java.util.Locale.US, "%,d notes", notes) : ""));
            }
            @Override public void onLoaded(ChartData chart, MidiMapper m, String describe) {
                if (!alive()) return;
                mapper = m;
                setLoading(false, describe);
                beginGame(chart, describe);
            }
            @Override public void onError(String message) {
                if (!alive()) return;
                // The loading panel is KEPT VISIBLE for errors. It used to be dismissed, which hid
                // the only copy of the message: the player was left staring at an empty board with
                // no explanation (exactly the "nothing appears in the roll" report). An error must
                // always be readable, even if it is ugly.
                showError(message);
            }
        });
    }

    private void setLoading(boolean show, String message) {
        loadingPanel.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) { loadingBar.setProgress(0); loadingText.setText(message); }
    }

    /** Keep the message on screen and offer a way out instead of a blank board. */
    private void showError(String message) {
        loadingPanel.setVisibility(View.VISIBLE);
        loadingBar.setVisibility(View.GONE);
        loadingText.setTextSize(16f);
        loadingText.setText("Could not load this chart\n\n" + message
                + "\n\nThe full detail is in the menu under LAST RUN CRASHED / logcat tag PianoHell.");
        buttonRow.setVisibility(View.VISIBLE);
        btnResume.setVisibility(View.GONE);
        btnRestart.setVisibility(View.GONE);
    }

    // ------------------------------------------------------------------
    // Start the run
    // ------------------------------------------------------------------

    private void beginGame(ChartData chart, String describe) {
      // Everything that can fail on a particular device (audio stream, surface, buffers) happens
      // here, so it is wrapped: a failure shows an in-app message instead of taking the app down
      // and leaving nothing behind but Android's "keeps stopping" dialog.
      try {
        colors = new NoteColors(chart.themeIndex);
        pool = new NotePool();
        // The audio engine is built on a BACKGROUND thread. Opening a low-latency stream and
        // pre-rendering the instrument samples is tens of milliseconds to a couple of seconds of
        // native work; doing it inline here would stall activity start (and put an expensive native
        // call on the launch path, which is precisely what has already bitten this app twice).
        // GameEngine tolerates a null AudioEngine, so the chart starts immediately and the sound
        // attaches a moment later — still before the first note reaches the hit line, because the
        // count-in has to scroll in first.
        engine = new GameEngine(chart, cfg, pool, null, mapper);
        engine.setListener(this);
        surface.bind(engine, cfg, colors, mapper);
        engine.start();
        startAudioAsync();
        syncButtons();
        ui.removeCallbacks(statePoller);
        ui.post(statePoller);
      } catch (Throwable t) {
        android.util.Log.e("PianoHell", "failed to start the run", t);
        setLoading(true, "Could not start this chart:\n\n" + t
                + "\n\nShare this text — it is the whole diagnosis.\n(the menu keeps the last crash report too)");
        ui.post(() -> syncButtons());
      }
    }

    /**
     * Build + start the native audio engine off the UI thread, then hand it to the simulation.
     * The engine re-learns its clock offset when it is attached mid-run (GameEngine.setAudio), so
     * song time stays continuous and no notes are judged against the wrong clock.
     */
    private void startAudioAsync() {
        if (audio != null) return;
        Thread t = new Thread(() -> {
            AudioEngine a = null;
            try {
                a = new AudioEngine();
                if (!a.isReady()) android.util.Log.w("PianoHell", "audio silent: " + a.describe());
            } catch (Throwable e) {
                android.util.Log.w("PianoHell", "audio unavailable, continuing silent", e);
                a = null;
            }
            final AudioEngine fa = a;
            if (destroyed) {                       // activity went away while we were starting up
                if (fa != null) fa.release();
                return;
            }
            ui.post(() -> {
                if (destroyed) { if (fa != null) fa.release(); return; }
                audio = fa;
                if (engine != null) engine.setAudio(fa);
                syncButtons();
            });
        }, "PianoHell-AudioInit");
        t.setDaemon(true);
        audioThread = t;
        t.start();
    }

    private void syncButtons() {
        if (engine == null) { buttonRow.setVisibility(View.GONE); return; }
        int state = engine.getState();
        boolean needsUi = state != GameEngine.STATE_PLAYING;
        buttonRow.setVisibility(needsUi ? View.VISIBLE : View.GONE);
        btnResume.setVisibility(state == GameEngine.STATE_PAUSED ? View.VISIBLE : View.GONE);
        btnRestart.setVisibility(needsUi && state != GameEngine.STATE_PAUSED ? View.VISIBLE : View.GONE);
        btnPause.setText(state == GameEngine.STATE_PLAYING ? getString(R.string.pause) : getString(R.string.resume));
    }

    // ------------------------------------------------------------------
    // Engine callbacks (already on the render thread → bounce to the UI thread)
    // ------------------------------------------------------------------

    @Override public void onRunFinished(GameEngine.RunResult result) {
        GameView.RunResultText t = new GameView.RunResultText();
        t.title = "CLEARED";
        t.body = result.pretty();
        surface.setResultText(t);
        ui.post(() -> syncButtons());
    }

    @Override public void onRunFailed(GameEngine.RunResult result, int laneThatKilledYou) {
        GameView.RunResultText t = new GameView.RunResultText();
        t.title = "FAILED";
        t.body = result.pretty();
        surface.setResultText(t);
        ui.post(() -> syncButtons());
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    @Override protected void onResume() {
        super.onResume();
        if (engine != null) engine.resume();
    }

    /** Surfaced in the HUD so a silent device is diagnosable without logcat. */
    public String audioStatus() {
        if (audio == null) return "audio: starting…";
        return audio.describe();
    }

    @Override protected void onPause() {
        super.onPause();
        ui.removeCallbacks(statePoller);
        if (engine != null) engine.pause();
        if (audio != null) audio.onRunPause();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        destroyed = true;
        ui.removeCallbacksAndMessages(null);
        surface.stopRenderThread();          // join the render thread BEFORE tearing the engine down
        if (engine != null) engine.setListener(null);
        if (audio != null) audio.release();
        engine = null;
        audio = null;
    }

    @Override public void onBackPressed() {
        if (engine != null && engine.getState() == GameEngine.STATE_PLAYING) {
            engine.pause();                  // first back = pause, second = leave. No accidental quits.
            syncButtons();
            return;
        }
        super.onBackPressed();
    }
}
