package com.pianohell;

/**
 * MidiMapper — the 128 → 12 lane mapping strategies.
 *
 * <h3>Why a 128-entry lookup table instead of computing per note?</h3>
 * The parser calls {@link #laneOf(int)} once per note-on. On a 5,000,000-note import that is
 * 5M+ calls; a modulo plus a scale search per call would be microseconds each. Instead
 * {@link #prepare} walks all 128 pitches ONCE and bakes the answers into two byte arrays.
 * Per-note cost afterwards is one array read — the same trick the render loop uses for colors.
 *
 * <h3>Modes</h3>
 * <ol>
 *   <li>{@link GameConfig#MAP_PITCH_CLASS} (default) — {@code lane = (pitch - root) mod 12}.
 *       Chromatic pitch classes: every C lands in lane 0, every C# in lane 1, and so on.
 *       This is the classic "12 columns = 12 keys" piano roll collapse.</li>
 *   <li>{@link GameConfig#MAP_SCALE} — pitch is quantized to the NEAREST degree of the chosen
 *       scale/key, then that degree index is spread evenly across the 12 lanes
 *       ({@code lane = degree * 12 / scaleSize}). A 7-note scale therefore uses lanes
 *       0,1,3,5,6,8,10 — the layout keeps scale steps apart in space, which feels far better
 *       under the fingers than cramming 7 degrees into lanes 0..6.</li>
 *   <li>{@link GameConfig#MAP_DENSITY} — cluster the 12 most-used pitch values in that file
 *       (from the pass-1 histogram) and give each its own lane; every other pitch snaps to the
 *       nearest chosen pitch. Ideal for black-MIDI files that only ever use ~15 pitches.</li>
 * </ol>
 */
public final class MidiMapper {

    /** Interval sets in semitones from the root. */
    public static final int[][] SCALES = {
            {0, 2, 4, 5, 7, 9, 11},        // Major (Ionian)
            {0, 2, 3, 5, 7, 8, 10},        // Natural minor (Aeolian)
            {0, 2, 3, 5, 7, 8, 11},        // Harmonic minor
            {0, 2, 3, 5, 7, 9, 11},        // Melodic minor
            {0, 2, 4, 7, 9},               // Major pentatonic
            {0, 3, 5, 7, 10},              // Minor pentatonic
            {0, 3, 5, 6, 7, 10},           // Blues
            {0, 2, 3, 5, 7, 9, 10},        // Dorian
            {0, 2, 4, 5, 7, 9, 10},        // Mixolydian
            {0, 2, 4, 6, 8, 10},           // Whole tone
            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11}, // Chromatic
    };

    public static final String[] SCALE_NAMES = {
            "Major", "Natural minor", "Harmonic minor", "Melodic minor", "Major pentatonic",
            "Minor pentatonic", "Blues", "Dorian", "Mixolydian", "Whole tone", "Chromatic"
    };

    private static final String[] MODE_NAMES = { "Pitch-class mod 12", "Scale quantize", "Density remap" };

    /** pitch -> lane, baked by {@link #prepare}. */
    private final byte[] lane = new byte[128];
    /** lane -> the MIDI pitch the audio engine will sound when that lane is struck. */
    private final int[] lanePitch = new int[12];

    private int activeMode = GameConfig.MAP_PITCH_CLASS;
    private int activeRoot = 0;
    private int activeScale = 0;
    /** For density mode: the 12 selected pitches, ascending (lane i == chosen[i]). */
    private final int[] chosen = new int[12];

    public static String[] modeNames() { return MODE_NAMES; }

    /**
     * Bake the mapping tables. Must be called AFTER pass 1 (it needs the histogram for density
     * mode) and BEFORE pass 2.
     */
    public void prepare(int[] histogram, GameConfig cfg) {
        activeMode = cfg.mappingMode;
        activeRoot = ((cfg.rootNote % 12) + 12) % 12;
        activeScale = Math.max(0, Math.min(SCALES.length - 1, cfg.scaleIndex));

        switch (activeMode) {
            case GameConfig.MAP_SCALE:   buildScale(SCALES[activeScale]); break;
            case GameConfig.MAP_DENSITY: buildDensity(histogram); break;
            default:                     buildPitchClass(); break;
        }
        buildLanePitches(histogram);
    }

    // ------------------------- mode 1: pitch class -------------------------
    private void buildPitchClass() {
        for (int p = 0; p < 128; p++) lane[p] = (byte) (((p - activeRoot) % 12 + 12) % 12);
    }

    // ------------------------- mode 2: scale quantize -------------------------
    /**
     * For each pitch: find the nearest scale degree above or below (ties resolve downward, which
     * keeps the leading tone from collapsing upward into the octave), then spread the degree
     * across the lanes so a 7-note scale still uses the whole keyboard width.
     */
    private void buildScale(int[] scale) {
        final int n = scale.length;
        for (int p = 0; p < 128; p++) {
            int rel = ((p - activeRoot) % 12 + 12) % 12;
            int bestDeg = 0, bestDist = 99;
            for (int d = 0; d < n; d++) {
                int dist = Math.abs(rel - scale[d]);
                dist = Math.min(dist, 12 - dist);                 // wrap around the octave
                if (dist < bestDist) { bestDist = dist; bestDeg = d; }
            }
            lane[p] = (byte) (bestDeg * 12 / n);
        }
    }

    // ------------------------- mode 3: density remap -------------------------
    /**
     * Pick the 12 most-used pitch values (ties broken by lower pitch) and give them lanes in
     * ascending pitch order, then snap every other pitch to the nearest chosen one.
     * A selection sort over 128 candidates — O(12*128) — runs once per import, not per note.
     */
    private void buildDensity(int[] histogram) {
        final int[] hist = histogram != null ? histogram : new int[128];
        final boolean[] taken = new boolean[128];
        int found = 0;
        for (int k = 0; k < 12; k++) {
            int best = -1, bestCount = 0;
            for (int p = 0; p < 128; p++) {
                if (taken[p]) continue;
                if (hist[p] > bestCount || (hist[p] == bestCount && best >= 0 && p < best)) {
                    best = p; bestCount = hist[p];
                }
            }
            if (best < 0 || (bestCount == 0 && k > 0 && found == 0)) break;   // empty/sparse file
            if (best < 0) best = k * 9;                                       // fall back to a spread
            taken[best] = true;
            chosen[found++] = best;
        }
        if (found == 0) { buildPitchClass(); return; }
        // Sort the chosen pitches ascending so lane order follows the keyboard, not frequency
        // (frequency order makes tiles jump around the screen for melodic material).
        java.util.Arrays.sort(chosen, 0, found);
        for (int p = 0; p < 128; p++) {
            int bestLane = 0, bestDist = 999;
            for (int i = 0; i < found; i++) {
                int d = Math.abs(p - chosen[i]);
                if (d < bestDist) { bestDist = d; bestLane = i; }
            }
            lane[p] = (byte) bestLane;
        }
    }

    // ------------------------- lane -> playback pitch -------------------------
    /**
     * Which MIDI pitch should sound when the player hits lane i? Answer: the most-used pitch in that
     * file that maps to lane i (so the audio matches the chart the player is looking at). Falls back
     * to the scale/root note when a lane is unused.
     */
    private void buildLanePitches(int[] histogram) {
        final int[] hist = histogram != null ? histogram : new int[128];
        final int[] bestCount = new int[12];
        for (int i = 0; i < 12; i++) {
            lanePitch[i] = clampPitch(activeRoot + i + 48);          // sane default: mid keyboard
            bestCount[i] = -1;
        }
        for (int p = 24; p < 108; p++) {                             // ignore extreme registers
            int l = lane[p] & 0xFF;
            if (hist[p] > bestCount[l]) { bestCount[l] = hist[p]; lanePitch[l] = p; }
        }
    }

    private static int clampPitch(int p) { return p < 21 ? p + 12 : p > 108 ? p - 12 : p; }

    // ------------------------- queries (hot path) -------------------------

    /** Lane for a MIDI pitch. One array read; this is called millions of times per import. */
    public int laneOf(int pitch) { return lane[pitch & 0x7F]; }

    /**
     * Color id for a note, honoring the config:
     * channel-based (up to 16 colors), velocity buckets, or the plain lane color.
     * Resolved to a tiny palette index here so the renderer only ever does palette[id].
     */
    public int colorOf(int pitch, int channel, int velocity, GameConfig cfg) {
        if (cfg.colorByChannel) return NoteColors.CHANNEL_BASE + (channel & 15);
        if (cfg.colorByVelocity) {
            int b = velocity < 40 ? 0 : velocity < 80 ? 1 : velocity < 110 ? 2 : 3;
            return NoteColors.VELOCITY_BASE + b;
        }
        return lane[pitch & 0x7F];
    }

    public int lanePlaybackPitch(int laneIdx) { return lanePitch[laneIdx % 12]; }

    public int[] lanePlaybackPitches() { return lanePitch; }

    /** Short human-readable description of the active mapping (shown in the import panel/HUD). */
    public String describe() {
        switch (activeMode) {
            case GameConfig.MAP_SCALE:
                return "Scale quantize · " + SCALE_NAMES[activeScale] + " in root " + activeRoot;
            case GameConfig.MAP_DENSITY:
                StringBuilder sb = new StringBuilder("Density remap · lanes = pitches ");
                for (int i = 0; i < 12; i++) { if (i > 0) sb.append(','); sb.append(chosen[i]); }
                return sb.toString();
            default:
                return "Pitch class mod 12 · lane = (pitch − " + activeRoot + ") % 12";
        }
    }
}
