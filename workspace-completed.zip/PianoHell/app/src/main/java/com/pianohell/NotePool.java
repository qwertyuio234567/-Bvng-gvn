package com.pianohell;

/**
 * NotePool — object pooling, used where objects are unavoidable.
 *
 * <p>The NOTES themselves are never objects (see {@link ChartData}: struct-of-arrays flat buffers).
 * What the renderer does need per frame is a small mutable "display record" per visible note holding
 * screen-space geometry — that is what gets pooled here. Same for hit sparks/particles.
 *
 * <p>Why it matters: at black-MIDI density with a tall tile window you can have several thousand
 * visible tiles and 200 hits/second. Allocating those records each frame would put the GC
 * (and its pauses) directly inside the render loop, causing dropped frames at exactly the moment
 * the chart is densest. Pooling makes steady-state play allocation-free: the loop reuses
 * {@link #MAX_ACTIVE} preallocated slots, and {@link #resetFrame()} just rewinds the cursor.
 *
 * <p>Thread-safety: one pool per thread (the render thread owns {@link #active}, the game thread owns
 * {@link #pendingHits}); nothing is shared, so no locks — a lock in the render loop would be worse
 * than the allocation it saves.
 */
public final class NotePool {

    /** Upper bound on tiles on screen at once. (Screen height / minimum tile height) * 12 lanes. */
    public static final int MAX_ACTIVE = 4096;
    /** Hit sparks alive at once. */
    public static final int MAX_PARTICLES = 1024;
    /** Touch events buffered between the game thread's fixed steps. */
    public static final int MAX_EVENTS = 2048;

    /** Screen-space geometry for one visible tile. Mutable by design; pooled, never shared. */
    public static final class ActiveNote {
        public int chartIndex;
        public float x, y, w, h;
        public int color;          // ARGB ready to write into the pixel buffer
        public boolean hold;
        public boolean hit;
        public float glow;

        void reset(int chartIndex, float x, float y, float w, float h, int color, boolean hold) {
            this.chartIndex = chartIndex;
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.color = color; this.hold = hold;
            this.hit = false; this.glow = 0f;
        }
    }

    /** A hit spark. */
    public static final class Particle {
        public float x, y, vx, vy, life, lifeMax;
        public int color;
        void reset(float x, float y, float vx, float vy, float life, int color) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.life = this.lifeMax = life; this.color = color;
        }
    }

    /** A finger event captured on the UI thread, consumed by the fixed-timestep game step. */
    public static final class TouchEvent {
        public static final int DOWN = 0, MOVE = 1, UP = 2, CANCEL = 3;
        public int type;
        public int pointerId;
        public float x, y;
        public long timeMs;
        void reset(int type, int pointerId, float x, float y, long timeMs) {
            this.type = type; this.pointerId = pointerId; this.x = x; this.y = y; this.timeMs = timeMs;
        }
    }

    private final ActiveNote[] pool = new ActiveNote[MAX_ACTIVE];
    private int used = 0;

    private final Particle[] particles = new Particle[MAX_PARTICLES];
    private int particleUsed = 0;

    private final TouchEvent[] events = new TouchEvent[MAX_EVENTS];
    private int eventHead = 0, eventTail = 0;

    public NotePool() {
        for (int i = 0; i < MAX_ACTIVE; i++) pool[i] = new ActiveNote();
        for (int i = 0; i < MAX_PARTICLES; i++) particles[i] = new Particle();
        for (int i = 0; i < MAX_EVENTS; i++) events[i] = new TouchEvent();
    }

    // ---------------- visible tile records (render thread only) ----------------

    public int activeCount() { return used; }

    public ActiveNote activeAt(int i) { return pool[i]; }

    public void resetFrame() { used = 0; }

    /**
     * Grab a display slot. Returns null when the pool is exhausted — the renderer treats that as
     * "too many tiles to draw this frame" and simply skips the rest, which degrades gracefully
     * instead of allocating or crashing.
     */
    public ActiveNote acquireActive(int chartIndex, float x, float y, float w, float h, int color, boolean hold) {
        if (used >= MAX_ACTIVE) return null;
        ActiveNote n = pool[used++];
        n.reset(chartIndex, x, y, w, h, color, hold);
        return n;
    }

    // ---------------- particles ----------------

    public int particleCount() { return particleUsed; }

    public Particle particleAt(int i) { return particles[i]; }

    public void spawnParticle(float x, float y, float vx, float vy, float life, int color) {
        if (particleUsed >= MAX_PARTICLES) {
            // Full: recycle the oldest slot by overwriting it in round-robin order (no growth, no alloc).
            Particle p = particles[particleUsed % MAX_PARTICLES];
            p.reset(x, y, vx, vy, life, color);
            return;
        }
        particles[particleUsed++].reset(x, y, vx, vy, life, color);
    }

    public void compactParticles(float dtSeconds) {
        int w = 0;
        for (int i = 0; i < particleUsed; i++) {
            Particle p = particles[i];
            p.life -= dtSeconds;
            p.x += p.vx * dtSeconds;
            p.y += p.vy * dtSeconds;
            if (p.life > 0) particles[w++] = p;      // compaction happens in the pooled array, no alloc
        }
        particleUsed = w;
    }

    public void clearParticles() { particleUsed = 0; }

    // ---------------- input ring buffer (UI thread -> game thread) ----------------

    /** Producer side: called from onTouchEvent on the UI thread. Never blocks, never allocates. */
    public synchronized void pushEvent(int type, int pointerId, float x, float y, long timeMs) {
        int next = (eventHead + 1) % MAX_EVENTS;
        if (next == eventTail) return;               // ring full: drop the oldest semantics via overwrite-free drop
        events[eventHead].reset(type, pointerId, x, y, timeMs);
        eventHead = next;
    }

    /** Consumer side: called from the fixed-timestep game step. */
    public synchronized int drainEvents(int max, TouchEvent[] out) {
        int n = 0;
        while (eventTail != eventHead && n < max) {
            TouchEvent e = events[eventTail];
            out[n++] = e;                            // callers pass a preallocated array too
            eventTail = (eventTail + 1) % MAX_EVENTS;
        }
        return n;
    }

    public void clearEvents() { eventHead = eventTail = 0; }
}
