package com.pianohell;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ChartLoader — every path that produces a {@link ChartData}, always OFF the UI thread.
 *
 * <p>Three sources, one rule ("never block the UI thread"):
 * <ol>
 *   <li><b>Bundled preset .mid</b> — read from assets, parsed by {@link MidiParser}.</li>
 *   <li><b>User import (SAF)</b> — opened through {@link MidiParser.Source} so the parser can make
 *       its two streaming passes; the result is cached as a {@code .phc} file so the same chart
 *       reopens instantly next time.</li>
 *   <li><b>Procedural preset</b> — generated straight into the flat arrays
 *       ({@link ChartGenerator}) on the same worker thread.</li>
 * </ol>
 *
 * <p>Progress and cancellation are funneled through {@link MidiParser.Listener}; the callback is
 * always delivered on the main thread so the UI can touch views safely.
 */
public final class ChartLoader {

    private static final ExecutorService POOL = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "PianoHell-ChartLoader");
        // Slightly below normal: the render thread must win any CPU contention.
        t.setPriority(Thread.NORM_PRIORITY - 1);
        return t;
    });
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Callback {
        void onProgress(int percent, long notes, String stage);
        void onLoaded(ChartData chart, MidiMapper mapper, String describe);
        void onError(String message);
    }

    public static Context appContext() { return PhApp.get(); }

    // ------------------------------------------------------------------
    // Entry points
    // ------------------------------------------------------------------

    /**
     * Load a catalogue preset.
     *
     * <ul>
     *   <li>Procedural presets are generated live by {@link ChartGenerator}.</li>
     *   <li>Audio-detected presets go through {@link AudioChartGenerator}, which runs
     *       TarsosDSP's McLeod pitch detector over the bundled MP3 — notes are NOT random;
     *       every note is a real pitch detected at its real timestamp in the audio.</li>
     *   <li>Everything else parses its bundled {@code .mid} asset via {@link MidiParser}.</li>
     * </ul>
     */
    public static void loadPreset(Preset preset, GameConfig cfg, Callback cb) {
        final Context ctx = appContext();
        final Canceller cancel = new Canceller();
        POOL.execute(() -> {
            try {
                // ---- Procedural tier (black-MIDI) -------------------------------------------
                if (preset.procedural) {
                    post(cb, () -> cb.onProgress(1, 0, "Generating " + preset.noteCount + " notes…"));
                    ChartData chart = ChartGenerator.generate(preset, cfg, toListener(cb, cancel));
                    chart.title = preset.title;
                    chart.subtitle = preset.subtitle;
                    chart.themeIndex = preset.themeIndex;
                    chart.isPreset = true;
                    MidiMapper mapper = new MidiMapper();
                    mapper.prepare(null, cfg);
                    finish(cb, chart, mapper, "generated · " + chart.count + " notes");
                    return;
                }

                // ---- Audio-detected tier (TarsosDSP pitch detection from MP3) ---------------
                if (preset.isAudioDetected()) {
                    File cached = ctx != null
                            ? ChartIO.cacheFile(ctx, "audio_" + preset.id + "_" + cfgKey(cfg))
                            : null;
                    if (cached != null && cached.exists()) {
                        post(cb, () -> cb.onProgress(30, preset.noteCount, "Loading cached audio chart…"));
                        try {
                            ChartData chart = ChartIO.read(cached);
                            MidiMapper mapper = mapperForCachedChart(chart, cfg);
                            finish(cb, chart, mapper, "cache · " + chart.count + " notes · by " + preset.creator);
                            return;
                        } catch (Throwable badCache) {
                            android.util.Log.w("PianoHell", "discarding unusable audio chart cache " + cached, badCache);
                            if (!cached.delete()) cached.deleteOnExit();
                        }
                    }

                    post(cb, () -> cb.onProgress(5, 0,
                            "Detecting pitches in \"" + preset.title + "\" by " + preset.creator + "…"));
                    final MidiParser.Listener listener = toListener(cb, cancel);
                    ChartData chart = AudioChartGenerator.generate(ctx, preset, listener);

                    // Cache so the next launch skips detection (takes a few seconds first time).
                    if (cached != null && chart.count <= 400_000) {
                        try {
                            ChartIO.write(chart, cached);
                        } catch (IOException ignored) { }
                    }

                    MidiMapper mapper = new MidiMapper();
                    mapper.prepare(null, cfg);
                    finish(cb, chart, mapper,
                            "audio-detected · " + chart.count + " notes · by " + preset.creator);
                    return;
                }

                // ---- MIDI-asset tier --------------------------------------------------------
                File cached = ctx != null ? ChartIO.cacheFile(ctx, "preset_" + preset.id + "_" + cfgKey(cfg)) : null;
                if (cached != null && cached.exists()) {
                    post(cb, () -> cb.onProgress(30, preset.noteCount, "Loading cached chart…"));
                    try {
                        ChartData chart = ChartIO.read(cached);
                        MidiMapper mapper = mapperForCachedChart(chart, cfg);
                        finish(cb, chart, mapper, "cache · " + chart.count + " notes");
                        return;
                    } catch (Throwable badCache) {
                        // Written by an older build, corrupted, or truncated. Discard it and do the
                        // real work: a cache miss is a slow load, never a failed load.
                        android.util.Log.w("PianoHell", "discarding unusable chart cache " + cached, badCache);
                        if (!cached.delete()) cached.deleteOnExit();
                    }
                }
                byte[] data = readAsset(ctx, preset.assetPath);
                MidiParser.Source src = new MidiParser.BytesSource(data, preset.title);
                loadFromSource(src, preset.title, preset.subtitle, preset.themeIndex, cfg, cb, cancel, cached, true);
            } catch (Throwable t) {
                post(cb, () -> cb.onError("Preset load failed: " + t.getMessage()));
            }
        });
    }

    /** Import a user-picked .mid via SAF. */
    public static void loadMidiUri(Uri uri, GameConfig cfg, Callback cb) {
        final Context ctx = appContext();
        final Canceller cancel = new Canceller();
        POOL.execute(() -> {
            try {
                String name = queryName(ctx, uri);
                MidiParser.Source src = new SafSource(ctx, uri, name);
                File cached = ctx != null ? ChartIO.cacheFile(ctx, "import_" + uri + "_" + cfgKey(cfg)) : null;
                if (cached != null && cached.exists() && src.length() >= 0) {
                    post(cb, () -> cb.onProgress(20, 0, "Loading cached import…"));
                    try {
                        ChartData chart = ChartIO.read(cached);
                        MidiMapper mapper = mapperForCachedChart(chart, cfg);
                        finish(cb, chart, mapper, "cache · " + chart.count + " notes");
                        return;
                    } catch (Throwable badCache) {
                        android.util.Log.w("PianoHell", "discarding unusable import cache " + cached, badCache);
                        if (!cached.delete()) cached.deleteOnExit();
                    }
                }
                loadFromSource(src, name, "imported", cfg.themeIndex, cfg, cb, cancel, cached, false);
            } catch (Throwable t) {
                post(cb, () -> cb.onError("Import failed: " + t.getMessage()));
            }
        });
    }

    public static void cancelAll() { /* single-thread executor: the canceller below covers the active job */ }

    /**
     * Rebuild the mapper for a chart that came from the .phc cache. The cache stores the raw MIDI
     * pitches and the mapping settings that were used, so density mode can rebuild its histogram
     * from the chart itself and every other mode is a lookup-table rebuild. Without this, a cached
     * chart would play with pitch-class lanes while its audio used a different lane→pitch table.
     */
    private static MidiMapper mapperForCachedChart(ChartData chart, GameConfig cfg) {
        GameConfig c = cfg.copy();
        c.mappingMode = chart.mappingMode;
        c.scaleIndex = chart.scaleIndex;
        c.rootNote = chart.rootNote;

        int[] histogram = null;
        if (c.mappingMode == GameConfig.MAP_DENSITY) {
            histogram = new int[128];
            for (int i = 0; i < chart.count; i++) {
                int p = chart.midiPitch[i];
                if (p >= 0 && p < 128) histogram[p]++;
            }
        }
        MidiMapper mapper = new MidiMapper();
        mapper.prepare(histogram, c);
        return mapper;
    }

    // ------------------------------------------------------------------
    // Shared pipeline
    // ------------------------------------------------------------------

    private static void loadFromSource(MidiParser.Source src, String title, String subtitle, int theme,
                                       GameConfig cfg, Callback cb, Canceller cancel, File cacheOut,
                                       boolean isPreset) throws IOException {
        final ChartData chart = new ChartData();
        final MidiMapper mapper = new MidiMapper();
        chart.title = title;
        chart.subtitle = subtitle;
        chart.themeIndex = theme;
        chart.isPreset = isPreset;

        MidiParser.Listener listener = toListener(cb, cancel);
        MidiParser.Stats stats = MidiParser.parse(src, mapper, cfg, chart, listener);

        // Cache the parsed chart for instant reloads (never for the multi-million-note tiers: the
        // write itself would cost more than it saves the first time).
        if (cacheOut != null && chart.count <= 400_000) {
            try {
                post(cb, () -> cb.onProgress(99, chart.count, "Caching chart…"));
                ChartIO.write(chart, cacheOut);
            } catch (IOException ignored) { /* a failed cache write is not a failed import */ }
        }
        finish(cb, chart, mapper, "parsed in " + stats.parseMs + " ms · " + stats.notesPerSecond()
                + " notes/s" + (stats.tempoChanges > 0 ? " · " + stats.tempoChanges + " tempo changes" : ""));
    }

    private static void finish(Callback cb, ChartData chart, MidiMapper mapper, String describe) {
        post(cb, () -> cb.onLoaded(chart, mapper, describe + "\n" + mapper.describe()));
    }

    private static MidiParser.Listener toListener(Callback cb, Canceller cancel) {
        return new MidiParser.Listener() {
            private long lastPost = 0;

            @Override public void onProgress(int percent, long notes, String stage) {
                long now = android.os.SystemClock.uptimeMillis();
                if (now - lastPost < 60 && percent < 100) return;    // throttle: 16 posts/second max
                lastPost = now;
                post(cb, () -> cb.onProgress(percent, notes, stage));
            }

            @Override public boolean isCancelled() { return cancel.cancelled; }
        };
    }

    private static void post(Callback cb, Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) r.run();
        else MAIN.post(r);
    }

    /** Simple flag object: the import screen flips it when the user backs out. */
    public static final class Canceller { public volatile boolean cancelled = false; }

    // ------------------------------------------------------------------
    // Sources
    // ------------------------------------------------------------------

    /**
     * SAF source: re-opens the document for each parsing pass. The parser reads the file twice
     * (tempo map, then notes) and never buffers the whole thing, so this is what keeps a 300 MB
     * black-MIDI import inside a phone's memory budget.
     */
    private static final class SafSource implements MidiParser.Source {
        private final Context ctx;
        private final Uri uri;
        private final String name;
        SafSource(Context ctx, Uri uri, String name) { this.ctx = ctx; this.uri = uri; this.name = name; }
        @Override public InputStream open() throws IOException {
            InputStream in = ctx.getContentResolver().openInputStream(uri);
            if (in == null) throw new IOException("Cannot open " + uri);
            return in;
        }
        @Override public long length() {
            try (android.content.res.AssetFileDescriptor fd = ctx.getContentResolver().openAssetFileDescriptor(uri, "r")) {
                return fd != null ? fd.getLength() : -1;
            } catch (IOException e) { return -1; }
        }
        @Override public String name() { return name; }
    }

    static byte[] readAsset(Context ctx, String path) throws IOException {
        try (InputStream in = ctx.getAssets().open(path)) {
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream(1 << 16);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            return bos.toByteArray();
        }
    }

    private static String queryName(Context ctx, Uri uri) {
        try (android.database.Cursor c = ctx.getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Throwable ignored) { }
        String last = uri.getLastPathSegment();
        return last != null ? last : "imported.mid";
    }

    /** Cache key includes the mapping settings, because the same file maps differently. */
    private static String cfgKey(GameConfig cfg) {
        return "m" + cfg.mappingMode + "_s" + cfg.scaleIndex + "_r" + cfg.rootNote
                + "_c" + cfg.collapseMs + "_d" + (cfg.ignoreDrums ? 1 : 0);
    }
}
