package com.pianohell;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import be.tarsos.dsp.pitch.McLeodPitchMethod;
import be.tarsos.dsp.pitch.PitchDetectionResult;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * AudioChartGenerator — builds a {@link ChartData} by running TarsosDSP's McLeod Pitch Method
 * (MPM) over a bundled MP3 asset.
 *
 * <h3>Why pitch detection instead of a bundled MIDI?</h3>
 * The GD songs uploaded by the user are MP3 audio files. There is no accompanying MIDI, so we
 * detect the dominant pitch in each ~46 ms analysis window, quantize it to the nearest semitone,
 * and emit a note-on whose duration equals the time until the pitch either drops silent or changes
 * by more than a semitone. The result is a faithful melodic "skeleton" of the track — every
 * detected note lands at the exact millisecond it sounded in the audio, so notes are never
 * random.
 *
 * <h3>Pipeline</h3>
 * <ol>
 *   <li>TarsosDSP opens the asset via its Android MP3 decoder (FFMPEG locator).</li>
 *   <li>McLeod algorithm (more robust than YIN for pitched instruments) runs at 2048 samples /
 *       1024 overlap ≈ 43 ms resolution at 44.1 kHz.</li>
 *   <li>Pitches with confidence &lt; {@link #MIN_CONFIDENCE} are treated as silence.</li>
 *   <li>Consecutive windows of the same semitone are merged into one long note.</li>
 *   <li>The note list is stuffed into a {@link ChartData} via
 *       {@link ChartData#append}, which stays monotonic, so
 *       {@link ChartData#finishLoad()} never needs the radix sort.</li>
 * </ol>
 *
 * <h3>Lane mapping</h3>
 * We use pitch-class mod 12 — identical to {@link GameConfig#MAP_PITCH_CLASS}. This mirrors
 * what the MIDI import pipeline produces, so the judgment/score system needs no special cases.
 */
public final class AudioChartGenerator {

    /** Below this confidence the window is treated as silence. MPM range is 0..1. */
    private static final float MIN_CONFIDENCE = 0.85f;

    /** Windows whose Hz reading is outside this range are discarded (noise / sub-bass artifacts). */
    private static final float MIN_HZ = 60f;     // B1 — below that it is usually not melody
    private static final float MAX_HZ = 2100f;   // C7 — above that is usually overtone noise

    /** Merge consecutive windows into a held note if the semitone is the same. */
    private static final int WINDOW_MS = 43;     // ≈ 2048/44100 * 1000

    /** Minimum hold duration we emit (shorter presses feel impossible to tap). */
    private static final int MIN_NOTE_MS = 80;

    /**
     * Analyse {@code assetPath} (relative to assets/, e.g. {@code "songs/electrodynamix.mp3"})
     * and return a ready-to-play {@link ChartData}.
     *
     * @param ctx       Android context — needed to open the asset stream.
     * @param preset    The preset this chart belongs to (provides title, bpm, themeIndex, etc.).
     * @param listener  Progress + cancellation; may be null for synchronous use.
     * @return          A populated {@link ChartData} that has passed through
     *                  {@link ChartData#finishLoad()}.
     * @throws Exception on any I/O or decoder error.
     */
    public static ChartData generate(Context ctx, Preset preset, MidiParser.Listener listener)
            throws Exception {

        // ---------------------------------------------------------------
        // Step 1: decode the MP3 with MediaCodec -> mono float PCM, and run the McLeod
        // pitch detector (TarsosDSP core) on 2048-sample windows with a 1024-sample hop.
        // ---------------------------------------------------------------
        final List<long[]> events = new ArrayList<>(4096);   // [timeMs, midiPitch or -1]
        final int WIN = 2048, HOP = 1024;
        final float[] win = new float[WIN];
        int filled = 0;
        long winStartSample = 0;

        AssetFileDescriptor afd = ctx.getAssets().openFd(preset.audioAsset);
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String m = f.getString(MediaFormat.KEY_MIME);
                if (m != null && m.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) throw new java.io.IOException("No audio track in " + preset.audioAsset);
            ex.selectTrack(track);

            int sampleRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int channels = fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 2;
            long durationUs = fmt.containsKey(MediaFormat.KEY_DURATION)
                    ? fmt.getLong(MediaFormat.KEY_DURATION) : 0;

            McLeodPitchMethod mpm = new McLeodPitchMethod(sampleRate, WIN);

            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false, outputDone = false;
            long lastProgressMs = 0;

            while (!outputDone) {
                if (listener != null && listener.isCancelled()) break;

                if (!inputDone) {
                    int inIdx = codec.dequeueInputBuffer(10_000);
                    if (inIdx >= 0) {
                        ByteBuffer inBuf = codec.getInputBuffer(inIdx);
                        int size = ex.readSampleData(inBuf, 0);
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }

                int outIdx = codec.dequeueOutputBuffer(info, 10_000);
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    continue;
                }
                if (outIdx < 0) continue;

                ByteBuffer out = codec.getOutputBuffer(outIdx);
                if (out != null && info.size > 0) {
                    out.position(info.offset);
                    out.limit(info.offset + info.size);
                    java.nio.ShortBuffer sb = out.order(java.nio.ByteOrder.nativeOrder()).asShortBuffer();
                    int frames = sb.remaining() / Math.max(1, channels);
                    for (int fr = 0; fr < frames; fr++) {
                        float sum = 0f;
                        for (int ch = 0; ch < channels; ch++) sum += sb.get();
                        win[filled++] = (sum / channels) / 32768f;
                        if (filled == WIN) {
                            long timeMs = winStartSample * 1000L / sampleRate;
                            PitchDetectionResult r = mpm.getPitch(win);
                            float hz = r.getPitch();
                            float conf = r.getProbability();
                            if (hz > MIN_HZ && hz < MAX_HZ && conf >= MIN_CONFIDENCE) {
                                int midi = Math.round(69f + 12f * (float) (Math.log(hz / 440.0) / Math.log(2.0)));
                                midi = Math.max(0, Math.min(127, midi));
                                events.add(new long[]{ timeMs, midi });
                            } else {
                                events.add(new long[]{ timeMs, -1L });
                            }
                            System.arraycopy(win, HOP, win, 0, WIN - HOP);
                            filled = WIN - HOP;
                            winStartSample += HOP;
                        }
                    }
                }
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                codec.releaseOutputBuffer(outIdx, false);

                if (listener != null && durationUs > 0) {
                    long nowMs = info.presentationTimeUs / 1000;
                    if (nowMs - lastProgressMs > 250) {
                        lastProgressMs = nowMs;
                        int pct = (int) Math.min(65, 5 + nowMs * 1000L * 60 / durationUs);
                        listener.onProgress(pct, events.size(), "Analysing audio…");
                    }
                }
            }
        } finally {
            if (codec != null) { try { codec.stop(); } catch (Throwable ignored) { } codec.release(); }
            ex.release();
            try { afd.close(); } catch (java.io.IOException ignored) { }
        }

        if (listener != null) listener.onProgress(70, events.size(), "Building chart…");

        // ---------------------------------------------------------------
        // Step 2: merge consecutive windows with the same semitone.
        // ---------------------------------------------------------------
        ChartData chart = new ChartData();
        chart.ensureCapacity(events.size());
        chart.title       = preset.title;
        chart.subtitle    = preset.subtitle;
        chart.bpm         = preset.bpm;
        chart.themeIndex  = preset.themeIndex;
        chart.isPreset    = true;

        long noteStart = -1;
        int  notePitch = -1;
        int  noteCount = 0;

        for (int i = 0; i <= events.size(); i++) {
            long timeMs   = i < events.size() ? events.get(i)[0] : Long.MAX_VALUE;
            int  thisPitch = i < events.size() ? (int) events.get(i)[1] : -1;

            // Did the pitch change (including going silent)?
            if (thisPitch != notePitch) {
                // Emit the previous note
                if (notePitch >= 0 && noteStart >= 0) {
                    long dur = Math.max(0, timeMs - noteStart - 10);  // 10ms gap between tiles
                    if (dur >= MIN_NOTE_MS) {
                        int lane  = notePitch % 12;
                        int color = NoteColors.CHANNEL_BASE + (notePitch / 12) % 16;
                        chart.append(lane, noteStart, (int) Math.min(dur, 3000),
                                color, notePitch);
                        noteCount++;
                    }
                }
                noteStart = timeMs;
                notePitch = thisPitch;
            }
        }

        chart.noteOnCount = noteCount;
        chart.finishLoad();

        chart.difficultyRating = MidiParser.rateDifficulty(
                chart.lengthMs <= 0 ? 0 : (int) (noteCount * 1000L / chart.lengthMs));

        if (listener != null) listener.onProgress(100, noteCount, "Done");
        return chart;
    }
}
