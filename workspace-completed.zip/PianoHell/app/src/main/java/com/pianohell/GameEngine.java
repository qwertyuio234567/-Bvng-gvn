package com.pianohell;

import android.os.SystemClock;

/**
 * GameEngine — the fixed-timestep simulation: input, judgment, holds, scoring, health.
 *
 * <h3>Fixed timestep, decoupled from render FPS</h3>
 * {@link #advance} is called once per rendered frame, but it does NOT use the frame's delta time as
 * its timestep. It accumulates real elapsed nanoseconds and runs {@link #STEP_NS}-sized steps
 * (200 Hz) until the accumulator is drained (with a catch-up cap so a stalled frame cannot spiral).
 * Two reasons this matters for a rhythm game:
 * <ul>
 *   <li>Judgment windows are in milliseconds, so the simulation must not care whether the device
 *       rendered the last frame in 8 ms or in 33 ms.</li>
 *   <li>Note scroll positions are a pure function of song time, so a dropped frame changes nothing
 *       about where tiles are — the next frame simply draws the correct position.</li>
 * </ul>
 * Song time itself is anchored to the AUDIO clock when audio is running (sample-accurate) and
 * falls back to the steady-clock accumulator otherwise. That is what keeps tiles glued to the
 * samples instead of drifting a few ms per minute.
 *
 * <h3>Polyphonic input</h3>
 * Touch events arrive on the UI thread into {@link NotePool}'s ring buffer and are drained here.
 * Every {@code pointerId} is tracked independently, so 5+ simultaneous holds across lanes work
 * (MotionEvent pointer tracking, never single-touch: see {@link GameView#onTouchEvent}).
 *
 * <h3>Hot-loop discipline</h3>
 * Nothing in this class allocates after construction: no iterators, no boxing, no collections.
 * The per-frame ranges come from binary search in {@link ChartData}, and the per-lane cursors mean
 * an input only ever scans a handful of candidates even in a 5M-note chart.
 */
public final class GameEngine {

    /** 200 Hz simulation step. Input is timestamped anyway, so this is mostly about hold release. */
    public static final long STEP_NS = 5_000_000L;
    /** Never simulate more than this many steps in one frame (0.25 s of catch-up). */
    private static final int MAX_CATCHUP_STEPS = 50;

    public static final int STATE_READY = 0, STATE_PLAYING = 1, STATE_PAUSED = 2,
            STATE_FAILED = 3, STATE_FINISHED = 4;

    public interface Listener {
        void onRunFinished(RunResult result);
        void onRunFailed(RunResult result, int laneThatKilledYou);
    }

    // ------------------------------------------------------------------
    // Results
    // ------------------------------------------------------------------
    public static final class RunResult {
        public String title = "";
        public int perfect, good, miss, partial;
        public int maxCombo, combo;
        public long score;
        public float accuracy;          // 0..1
        public long playedMs;
        public boolean failed;
        public String mappingDescription = "";

        public String pretty() {
            return String.format(java.util.Locale.US,
                    "%s\nPerfect %d · Good %d · Partial %d · Miss %d\nMax combo %d · Score %,d · Acc %.1f%%\n%s",
                    title, perfect, good, partial, miss, maxCombo, score, accuracy * 100f, mappingDescription);
        }
    }

    // ------------------------------------------------------------------
    // State
    // ------------------------------------------------------------------
    private final ChartData chart;
    private final GameConfig cfg;
    private final NotePool pool;
    /**
     * Attached asynchronously (see GameActivity.startAudioAsync), hence volatile. Null simply means
     * "play silently": every use site is already null-checked, which is what lets the chart start
     * before the audio device has finished coming up.
     */
    private volatile AudioEngine audio;
    private final MidiMapper mapper;
    private Listener listener;

    private long accumulatorNs = 0;
    private long lastFrameNs = 0;
    private double songTimeMs = 0;
    private int state = STATE_READY;

    /**
     * Constant offset between the audio clock and song time. The audio stream's frame counter starts
     * at zero when the run starts, but song time starts at {@code -countInMs} (tiles must scroll in
     * from the top before the first note reaches the hit line). Without a bias the first sync would
     * slam song time to 0 and teleport every tile, so the bias is MEASURED (songTime - audioMs) the
     * first time the audio clock is trustworthy, and re-measured after every pause/resume.
     */
    private double audioBiasMs = 0;
    private boolean audioAnchored = false;
    private int clockReanchors = 0;

    /**
     * Miss scanning. Notes are sorted by time, so ONE global sweep cursor is enough: everything
     * behind it is already resolved, everything ahead of it is either in the future or in flight.
     * This is what keeps the per-step cost O(1) amortised instead of re-deriving per-lane state
     * (an earlier version kept 12 lane cursors and had to re-scan lanes to find "the next note in
     * this lane" — the trap that makes black-MIDI charts stutter).
     */
    private int expireCursor = 0;
    /** -1 == no finger down in this lane, else the pointerId holding it. */
    private final int[] lanePointer = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };
    /** Chart index of the hold currently being played in this lane, or -1. */
    private final int[] laneHoldIndex = { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };


    // scoring
    private int perfectCount, goodCount, missCount, partialCount;
    private int combo, maxCombo;
    private long score;
    private float health = 1f;
    private long runStartWallMs;
    private int laneThatKilledYou = -1;

    // input drain scratch (preallocated: the drain must not allocate)
    private final NotePool.TouchEvent[] eventScratch = new NotePool.TouchEvent[256];

    // visuals the renderer reads
    public float laneFlash[] = new float[GameConfig.LANES];   // 1 -> 0 after a hit (lane glow)
    public long lastJudgmentMs = 0;
    public int lastJudgmentKind = 0;                          // 0 perfect 1 good 2 partial 3 miss
    public int lastJudgmentLane = 0;
    public int[] judgmentPulseLane = new int[16];
    public int[] judgmentPulseKind = new int[16];
    public long[] judgmentPulseTime = new long[16];
    public int judgmentPulseHead = 0, judgmentPulseCount = 0;

    public GameEngine(ChartData chart, GameConfig cfg, NotePool pool, AudioEngine audio, MidiMapper mapper) {
        this.chart = chart;
        this.cfg = cfg;
        this.pool = pool;
        this.audio = audio;
        this.mapper = mapper;
        for (int i = 0; i < eventScratch.length; i++) eventScratch[i] = new NotePool.TouchEvent();
    }

    public void setListener(Listener l) { this.listener = l; }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    /** Start (or restart) a run. Resets all per-run state without touching the chart arrays' data. */
    public void start() {
        chart.resetJudgment();
        expireCursor = 0;
        for (int i = 0; i < GameConfig.LANES; i++) {
            lanePointer[i] = -1;
            laneHoldIndex[i] = -1;
            laneFlash[i] = 0f;
        }
        accumulatorNs = 0;
        lastFrameNs = System.nanoTime();
        songTimeMs = -countInMs();
        audioBiasMs = 0;
        audioAnchored = false;
        clockReanchors = 0;
        perfectCount = goodCount = missCount = partialCount = 0;
        combo = maxCombo = 0;
        score = 0;
        health = 1f;
        laneThatKilledYou = -1;
        judgmentPulseCount = 0;
        pool.clearParticles();
        pool.clearEvents();
        state = STATE_PLAYING;
        runStartWallMs = SystemClock.uptimeMillis();
        if (audio != null) audio.onRunStart(mapper);
    }

    /** Count-in: the first tiles must scroll in, so song time starts negative. */
    private int countInMs() {
        return Math.min(cfg.scrollMs, 2000);
    }

    public void pause() {
        if (state == STATE_PLAYING) {
            state = STATE_PAUSED;
            if (audio != null) audio.onRunPause();
        }
    }

    public void resume() {
        if (state == STATE_PAUSED) {
            state = STATE_PLAYING;
            lastFrameNs = System.nanoTime();          // do not eat the paused wall time
            audioAnchored = false;                    // the audio clock was reset on resume: re-learn

            if (audio != null) audio.onRunResume();
        }
    }

    public int getState() { return state; }

    /** True while a finger is holding this lane (the renderer lights the key). */
    public boolean isLaneDown(int lane) { return lane >= 0 && lane < GameConfig.LANES && lanePointer[lane] != -1; }

    /**
     * Hand over the audio engine once it exists. Called on the UI thread, possibly after the run has
     * already started, so the audio clock offset is re-learned (audioAnchored = false) instead of
     * being assumed — otherwise song time would snap to the freshly-zeroed audio clock and every
     * tile would teleport.
     */
    public void setAudio(AudioEngine a) {
        this.audio = a;
        if (a == null) return;
        audioAnchored = false;
        a.onRunStart(mapper);          // lane -> pitch table for this chart, and reset the clock
    }

    public AudioEngine getAudio() { return audio; }

    /** One-line audio status for the HUD. */
    public String audioStatus() {
        AudioEngine a = audio;
        return a == null ? "audio: starting…" : a.describe();
    }

    /** How many times song time had to be re-anchored to the audio clock (a HUD diagnostic). */
    public int getClockReanchors() { return clockReanchors; }

    /** The render thread draws straight out of this pool; exposed so the view can share it. */
    public NotePool getPool() { return pool; }
    public double getSongTimeMs() { return songTimeMs; }
    public ChartData getChart() { return chart; }
    public float getHealth() { return health; }
    public int getCombo() { return combo; }
    public long getScore() { return score; }
    public int getPerfect() { return perfectCount; }
    public int getGood() { return goodCount; }
    public int getMiss() { return missCount; }
    public int getPartial() { return partialCount; }

    /** 0..1 progress through the chart (used by the HUD bar). */
    public float progress() {
        return chart.lengthMs <= 0 ? 0f : (float) Math.max(0, Math.min(1, songTimeMs / chart.lengthMs));
    }

    // ------------------------------------------------------------------
    // Per-frame entry point (called from the render thread)
    // ------------------------------------------------------------------

    /**
     * Advance the simulation to "now". Returns the song time in ms that the renderer should draw.
     * The catch-up cap prevents the spiral of death: if the device hiccuped for half a second we
     * simulate at most {@link #MAX_CATCHUP_STEPS} steps and let song time jump to the audio clock,
     * which is the ground truth anyway.
     */
    public double advance() {
        long now = System.nanoTime();
        if (state != STATE_PLAYING) {
            lastFrameNs = now;
            return songTimeMs;
        }
        long frameDelta = now - lastFrameNs;
        lastFrameNs = now;
        if (frameDelta > 250_000_000L) frameDelta = 250_000_000L;   // clamp: never simulate >0.25 s of stale input
        accumulatorNs += frameDelta;

        int steps = 0;
        while (accumulatorNs >= STEP_NS && steps < MAX_CATCHUP_STEPS) {
            step(STEP_NS);
            accumulatorNs -= STEP_NS;
            steps++;
        }
        if (steps == MAX_CATCHUP_STEPS) accumulatorNs = 0;

        syncWithAudioClock();
        updateVisuals();
        return songTimeMs;
    }

    private void step(long stepNs) {
        songTimeMs += stepNs / 1_000_000.0;
        drainInput();
        progressHolds();
        expireMissedNotes();
        finishCheck();
    }

    /**
     * Drag song time onto the audio clock. The engine's own accumulator is smooth but its absolute
     * offset can drift; the audio device position is what the player actually hears, so we nudge
     * (never snap more than a few ms at a time) toward it. This is the mechanism behind the spec's
     * "audio/input timing doesn't drift from note scroll speed".
     */
    private void syncWithAudioClock() {
        if (audio == null || !audio.isReady()) return;
        long audioMs = audio.playbackPositionMs();
        if (audioMs < 0) return;

        if (!audioAnchored) {
            // First trustworthy reading of this run: learn the offset instead of trusting it to be 0.
            audioBiasMs = songTimeMs - audioMs;
            audioAnchored = true;
            clockReanchors++;
            return;
        }
        double target = audioMs + audioBiasMs;
        double err = target - songTimeMs;
        if (Math.abs(err) > 90) {
            songTimeMs = target;                       // device restart / big hiccup: re-anchor hard
            clockReanchors++;
        } else {
            songTimeMs += err * 0.02;                  // otherwise creep: 2% of the error per frame
        }
    }

    // ------------------------------------------------------------------
    // Input
    // ------------------------------------------------------------------

    private void drainInput() {
        int n = pool.drainEvents(eventScratch.length, eventScratch);
        for (int i = 0; i < n; i++) {
            NotePool.TouchEvent e = eventScratch[i];
            // Convert the event's wall-clock timestamp into song time so a 16 ms input latency does
            // not silently become 16 ms of judgment error on top of the touch hardware latency.
            long lag = SystemClock.uptimeMillis() - e.timeMs;
            // audioOffsetMs is the player's calibration: it shifts the judgment clock to compensate
            // for the device's touch-to-sound latency, so "PERFECT" matches what the player HEARD.
            double eventSongMs = songTimeMs - lag + cfg.audioOffsetMs;
            int lane = laneAtX(e.x);
            switch (e.type) {
                case NotePool.TouchEvent.DOWN:
                    onDown(lane, e.pointerId, e.x, e.y, eventSongMs);
                    break;
                case NotePool.TouchEvent.MOVE:
                    break;                              // slides never re-trigger: tiles are judged on down
                case NotePool.TouchEvent.UP:
                case NotePool.TouchEvent.CANCEL:
                    onUp(e.pointerId, eventSongMs, e.type == NotePool.TouchEvent.CANCEL);
                    break;
            }
        }
    }

    private int laneAtX(float x) {
        int l = (int) (x * GameConfig.LANES / GameView.lastWidthPx());
        if (l < 0) l = 0;
        if (l >= GameConfig.LANES) l = GameConfig.LANES - 1;
        return l;
    }

    private void onDown(int lane, int pointerId, float x, float y, double eventSongMs) {
        lanePointer[lane] = pointerId;

        int idx = findHittable(lane, eventSongMs);
        if (idx == ChartData.NO_INDEX) {
            // Nothing in the window. In Piano-Tiles mode a stray tap is not punished; it just does
            // not count. (Punishing it feels broken on multi-touch phones where thumbs rest.)
            return;
        }
        double delta = eventSongMs - chart.startMs[idx];
        if (Math.abs(delta) > cfg.goodMs) return;

        if (chart.kind[idx] == ChartData.KIND_HOLD && chart.durationMs[idx] >= GameConfig.MIN_HOLD_MS) {
            chart.jud[idx] = ChartData.JUD_HOLDING;      // head judged now, tail judged on release
            laneHoldIndex[lane] = idx;
            judge(idx, lane, Math.abs(delta) <= cfg.perfectMs ? 0 : 1, true);
        } else {
            chart.jud[idx] = ChartData.JUD_DONE;
            judge(idx, lane, Math.abs(delta) <= cfg.perfectMs ? 0 : 1, false);
        }
        if (audio != null) audio.noteOn(lane, 1f);
        // Sparks are spawned by the renderer (it owns the geometry + the lane colors); the engine
        // only publishes the lane flash level, which keeps the simulation thread free of drawing data.
    }

    private void onUp(int pointerId, double eventSongMs, boolean cancelled) {
        // A finger can have been holding exactly one lane (the lane where it went down).
        for (int lane = 0; lane < GameConfig.LANES; lane++) {
            if (lanePointer[lane] != pointerId) continue;
            lanePointer[lane] = -1;
            int idx = laneHoldIndex[lane];
            if (idx < 0) continue;
            laneHoldIndex[lane] = -1;

            long tailMs = chart.startMs[idx] + chart.durationMs[idx];
            double remain = tailMs - eventSongMs;         // >0 == released early
            int kind;
            if (cancelled && remain > cfg.goodMs) {
                kind = 3;                                // cancelled with the tile still running: MISS
            } else if (remain <= cfg.holdReleaseToleranceMs) {
                kind = 0;                                // held to the tail (inside tolerance)
            } else if (remain <= cfg.goodMs + cfg.holdReleaseToleranceMs) {
                kind = 1;                                // early, but close: GOOD-ish for a hold
            } else {
                kind = 2;                                // let go way too soon: PARTIAL
            }
            chart.jud[idx] = (kind == 2 || kind == 3) ? ChartData.JUD_MISSED : ChartData.JUD_DONE;
            judge(idx, lane, kind, true);
        }
    }

    /**
     * Find the best hittable note in a lane at {@code t}. Two candidates matter: the earliest
     * unjudged note at/after t - goodMs, and the previous one (which may still be inside the
     * window). Whichever timing error is smaller wins. Scanning is bounded by time, not by note
     * count, so a black-MIDI stack in the same lane cannot stall the input path.
     */
    private int findHittable(int lane, double t) {
        // Binary search straight to the start of the window: the cost of a hit is O(log n + window)
        // and never depends on how many notes are in the chart or in the lane.
        int i = chart.lowerBound((long) (t - cfg.goodMs));
        int best = ChartData.NO_INDEX;
        double bestAbs = Double.MAX_VALUE;
        long windowStart = (long) (t - cfg.goodMs);
        int guard = 0;
        while (i < chart.count && chart.startMs[i] <= t + cfg.goodMs && guard++ < 4096) {
            if (chart.lane[i] == lane && chart.jud[i] == ChartData.JUD_NONE && chart.startMs[i] >= windowStart) {
                double abs = Math.abs(chart.startMs[i] - t);
                if (abs < bestAbs) { bestAbs = abs; best = i; }
            }
            i++;
        }
        return best;
    }

    // ------------------------------------------------------------------
    // Holds + misses
    // ------------------------------------------------------------------

    /** Complete holds whose tail has passed while the finger stayed down. */
    private void progressHolds() {
        long now = (long) (songTimeMs + cfg.audioOffsetMs);
        for (int lane = 0; lane < GameConfig.LANES; lane++) {
            int idx = laneHoldIndex[lane];
            if (idx < 0) continue;
            int ptr = lanePointer[lane];
            long tail = chart.startMs[idx] + chart.durationMs[idx];
            if (ptr < 0) continue;                        // released: handled in onUp
            if (now >= tail - cfg.holdReleaseToleranceMs) {
                chart.jud[idx] = ChartData.JUD_DONE;      // held to the end: success (already scored at head)
                laneHoldIndex[lane] = -1;
                laneFlash[lane] = 1f;
            }
        }
    }

    /**
     * Notes that scrolled past their window without being touched become MISSes.
     *
     * <p>Because the chart is sorted by start time, this is a single forward sweep: once a note is
     * older than {@code goodMs} it can never be hit again, so we resolve it and move on. The sweep
     * stops at the first note that is still in play. Amortised cost is O(1) per note per run —
     * a 5,000,000-note chart costs the same per frame as a 500-note one.
     */
    private void expireMissedNotes() {
        long now = (long) (songTimeMs + cfg.audioOffsetMs);
        int i = expireCursor;
        final int n = chart.count;
        while (i < n) {
            if (chart.startMs[i] + cfg.goodMs >= now) break;      // this and everything after is still live
            byte state = chart.jud[i];
            if (state == ChartData.JUD_NONE) {
                chart.jud[i] = ChartData.JUD_MISSED;
                judge(i, chart.lane[i], 3, false);
            } else if (state == ChartData.JUD_HOLDING) {
                // A hold that is still marked HOLDING after its tail has left the window means the
                // finger disappeared without an UP event (a cancel/drop). progressHolds() completes
                // holds that were actually held, so anything left here is a miss.
                long tail = chart.startMs[i] + chart.durationMs[i] + cfg.holdReleaseToleranceMs;
                if (tail < now) {
                    chart.jud[i] = ChartData.JUD_MISSED;
                    laneHoldIndex[chart.lane[i]] = -1;
                    judge(i, chart.lane[i], 3, true);
                } else {
                    break;                                            // still being held: stop the sweep
                }
            }
            expireCursor = ++i;
        }
    }

    // ------------------------------------------------------------------
    // Judgment + scoring
    // ------------------------------------------------------------------

    /**
     * @param kind 0 perfect, 1 good, 2 partial (hold released early), 3 miss
     */
    private void judge(int chartIndex, int lane, int kind, boolean holdTail) {
        switch (kind) {
            case 0:
                perfectCount++; combo++; score += 1000 + Math.min(combo, 200) * 5;
                health = Math.min(1f, health + 0.01f);
                break;
            case 1:
                goodCount++; combo++; score += 500;
                health = Math.min(1f, health + 0.005f);
                break;
            case 2:
                partialCount++; combo = 0; score += 120;
                health -= 0.06f;
                break;
            default:
                missCount++; combo = 0;
                health -= 0.12f;
                break;
        }
        if (combo > maxCombo) maxCombo = combo;
        laneFlash[lane] = 1f;

        // Publish the judgment so the renderer can pop text without any allocation.
        int head = judgmentPulseHead;
        judgmentPulseLane[head] = lane;
        judgmentPulseKind[head] = kind;
        judgmentPulseTime[head] = SystemClock.uptimeMillis();
        judgmentPulseHead = (head + 1) & 15;
        if (judgmentPulseCount < 16) judgmentPulseCount++;
        lastJudgmentMs = SystemClock.uptimeMillis();
        lastJudgmentKind = kind;
        lastJudgmentLane = lane;

        // Audio: a real piano voice per hit is the whole point of the native engine.
        if (audio != null && (!holdTail || kind <= 1)) {
            audio.noteOn(mapper.lanePlaybackPitch(lane), kind == 3 ? 0.35f : 1f);
        }

        // Sudden death: health is deplete-on-miss like Piano Tiles — one miss and the run is over.
        if (cfg.suddenDeath && health <= 0f) {
            health = 0f;
            laneThatKilledYou = lane;
            state = STATE_FAILED;
            if (audio != null) audio.onRunPause();
            if (listener != null) listener.onRunFailed(buildResult(true), lane);
        }
    }

    private void finishCheck() {
        if (state != STATE_PLAYING) return;
        if (songTimeMs > chart.lengthMs + 1500) {
            state = STATE_FINISHED;
            saveResult(buildResult(false));
            if (listener != null) listener.onRunFinished(buildResult(false));
        }
    }

    private RunResult buildResult(boolean failed) {
        RunResult r = new RunResult();
        r.title = chart.title;
        r.perfect = perfectCount; r.good = goodCount; r.miss = missCount; r.partial = partialCount;
        r.combo = combo; r.maxCombo = maxCombo; r.score = score;
        int total = perfectCount + goodCount + partialCount + missCount;
        r.accuracy = total == 0 ? 0f : (perfectCount + goodCount * 0.6f + partialCount * 0.25f) / total;
        r.playedMs = SystemClock.uptimeMillis() - runStartWallMs;
        r.failed = failed;
        r.mappingDescription = mapper != null ? mapper.describe() : "";
        return r;
    }

    /** Persist a personal best for this title (keyed by title, which is stable for presets). */
    private void saveResult(RunResult r) {
        if (r.score <= 0) return;
        try {
            android.content.SharedPreferences p = ChartLoader.appContext()
                    .getSharedPreferences("pianohell_scores", android.content.Context.MODE_PRIVATE);
            long best = p.getLong("best_" + r.title, 0);
            if (r.score > best) p.edit().putLong("best_" + r.title, r.score).putFloat("acc_" + r.title, r.accuracy).apply();
        } catch (Throwable ignored) { }
    }

    public static long bestScore(String title) {
        try {
            return ChartLoader.appContext().getSharedPreferences("pianohell_scores", android.content.Context.MODE_PRIVATE)
                    .getLong("best_" + title, 0);
        } catch (Throwable t) { return 0; }
    }

    // ------------------------------------------------------------------
    // Visual bookkeeping (cheap, runs once per frame)
    // ------------------------------------------------------------------

    private void updateVisuals() {
        float decay = 1f / 8f;                        // lane flash lasts ~8 steps
        for (int i = 0; i < GameConfig.LANES; i++) if (laneFlash[i] > 0) laneFlash[i] = Math.max(0, laneFlash[i] - decay);
        pool.compactParticles(1f / 60f);
    }
}
