package com.pianohell;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * PresetAdapter — RecyclerView adapter for the preset catalogue.
 *
 * <p>RecyclerView (not a ListView, not a LinearLayout of inflates) because preset rows are recycled
 * as the list scrolls; each row also shows the personal best from SharedPreferences, read once per
 * bind rather than kept in memory.
 */
public final class PresetAdapter extends RecyclerView.Adapter<PresetAdapter.VH> {

    public interface OnPresetClick { void onClick(Preset preset); }

    private final OnPresetClick click;

    public PresetAdapter(OnPresetClick click) { this.click = click; }

    static final class VH extends RecyclerView.ViewHolder {
        final PresetThemeSwatch swatch;
        final TextView title, subtitle, rating;
        VH(View v) {
            super(v);
            swatch = v.findViewById(R.id.swatch);
            title = v.findViewById(R.id.title);
            subtitle = v.findViewById(R.id.subtitle);
            rating = v.findViewById(R.id.rating);
        }
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_preset, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int position) {
        Preset p = Preset.ALL[position];
        h.title.setText(p.title);
        h.rating.setText(String.valueOf(p.difficulty));
        h.swatch.setTheme(p.themeIndex);

        // Build detail line: BPM · Creator · notes · density [· audio badge] [· best score]
        String detail = p.detailLine();
        if (p.isAudioDetected()) {
            detail += " · 🎵 pitch-detected";
        }
        long best = GameEngine.bestScore(p.title);
        if (best > 0) {
            detail += " · best " + String.format(java.util.Locale.US, "%,d", best);
        }
        h.subtitle.setText(detail);

        h.itemView.setOnClickListener(v -> click.onClick(p));
    }

    @Override public int getItemCount() { return Preset.ALL.length; }
}
