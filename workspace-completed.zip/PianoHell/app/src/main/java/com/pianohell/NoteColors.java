package com.pianohell;

/**
 * NoteColors — the color palette the renderer resolves into raw ARGB ints ONCE, at load time.
 *
 * <p>Color IDs stored in {@link ChartData#colorId} are tiny indices, never ARGB ints:
 * <pre>
 *   0 .. 11  : lane theme color            (default; "each lane gets its own accent")
 *   12 .. 27  : MIDI channel 0..15         (multi-color black-MIDI chaos)
 *   28 .. 31  : velocity buckets: ppp / mf / ff / ffff
 * </pre>
 * Because the render thread only ever does {@code palette[colorId[i]]}, there is no per-note
 * string/hex parsing, no allocation, and the palette can be swapped live (theme change) without
 * touching the chart arrays at all.
 */
public final class NoteColors {

    public static final int CHANNEL_BASE = 12;   // 12..27
    public static final int VELOCITY_BASE = 28;  // 28..31
    public static final int PALETTE_SIZE = 32;

    /** 12 hue-rotated accents chosen to stay distinguishable on a dark background. */
    private static final int[] LANE_HUES = {
            0xFF2D6F, // 0  C   pink/red
            0xFF7A18, // 1  C#  orange
            0xFFC61A, // 2  D   amber
            0xC6F32A, // 3  D#  lime
            0x3BE07A, // 4  E   green
            0x16D9B4, // 5  F   teal
            0x22D3EE, // 6  F#  cyan
            0x3B9CFF, // 7  G   blue
            0x6C6CFF, // 8  G#  indigo
            0xA855F7, // 9  A   violet
            0xEC4BD0, // 10 A#  magenta
            0xFF4D79, // 11 B   rose
    };

    /** Channel palette: 16 hues spread evenly (golden-angle spacing) so 16 channels stay distinct. */
    private static final int[] CHANNEL_COLORS = new int[16];
    /** Velocity buckets. */
    private static final int[] VELOCITY_COLORS = { 0xFF6E8BFF, 0xFF40E0D0, 0xFFFFC400, 0xFFFF3B30 };

    static {
        for (int i = 0; i < 16; i++) {
            float hue = (i * 137.508f) % 360f;                      // golden angle: maximal spread
            CHANNEL_COLORS[i] = hsl(hue, 0.85f, 0.58f);
        }
    }

    /** Theme variants (index used by {@link ChartData#themeIndex} and the preset swatch). */
    public static final String[] THEME_NAMES = { "Neon", "Ice", "Hellfire", "Mono", "Rainbow" };

    private final int[] palette = new int[PALETTE_SIZE];

    public NoteColors(int themeIndex) {
        build(themeIndex);
    }

    public void build(int themeIndex) {
        switch (themeIndex) {
            case 1: // Ice — cyan/white family, low saturation drift
                for (int i = 0; i < 12; i++) palette[i] = hsl(180f + i * 6f, 0.55f, 0.55f + (i % 4) * 0.07f);
                break;
            case 2: // Hellfire — red through yellow
                for (int i = 0; i < 12; i++) palette[i] = hsl(i * 6f, 0.95f, 0.50f);
                break;
            case 3: // Mono — grayscale ladder, useful to judge pure timing
                for (int i = 0; i < 12; i++) {
                    int v = 110 + i * 11;                              // 110..231
                    palette[i] = 0xFF000000 | (v << 16) | (v << 8) | v;
                }
                break;
            case 4: // Rainbow — full spectrum across the 12 lanes
                for (int i = 0; i < 12; i++) palette[i] = hsl(i * 30f, 0.9f, 0.60f);
                break;
            default: // Neon
                System.arraycopy(LANE_HUES, 0, palette, 0, 12);
        }
        System.arraycopy(CHANNEL_COLORS, 0, palette, CHANNEL_BASE, 16);
        System.arraycopy(VELOCITY_COLORS, 0, palette, VELOCITY_BASE, 4);
    }

    public int[] raw() { return palette; }

    /** Palette lookup used by the render loop (branch-free, cache hot). */
    public int color(int colorId) {
        return palette[colorId & 0x1F];
    }

    public int laneColor(int lane) { return palette[lane % 12]; }

    /** Body color of a tile: theme color darkened, so the bright core reads as "the note". */
    public int laneBodyColor(int lane) {
        return darken(palette[lane % 12], 0.45f);
    }

    public int channelColor(int channel) { return palette[CHANNEL_BASE + (channel & 15)]; }

    public int velocityColor(int velocity) {
        int b = velocity < 40 ? 0 : velocity < 80 ? 1 : velocity < 110 ? 2 : 3;
        return palette[VELOCITY_BASE + b];
    }

    // ------------------------- helpers -------------------------

    public static int darken(int c, float f) {
        int a = (c >>> 24), r = (int) (((c >> 16) & 0xFF) * f), g = (int) (((c >> 8) & 0xFF) * f), b = (int) ((c & 0xFF) * f);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int lerp(int c1, int c2, float t) {
        int a = (int) ((c1 >>> 24) + (((c2 >>> 24) - (c1 >>> 24)) * t));
        int r = (int) (((c1 >> 16) & 0xFF) + ((((c2 >> 16) & 0xFF) - ((c1 >> 16) & 0xFF)) * t));
        int g = (int) (((c1 >> 8) & 0xFF) + ((((c2 >> 8) & 0xFF) - ((c1 >> 8) & 0xFF)) * t));
        int b = (int) ((c1 & 0xFF) + (((c2 & 0xFF) - (c1 & 0xFF)) * t));
        return (a << 24) | (r << 16) | (g << 8) | b;
    }

    public static int hsl(float h, float s, float l) {
        h = ((h % 360f) + 360f) % 360f;
        float c = (1f - Math.abs(2f * l - 1f)) * s;
        float x = c * (1f - Math.abs(((h / 60f) % 2f) - 1f));
        float m = l - c / 2f;
        float r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        int ri = Math.round((r + m) * 255f), gi = Math.round((g + m) * 255f), bi = Math.round((b + m) * 255f);
        return 0xFF000000 | (ri << 16) | (gi << 8) | bi;
    }

    /** Blend two ARGB colors with 8-bit alpha (used for the tile fill over the background). */
    public static int blend(int dst, int src, int alpha) {
        int ia = 255 - alpha;
        int r = (((src >> 16) & 0xFF) * alpha + ((dst >> 16) & 0xFF) * ia) >> 8;
        int g = (((src >> 8) & 0xFF) * alpha + ((dst >> 8) & 0xFF) * ia) >> 8;
        int b = ((src & 0xFF) * alpha + (dst & 0xFF) * ia) >> 8;
        return (dst & 0xFF000000) | (r << 16) | (g << 8) | b;
    }
}
