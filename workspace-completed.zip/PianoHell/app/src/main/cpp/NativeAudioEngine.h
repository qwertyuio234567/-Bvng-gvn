// PianoHell — native audio engine.
// Oboe (AAudio on API 26+, OpenSL ES fallback below) + a fixed voice pool mixer.
// See NativeAudioEngine.cpp for the reasoning; this header is the shape of it.

#pragma once

#include <atomic>
#include <cstdint>

#include <oboe/Oboe.h>

namespace pianohell {

// ---------------------------------------------------------------- events
// A note event small enough to move through a lock-free ring without tearing:
// one 64-bit word. That matters because the producer is a Java/JNI call on the
// UI thread and the consumer is the AAudio callback thread, which must never
// block, lock, or allocate.
struct NoteEvent {
    int32_t pitch : 8;      // 0..127
    int32_t velocity : 8;   // 0..127
    int32_t kind : 2;       // 0 = note on, 1 = all notes off, 2 = volume
    int32_t reserved : 14;
    int32_t packed2;

    static NoteEvent noteOn(int pitch, int velocity) {
        NoteEvent e{}; e.pitch = pitch; e.velocity = velocity; e.kind = 0; return e;
    }
};

// Lock-free single-producer / single-consumer ring buffer.
template <typename T, size_t CapacityPow2>
class SpscRing {
public:
    bool push(const T& v) {
        const uint32_t w = write_.load(std::memory_order_relaxed);
        const uint32_t next = (w + 1) & (CapacityPow2 - 1);
        if (next == read_.load(std::memory_order_acquire)) return false;  // full: drop, never block
        buf_[w] = v;
        write_.store(next, std::memory_order_release);
        return true;
    }
    bool pop(T& out) {
        const uint32_t r = read_.load(std::memory_order_relaxed);
        if (r == write_.load(std::memory_order_acquire)) return false;   // empty
        out = buf_[r];
        read_.store((r + 1) & (CapacityPow2 - 1), std::memory_order_release);
        return true;
    }
private:
    T buf_[CapacityPow2]{};
    std::atomic<uint32_t> write_{0};
    std::atomic<uint32_t> read_{0};
};

// ---------------------------------------------------------------- voice
// One pre-rendered sample per lane + a per-voice ADSR applied at render time.
// Samples are looped for the sustain portion so a 20-second hold costs the same
// memory as a 1-second one.
struct Voice {
    bool active = false;
    int lane = 0;                 // which sample
    uint32_t pos = 0;             // frame index into the sample
    uint32_t loopStart = 0;
    uint32_t loopEnd = 0;
    uint32_t releaseAt = 0;       // frame index where the release began (0 = still held)
    float gain = 0.f;             // velocity-scaled
    float env = 0.f;              // current envelope value
    float ratio = 1.f;            // playback rate: 2^(semitones/12), for pitch-shifting the sample
    float pan = 0.5f;             // lane -> stereo position
    uint64_t startedAt = 0;       // sample clock, for voice stealing
};

class NativeAudioEngine : public oboe::AudioStreamDataCallback,
                          public oboe::AudioStreamErrorCallback {
public:
    static constexpr int kVoices = 96;          // black-MIDI polyphony without dropouts
    static constexpr int kLanes = 12;
    static constexpr int kEventsRing = 4096;    // power of two

    NativeAudioEngine();
    ~NativeAudioEngine() override;

    bool start();
    void stop();
    bool isRunning() const { return running_.load(std::memory_order_acquire); }
    /** Running, stream alive, and no error reported. Used by the Java layer for the HUD. */
    bool isHealthy() const;
    int getLastError() const { return lastError_.load(std::memory_order_relaxed); }

    // Called from Java (any thread) — must be wait-free.
    void noteOn(int midiPitch, float velocity);
    void noteOff(int midiPitch);
    void allNotesOff();
    void setLanePitch(int lane, int midiPitch);
    void setMasterVolume(float v);

    // Replaces the lane's instrument with an externally supplied sample
    // (e.g. a WAV/SoundFont render loaded from assets). data is copied.
    void setSample(int lane, const float* data, int length, int rootPitch);

    /** Frames rendered since the run started — the game uses this as the audio clock. */
    int64_t playbackFrames() const { return framesPlayed_.load(std::memory_order_relaxed); }
    int64_t playbackPositionMs() const;
    /** Zero the audio clock. The game calls this at the start of every run. */
    void resetClock() { framesPlayed_.store(0, std::memory_order_relaxed); }
    int getSampleRate() const { return sampleRate_; }
    int getActiveVoices() const { return activeVoices_.load(std::memory_order_relaxed); }
    int getXruns() const { return xruns_.load(std::memory_order_relaxed); }

    // oboe::AudioStreamDataCallback
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream* stream, void* audioData, int32_t numFrames) override;
    // oboe::AudioStreamErrorCallback
    bool onError(oboe::AudioStream* stream, oboe::Result error) override;

private:
    void renderSamples(int lane);            // pre-render the 12 key samples at init
    void startVoice(int pitch, int velocity);
    void releaseVoicesForPitch(int pitch);
    Voice* allocateVoice();

    std::shared_ptr<oboe::AudioStream> stream_;
    std::atomic<bool> running_{false};
    /**
     * True from the moment openStream() is called until requestStart() has returned. Oboe may
     * dispatch error callbacks on its own thread during that window (and after), so every use of
     * stream_ is guarded by it: touching stream_ from two threads is how you get a use-after-free
     * crash on launch.
     */
    std::atomic<bool> opening_{false};

    // pre-rendered instrument: one mono sample per lane + its natural length
    float* samples_[kLanes] = {nullptr};
    int sampleLen_[kLanes] = {0};
    int sampleRoot_[kLanes] = {48};
    int sampleRate_ = 48000;

    Voice voices_[kVoices];
    SpscRing<NoteEvent, kEventsRing> events_;

    std::atomic<int64_t> framesPlayed_{0};
    std::atomic<int> activeVoices_{0};
    std::atomic<int> xruns_{0};
    std::atomic<int> lastError_{0};      // last oboe::Result an error callback reported (0 == OK)
    std::atomic<float> masterVolume_{0.8f};

    // lane -> midi pitch the chart mapped to that lane (set per run by the Java layer)
    int lanePitch_[kLanes];

    uint64_t voiceClock_ = 0;
};

} // namespace pianohell
