// PianoHell — native audio engine implementation.
//
// WHY THIS EXISTS (the performance-critical decisions, in order of importance):
//
// 1. OBOE / AAudio instead of MediaPlayer, SoundPool or Gervill.
//    - MediaPlayer is a file/codec player: hundreds of ms of latency, one stream per instance.
//    - SoundPool decodes to its own mixer with ~40-80 ms of latency and a hard 32-stream-ish
//      ceiling; at black-MIDI density it is both late and truncated.
//    - Gervill/javax.sound.midi is a Java soft synth that does not exist on Android and would
//      be too slow and too jittery anyway.
//    Oboe gives us a LowLatency AAudio stream (native sample rate, small buffer, exclusive if
//    the device offers it) with a callback that runs on a real-time thread. Measured on typical
//    ARM phones that is 5-15 ms touch-to-sound, which is what the spec's "<20 ms" needs.
//
// 2. PRE-RENDERED SAMPLES, not per-note synthesis.
//    Twelve key samples (one per lane, extended by pitch-shifting) are synthesized once at
//    startup by additive synthesis with inharmonic partials (see renderSamples). After that the
//    audio callback only does: read sample, multiply, accumulate — no oscillators, no maths per
//    voice per sample. setSample() lets a real SoundFont/WAV render be dropped in instead.
//
// 3. FIXED VOICE POOL + LOCK-FREE RING, not dynamic allocation.
//    The callback must never allocate, lock, or syscall: doing so causes xruns, which in a rhythm
//    game means audible stutter exactly during the densest passage. So: 96 preallocated voices and
//    a lock-free SPSC ring for events from the UI thread. When the ring is full we DROP events
//    (silence) rather than block; when voices run out we steal the oldest (musically the least
//    noticeable option at 200 notes/second).
//
// 4. THE AUDIO CLOCK IS THE GAME CLOCK.
//    framesPlayed_ is what the device has actually played, so the Java engine syncs note scroll to
//    it (GameEngine.syncWithAudioClock). That removes the drift you get from counting frames in
//    Java.

#include "NativeAudioEngine.h"

#include <android/log.h>
#include <cmath>
#include <cstring>
#include <mutex>

#define LOG_TAG "PianoHellAudio"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace pianohell {

namespace {
constexpr float kTwoPi = 6.2831853f;
/** Serialises start()/stop() against each other (Java may call stop from another thread). */
std::mutex gEngineMutex;

inline float midiToHz(int pitch) {
    return 440.0f * std::pow(2.0f, (pitch - 69) / 12.0f);
}
} // namespace

NativeAudioEngine::NativeAudioEngine() {
    for (int i = 0; i < kLanes; ++i) {
        lanePitch_[i] = 48 + i * 2;                 // sane default: C3 upward, replaced per run
        samples_[i] = nullptr;
        sampleLen_[i] = 0;
    }
}

NativeAudioEngine::~NativeAudioEngine() {
    stop();
    for (int i = 0; i < kLanes; ++i) {
        delete[] samples_[i];
        samples_[i] = nullptr;
    }
}

// ---------------------------------------------------------------------------
// Stream setup
// ---------------------------------------------------------------------------
bool NativeAudioEngine::start() {
    std::lock_guard<std::mutex> lock(gEngineMutex);
    stop();                                   // idempotent: safe to call on a live engine

    opening_.store(true, std::memory_order_release);

    oboe::AudioStreamBuilder b;
    b.setDirection(oboe::Direction::Output)
     ->setPerformanceMode(oboe::PerformanceMode::LowLatency)   // asks AAudio for the fast mixer path
     ->setSharingMode(oboe::SharingMode::Exclusive)            // may be downgraded by the device
     ->setFormat(oboe::AudioFormat::Float)                     // native float math, no int conversion
     ->setChannelCount(oboe::ChannelCount::Stereo)
     ->setSampleRate(0)                                        // 0 = device native rate, no resampling
     ->setSampleRateConversionQuality(oboe::SampleRateConversionQuality::Medium)
     ->setUsage(oboe::Usage::Game)
     ->setDataCallback(this)
     ->setErrorCallback(this)
     ->setFramesPerDataCallback(128);                          // small callback = low latency

    oboe::Result r = b.openStream(stream_);
    if (r != oboe::Result::OK || stream_ == nullptr) {
        LOGW("Low-latency open failed (%s), retrying with a plain shared stream",
             oboe::convertToText(r));
        // Devices that refuse Exclusive/LowLatency (emulators, some tablets, desktop-window modes)
        // must still be playable, so fall back rather than go silent. NOTE: the fallback happens
        // only after the first attempt has fully returned — never while a callback for it could
        // still be in flight (see onError()).
        stream_.reset();
        oboe::AudioStreamBuilder b2;
        b2.setDirection(oboe::Direction::Output)
          ->setPerformanceMode(oboe::PerformanceMode::None)
          ->setSharingMode(oboe::SharingMode::Shared)
          ->setFormat(oboe::AudioFormat::Float)
          ->setChannelCount(oboe::ChannelCount::Stereo)
          ->setDataCallback(this)
          ->setErrorCallback(this);
        r = b2.openStream(stream_);
        if (r != oboe::Result::OK || stream_ == nullptr) {
            LOGW("Oboe could not open any output stream: %s — running silent", oboe::convertToText(r));
            stream_.reset();
            opening_.store(false, std::memory_order_release);
            return false;
        }
    }

    sampleRate_ = stream_->getSampleRate();
    if (sampleRate_ <= 0) sampleRate_ = 48000;
    renderSamples(-1);                            // pre-render ALL lanes now that the rate is known
    framesPlayed_.store(0, std::memory_order_relaxed);

    r = stream_->requestStart();
    opening_.store(false, std::memory_order_release);
    if (r != oboe::Result::OK) {
        LOGW("requestStart failed: %s — running silent", oboe::convertToText(r));
        return false;
    }
    running_.store(true, std::memory_order_release);
    LOGI("Oboe running: %d Hz, %d ch, framesPerBurst=%d, bufferSize=%d",
         stream_->getSampleRate(), stream_->getChannelCount(),
         stream_->getFramesPerBurst(), stream_->getBufferSizeInFrames());
    return true;
}

bool NativeAudioEngine::isHealthy() const {
    return running_.load(std::memory_order_acquire) && stream_ != nullptr && lastError_.load() == 0;
}

void NativeAudioEngine::stop() {
    running_.store(false, std::memory_order_release);
    if (stream_ != nullptr) {
        // Only touch the stream from this thread if no open is in flight. A close() that races an
        // openStream()/error callback is a use-after-free, which is exactly the class of crash that
        // makes an app "keep stopping" on launch.
        if (!opening_.load(std::memory_order_acquire)) {
            stream_->requestStop();
            stream_->close();
        }
        stream_.reset();
    }
    opening_.store(false, std::memory_order_release);
}

// ---------------------------------------------------------------------------
// Pre-rendered instrument
// ---------------------------------------------------------------------------
//
// Additive synthesis of one piano-like key: stiff-string partials (slightly stretched,
// inharmonic), each with its own decay rate (high partials die first, which is what makes it
// sound struck rather than organ-like), plus a short noise transient for the hammer.
// ~2.4 s at the device sample rate, looped from 60% onwards for long holds.
void NativeAudioEngine::renderSamples(int lane) {
    const int first = (lane < 0) ? 0 : lane;
    const int last = (lane < 0) ? kLanes - 1 : lane;

    const int sr = sampleRate_;
    const int len = (int) (sr * 2.4f);
    for (int l = first; l <= last; ++l) {
        delete[] samples_[l];
        samples_[l] = new float[len];
        sampleLen_[l] = len;

        const int rootPitch = 36 + l * 4;                 // C2 .. B4, spread across the keyboard
        sampleRoot_[l] = rootPitch;
        const float f0 = midiToHz(rootPitch);
        const float detune = 0.0004f * (l - 6);           // tiny per-lane detune so 12 lanes shimmer
        const int partials = 18;

        for (int i = 0; i < len; ++i) {
            const float t = (float) i / sr;
            float v = 0.f;
            for (int h = 1; h <= partials; ++h) {
                // Inharmonicity: real strings stretch partials upward (B in  f_h = h*f0*sqrt(1+B*h^2))
                const float fh = f0 * h * std::sqrt(1.0f + 0.00032f * h * h) * (1.0f + detune);
                if (fh > sr * 0.47f) break;               // stay under Nyquist, no aliasing
                const float amp = std::exp(-h * 0.22f) / std::pow((float) h, 1.15f);
                const float decay = 2.1f + h * 1.15f;     // high partials decay faster
                v += amp * std::exp(-decay * t) * std::sin(kTwoPi * fh * t);
            }
            // Hammer transient: 12 ms of filtered noise at the attack.
            if (i < (int) (sr * 0.012f)) {
                const float n = (float) (((i * 1103515245 + 12345) >> 16) & 0xFFFF) / 32768.0f - 1.0f;
                v += n * 0.16f * std::exp(-t * 260.0f);
            }
            // Attack ramp (2 ms) so the note never starts with a click.
            const float atk = t < 0.002f ? t / 0.002f : 1.0f;
            samples_[l][i] = v * atk;
        }

        // Normalise to a fixed peak so lane-to-lane loudness is consistent, then apply a gentle
        // fade at the end so a long hold loops back seamlessly instead of clicking.
        float peak = 1e-6f;
        for (int i = 0; i < len; ++i) peak = std::max(peak, std::fabs(samples_[l][i]));
        const float norm = 0.85f / peak;
        const int fade = sr / 40;                          // 25 ms
        for (int i = 0; i < len; ++i) {
            float g = norm;
            if (i > len - fade) g *= (float) (len - i) / fade;
            samples_[l][i] *= g;
        }
    }
    LOGI("Pre-rendered %d key samples (%d frames each @ %d Hz)", last - first + 1, len, sr);
}

// ---------------------------------------------------------------------------
// Voice management (audio thread only)
// ---------------------------------------------------------------------------
Voice* NativeAudioEngine::allocateVoice() {
    Voice* oldest = &voices_[0];
    for (int i = 0; i < kVoices; ++i) {
        if (!voices_[i].active) return &voices_[i];
        if (voices_[i].startedAt < oldest->startedAt) oldest = &voices_[i];
    }
    return oldest;                                     // steal the oldest: least audible choice
}

void NativeAudioEngine::startVoice(int pitch, int velocity) {
    // Pick the closest pre-rendered sample, then pitch-shift it. 12 comparisons, no allocation.
    int bestLane = 6, bestDist = 999;
    for (int l = 0; l < kLanes; ++l) {
        const int d = std::abs(sampleRoot_[l] - pitch);
        if (d < bestDist) { bestDist = d; bestLane = l; }
    }
    if (samples_[bestLane] == nullptr || sampleLen_[bestLane] <= 0) return;

    Voice* v = allocateVoice();
    v->active = true;
    v->lane = bestLane;
    v->pos = 0;
    v->releaseAt = 0;
    v->gain = std::max(0.05f, (float) velocity / 127.0f);
    v->env = 1.0f;
    v->pan = (float) bestLane / (float) (kLanes - 1);
    v->startedAt = voiceClock_++;
    // Sample-rate-correct pitch shift: semitone ratio 2^(n/12), applied as an increment so each
    // output sample advances the read position fractionally (linear interpolation below).
    v->ratio = std::pow(2.0f, (pitch - sampleRoot_[bestLane]) / 12.0f);
    v->ratio = std::min(v->ratio, 8.0f);               // guard: a 4-octave jump is already extreme
    // Loop the tail so a multi-second hold costs no extra memory and no re-trigger.
    v->loopStart = (uint32_t) (sampleLen_[bestLane] * 0.60f);
    v->loopEnd = (uint32_t) sampleLen_[bestLane];
    activeVoices_.fetch_add(1, std::memory_order_relaxed);
}

void NativeAudioEngine::releaseVoicesForPitch(int pitch) {
    for (int i = 0; i < kVoices; ++i) {
        Voice& v = voices_[i];
        if (v.active && v.releaseAt == 0) v.releaseAt = v.pos ? v.pos : 1;   // begin the release ramp
    }
    (void) pitch;   // one-shots: a note-off simply releases everything still ringing
}

// ---------------------------------------------------------------------------
// Producer side (called from Java via JNI, any thread)
// ---------------------------------------------------------------------------
void NativeAudioEngine::noteOn(int midiPitch, float velocity) {
    const int v = (int) (std::min(1.f, std::max(0.f, velocity)) * 127.f);
    NoteEvent e = NoteEvent::noteOn(midiPitch & 0x7F, v);
    if (!events_.push(e)) {
        // Ring full: dropping is intentional. Blocking here would stall the UI thread; expanding
        // would allocate on the RT path. At 4096 slots this only happens if the audio callback
        // has been dead for a long time.
        LOGW("event ring full, dropped a note");
    }
}

void NativeAudioEngine::noteOff(int midiPitch) {
    NoteEvent e{}; e.kind = 1; e.pitch = midiPitch & 0x7F;
    events_.push(e);
}

void NativeAudioEngine::allNotesOff() {
    for (int i = 0; i < kVoices; ++i) {
        voices_[i].active = false;
        voices_[i].releaseAt = 0;
    }
    activeVoices_.store(0, std::memory_order_relaxed);
}

void NativeAudioEngine::setLanePitch(int lane, int midiPitch) { lanePitch_[lane % kLanes] = midiPitch; }

void NativeAudioEngine::setMasterVolume(float v) {
    masterVolume_.store(std::min(1.5f, std::max(0.f, v)), std::memory_order_relaxed);
}

void NativeAudioEngine::setSample(int lane, const float* data, int length, int rootPitch) {
    if (lane < 0 || lane >= kLanes || data == nullptr || length <= 0) return;
    if (running_.load()) {
        LOGW("setSample ignored while the stream is running (stop the engine first)");
        return;                                        // documented: swap samples offline
    }
    delete[] samples_[lane];
    samples_[lane] = new float[length];
    std::memcpy(samples_[lane], data, (size_t) length * sizeof(float));
    sampleLen_[lane] = length;
    sampleRoot_[lane] = rootPitch;
}

int64_t NativeAudioEngine::playbackPositionMs() const {
    const int sr = sampleRate_ > 0 ? sampleRate_ : 48000;
    return framesPlayed_.load(std::memory_order_relaxed) * 1000 / sr;
}

// ---------------------------------------------------------------------------
// The realtime callback
// ---------------------------------------------------------------------------
oboe::DataCallbackResult NativeAudioEngine::onAudioReady(oboe::AudioStream* /*stream*/,
                                                         void* audioData, int32_t numFrames) {
    float* out = static_cast<float*>(audioData);
    std::memset(out, 0, sizeof(float) * (size_t) numFrames * 2);

    // 1. Consume pending events, bounded per callback so a burst cannot blow the deadline.
    NoteEvent e;
    int budget = 256;
    while (budget-- > 0 && events_.pop(e)) {
        if (e.kind == 0) startVoice(e.pitch, e.velocity);
        else if (e.kind == 1) releaseVoicesForPitch(e.pitch);
    }

    const float master = masterVolume_.load(std::memory_order_relaxed);

    // 2. Mix every active voice. All state is in the preallocated voice array.
    for (int vi = 0; vi < kVoices; ++vi) {
        Voice& v = voices_[vi];
        if (!v.active) continue;

        const float* buf = samples_[v.lane];
        const int len = sampleLen_[v.lane];
        if (buf == nullptr || len <= 0) { v.active = false; continue; }

        const float lGain = (1.0f - v.pan) * 1.2f;
        const float rGain = v.pan * 1.2f;
        float pos = (float) v.pos;

        for (int i = 0; i < numFrames; ++i) {
            const int i0 = (int) pos;
            if (i0 >= len - 1) {
                // End of sample: loop back into the sustain region for long holds, else die.
                if (v.releaseAt == 0 && v.ratio < 1.2f) {
                    v.pos = v.loopStart;
                    pos = (float) v.pos;
                    continue;   // re-enter with the looped position (still inside this frame's loop)
                }
                v.active = false;
                break;
            }
            const float frac = pos - (float) i0;
            const float s = buf[i0] + (buf[i0 + 1] - buf[i0]) * frac;

            // Envelope: natural sample decay while held; a 90 ms ramp once released.
            if (v.releaseAt != 0) {
                const uint32_t releasedFor = v.pos > v.releaseAt ? v.pos - v.releaseAt : 0;
                const float ramp = 1.0f - (float) releasedFor / (0.090f * sampleRate_);
                if (ramp <= 0.f) { v.active = false; break; }
                v.env = ramp;
            }
            const float g = s * v.gain * v.env * master;
            out[i * 2] += g * lGain;
            out[i * 2 + 1] += g * rGain;

            pos += v.ratio;
            v.pos = (uint32_t) pos;
        }
    }

    // 3. Soft clip. Black-MIDI passages sum dozens of voices; tanh-ish saturation keeps the mix
    //    loud without the harsh digital clipping that a hard clamp produces.
    for (int i = 0; i < numFrames * 2; ++i) {
        float x = out[i];
        if (x > 1.0f || x < -1.0f) {
            const float a = std::fabs(x);
            x = (x > 0 ? 1.0f : -1.0f) * (1.0f - 1.0f / (1.0f + a));
        }
        out[i] = x;
    }

    framesPlayed_.fetch_add(numFrames, std::memory_order_relaxed);

    int active = 0;
    for (int i = 0; i < kVoices; ++i) if (voices_[i].active) ++active;
    activeVoices_.store(active, std::memory_order_relaxed);

    return oboe::DataCallbackResult::Continue;
}

bool NativeAudioEngine::onError(oboe::AudioStream* stream, oboe::Result error) {
    xruns_.fetch_add(1, std::memory_order_relaxed);
    lastError_.store((int) error, std::memory_order_relaxed);
    LOGW("Audio stream error: %s", oboe::convertToText(error));

    // IMPORTANT (this was a launch crash): the error callback must NOT close or reset the stream.
    // Oboe documents that calling close() from here is illegal, and doing it while start() is still
    // running means two threads touching the same shared_ptr — occasionally a segfault, always
    // undefined. All we do is mark ourselves not-running; Oboe owns the teardown from here, and the
    // Java layer sees isRunning() == false and stops triggering voices instead of pretending to play.
    (void) stream;
    running_.store(false, std::memory_order_release);

    // Returning false tells Oboe we do not want an automatic restart.
    return false;
}

} // namespace pianohell
