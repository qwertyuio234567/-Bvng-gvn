// PianoHell — JNI bridge.
//
// Deliberately a thin shim: every entry point does one thing and returns. The interesting work
// (voice pool, ring buffer, mixing) lives in NativeAudioEngine, and the Java side (AudioEngine.java)
// holds the policy: when to start, what pitch each lane sounds, and how to degrade if native audio
// is unavailable.
//
// Only ONE engine instance exists per process (one output stream per app is the correct model for
// a game), so the handle is a singleton guarded for start/stop only. Calls that arrive from the UI
// thread while the RT thread is mixing are lock-free by construction: they push into the SPSC ring.

#include <jni.h>
#include <android/log.h>
#include <mutex>

#include "NativeAudioEngine.h"

#define LOG_TAG "PianoHellJni"
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)

namespace {
pianohell::NativeAudioEngine* gEngine = nullptr;
std::mutex gStartStopMutex;          // never taken by the audio thread or by noteOn()

inline pianohell::NativeAudioEngine* engine() { return gEngine; }
} // namespace

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_pianohell_AudioEngine_nativeCreate(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gStartStopMutex);
    if (gEngine == nullptr) gEngine = new pianohell::NativeAudioEngine();
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_pianohell_AudioEngine_nativeStart(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gStartStopMutex);
    if (gEngine == nullptr) return JNI_FALSE;
    return gEngine->start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeStop(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gStartStopMutex);
    if (gEngine) gEngine->stop();
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeRelease(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lock(gStartStopMutex);
    if (gEngine) {
        gEngine->stop();
        delete gEngine;
        gEngine = nullptr;
    }
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeNoteOn(JNIEnv*, jobject, jint pitch, jfloat velocity) {
    pianohell::NativeAudioEngine* e = engine();
    if (e && e->isRunning()) e->noteOn(pitch, velocity);
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeNoteOff(JNIEnv*, jobject, jint pitch) {
    pianohell::NativeAudioEngine* e = engine();
    if (e && e->isRunning()) e->noteOff(pitch);
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeAllNotesOff(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    if (e) e->allNotesOff();
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeSetLanePitch(JNIEnv*, jobject, jint lane, jint pitch) {
    pianohell::NativeAudioEngine* e = engine();
    if (e) e->setLanePitch(lane, pitch);
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeSetLanePitches(JNIEnv* env, jobject, jintArray pitches) {
    pianohell::NativeAudioEngine* e = engine();
    if (!e || pitches == nullptr) return;
    const jsize n = env->GetArrayLength(pitches);
    if (n <= 0) return;
    // GetIntArrayElements with a small stack buffer avoids a heap copy for a 12-element array.
    jint buf[12];
    const jsize take = n < 12 ? n : 12;
    env->GetIntArrayRegion(pitches, 0, take, buf);
    for (jsize i = 0; i < take; ++i) e->setLanePitch((int) i, (int) buf[i]);
}

JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeSetMasterVolume(JNIEnv*, jobject, jfloat v) {
    pianohell::NativeAudioEngine* e = engine();
    if (e) e->setMasterVolume(v);
}

/**
 * Install a real instrument sample for one lane (a WAV/SoundFont render, for example).
 * Must be called while the stream is stopped so the audio thread never reads a half-swapped buffer.
 */
JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeSetSample(JNIEnv* env, jobject, jint lane,
                                              jfloatArray data, jint length, jint rootPitch) {
    pianohell::NativeAudioEngine* e = engine();
    if (!e || data == nullptr) return;
    const jsize n = env->GetArrayLength(data);
    const jsize take = n < length ? n : length;
    if (take <= 0) return;
    jfloat* buf = new jfloat[take];
    env->GetFloatArrayRegion(data, 0, take, buf);
    e->setSample((int) lane, buf, (int) take, (int) rootPitch);
    delete[] buf;
}

JNIEXPORT jlong JNICALL
Java_com_pianohell_AudioEngine_nativePositionMs(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return e ? (jlong) e->playbackPositionMs() : -1;
}

JNIEXPORT jint JNICALL
Java_com_pianohell_AudioEngine_nativeActiveVoices(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return e ? e->getActiveVoices() : 0;
}

JNIEXPORT jint JNICALL
Java_com_pianohell_AudioEngine_nativeSampleRate(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return e ? e->getSampleRate() : 0;
}

JNIEXPORT jint JNICALL
Java_com_pianohell_AudioEngine_nativeXruns(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return e ? e->getXruns() : 0;
}

JNIEXPORT jboolean JNICALL
Java_com_pianohell_AudioEngine_nativeIsRunning(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return (e && e->isRunning()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_pianohell_AudioEngine_nativeIsHealthy(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return (e && e->isHealthy()) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_pianohell_AudioEngine_nativeLastError(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    return e ? (jint) e->getLastError() : -1;
}

// Reset the audio clock to zero. The game calls this when a run starts so that
// playbackPositionMs() is "milliseconds into this run".
JNIEXPORT void JNICALL
Java_com_pianohell_AudioEngine_nativeResetClock(JNIEnv*, jobject) {
    pianohell::NativeAudioEngine* e = engine();
    if (e) e->resetClock();
}

} // extern "C"
